"""Offline library utilities. No Qt dependency; safe to test independently."""
from __future__ import annotations
import hashlib
import os
import sqlite3
import threading
from contextlib import contextmanager
import time
from collections import defaultdict
from pathlib import Path

_DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS videos (
    path TEXT PRIMARY KEY, size INTEGER NOT NULL, mtime REAL NOT NULL,
    duration REAL, width INTEGER, height INTEGER,
    updated_at REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_videos_size ON videos(size);
"""


def library_folders(cfg: dict) -> list[str]:
    paths = cfg.get('folders', [])
    if not isinstance(paths, list):
        paths = []
    # Preserve the first-selected folder for backwards compatibility.
    primary = cfg.get('folder', '')
    if primary:
        paths = [primary] + paths
    result, seen = [], set()
    for item in paths:
        if not isinstance(item, str) or not item.strip():
            continue
        absolute = os.path.abspath(os.path.expanduser(item))
        key = os.path.normcase(absolute)
        if key not in seen:
            seen.add(key)
            result.append(absolute)
    return result


def default_database_path() -> Path:
    base = os.environ.get('LOCALAPPDATA') if os.name == 'nt' else None
    if not base:
        base = str(Path.home() / '.local' / 'share')
    return Path(base) / 'VideoShelf' / 'library.sqlite3'


class LibraryCatalog:
    """Small WAL catalog: fast metadata reuse, not the source of portable ratings."""
    def __init__(self, db_path: str | Path | None = None):
        self.path = Path(db_path) if db_path else default_database_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self._connect() as db:
            db.executescript(_DB_SCHEMA)

    @contextmanager
    def _connect(self):
        # SQLite's own `with connection:` commits/rolls back but does not close
        # the handle. Use an explicit context manager to avoid DB handle leaks.
        db = sqlite3.connect(str(self.path), timeout=8)
        try:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA busy_timeout=8000')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def index_scan(self, rows: list[tuple]):
        stamp = time.time()
        with self._lock, self._connect() as db:
            db.executemany('''
                INSERT INTO videos(path, size, mtime, updated_at) VALUES (?, ?, ?, ?)
                ON CONFLICT(path) DO UPDATE SET
                  duration=CASE WHEN videos.size=excluded.size AND videos.mtime=excluded.mtime THEN videos.duration ELSE NULL END,
                  width=CASE WHEN videos.size=excluded.size AND videos.mtime=excluded.mtime THEN videos.width ELSE NULL END,
                  height=CASE WHEN videos.size=excluded.size AND videos.mtime=excluded.mtime THEN videos.height ELSE NULL END,
                  size=excluded.size, mtime=excluded.mtime, updated_at=excluded.updated_at
                WHERE videos.size != excluded.size OR videos.mtime != excluded.mtime
            ''', ((p, int(size), float(mtime), stamp) for p, _, size, mtime in rows))

    def cached_metadata(self, rows: list[tuple]) -> dict[str, tuple]:
        # Read all in one SQLite pass, avoiding 10k independent queries.
        row_stat = {path: (int(size), float(mtime)) for path, _, size, mtime in rows}
        if not row_stat:
            return {}
        # Query only current-library paths. Older versions loaded *every* row
        # from the database, even when this library contains just 200 files.
        result = {}
        paths = list(row_stat)
        with self._lock, self._connect() as db:
            for offset in range(0, len(paths), 400):
                batch = paths[offset:offset + 400]
                placeholders = ','.join('?' for _ in batch)
                sql = ("SELECT path, size, mtime, duration, width, height FROM videos "
                       f"WHERE duration IS NOT NULL AND path IN ({placeholders})")
                for p, size, mtime, dur, w, h in db.execute(sql, batch):
                    if row_stat.get(p) == (int(size), float(mtime)):
                        result[p] = (float(dur), int(w or 0), int(h or 0))
        return result

    def store_metadata(self, path: str, duration: float, width: int, height: int):
        try:
            st = Path(path).stat()
        except OSError:
            return
        with self._lock, self._connect() as db:
            db.execute('''
                INSERT INTO videos(path, size, mtime, duration, width, height, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(path) DO UPDATE SET
                    duration=excluded.duration, width=excluded.width, height=excluded.height,
                    size=excluded.size, mtime=excluded.mtime, updated_at=excluded.updated_at

            ''', (path, st.st_size, st.st_mtime, float(duration), int(width), int(height), time.time()))

    def remove(self, paths):
        with self._lock, self._connect() as db:
            db.executemany('DELETE FROM videos WHERE path=?', ((p,) for p in paths))


def duplicate_groups(paths: list[str], stop: threading.Event | None = None,
                     progress=None) -> list[list[str]]:
    """Only call files exact duplicates after comparing their *complete* SHA256.

    Group by size, then cheap edge digest, then whole-file digest. This avoids
    the worst O(files * file_size) scanning cost and never deletes anything.
    """
    by_size = defaultdict(list)
    for p in paths:
        if stop and stop.is_set():
            return []
        try:
            st = os.stat(p)
            if st.st_size > 0:
                by_size[st.st_size].append(p)
        except OSError:
            continue
    candidates = [p for group in by_size.values() if len(group) > 1 for p in group]
    by_edge = defaultdict(list)
    for i, p in enumerate(candidates, 1):
        if stop and stop.is_set():
            return []
        try:
            with open(p, 'rb') as stream:
                h = hashlib.sha256(stream.read(1024 * 1024))
                stream.seek(max(0, os.path.getsize(p) - 1024 * 1024))
                h.update(stream.read(1024 * 1024))
            by_edge[(os.path.getsize(p), h.digest())].append(p)
        except OSError:
            continue
        if progress and i % 20 == 0:
            progress(i, len(candidates), 'sample')
    exact_candidates = [p for group in by_edge.values() if len(group) > 1 for p in group]
    exact = defaultdict(list)
    for i, p in enumerate(exact_candidates, 1):
        if stop and stop.is_set():
            return []
        try:
            h = hashlib.sha256()
            with open(p, 'rb') as stream:
                for chunk in iter(lambda: stream.read(2 * 1024 * 1024), b''):
                    if stop and stop.is_set():
                        return []
                    h.update(chunk)
            exact[(os.path.getsize(p), h.digest())].append(p)
        except OSError:
            continue
        if progress:
            progress(i, len(exact_candidates), 'full')
    return [sorted(group) for group in exact.values() if len(group) > 1]
