@echo off
setlocal
where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py"
) else (
  set "PY=python"
)

echo Current pip configuration:
%PY% -m pip config list
echo.
echo Removing custom global/user index-url values if present...
%PY% -m pip config unset global.index-url 2>nul
%PY% -m pip config unset user.index-url 2>nul
echo.
echo Testing official PyPI...
%PY% -m pip install --index-url https://pypi.org/simple --timeout 60 --retries 5 --upgrade pip
echo.
echo Done. Now run run.bat
pause
endlocal
