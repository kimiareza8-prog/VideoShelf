"""Reliable filename ratings, independent of Qt.

A rating is encoded in the real filename, e.g. ``Film [★15].mkv``.
The folder-local .videoshelf.json remains the portable metadata source.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from file_actions import _read_sidecar, _write_sidecar

MAX_RATING = 20
# Remove only our recognized terminal rating marker, never internal parts of a title.
_RATING_SUFFIX = re.compile(r'\s\[★(?:[1-9]|1[0-9]|20)\]$')
_RATING_EXTRACT = re.compile(r'\s\[★(\d{1,2})\]$')


def unmarked_stem(stem: str) -> str:
    return _RATING_SUFFIX.sub('', stem)


def rating_from_filename(filename: str) -> int:
    """Recover the star value when a movie travels without its JSON sidecar."""
    match = _RATING_EXTRACT.search(Path(filename).stem)
    if not match:
        return 0
    value = int(match.group(1))
    return value if 1 <= value <= MAX_RATING else 0


def rated_filename(filename: str, rating: int) -> str:
    if not 0 <= int(rating) <= MAX_RATING:
        raise ValueError(f'Rating must be between 0 and {MAX_RATING}')
    path = Path(filename)
    name = unmarked_stem(path.stem)
    if not name:
        raise ValueError('A video filename cannot consist only of a rating')
    # Windows accepts ★, and we retain the exact original media extension.
    suffix = f' [★{int(rating)}]' if rating else ''
    return f'{name}{suffix}{path.suffix}'


def _matching_key(mapping: dict, filename: str):
    wanted = filename.casefold()
    return next((key for key in mapping if str(key).casefold() == wanted), None)


def rename_video_for_rating(path: str, rating: int) -> str:
    """Rename a local video without overwriting existing files or losing sidecars.

    Changing a rating changes the name (not content) of the video and migrates
    all existing per-video sidecar maps. The sidecar is updated atomically.
    On sidecar-write failure, attempt to restore the filename, then raise.
    """
    value = int(rating)
    if not 0 <= value <= MAX_RATING:
        raise ValueError(f'Rating must be between 0 and {MAX_RATING}')
    src = Path(path).absolute()
    if not src.is_file():
        raise FileNotFoundError(str(src))
    dst = src.with_name(rated_filename(src.name, value))
    data = _read_sidecar(src.parent)
    updated = json.loads(json.dumps(data))
    # Future metadata sections whose keys are video filenames are also migrated.
    for section, mapping in updated.items():
        if not isinstance(mapping, dict):
            continue
        key = _matching_key(mapping, src.name)
        if key is not None:
            moving = mapping.pop(key)
            new_key = _matching_key(mapping, dst.name)
            if new_key is not None and new_key != key:
                # A stale sidecar may refer to a real destination: do not stomp it.
                raise FileExistsError(f'Destination metadata already exists: {dst.name}')
            if section != 'ratings':
                mapping[dst.name] = moving
    scores = updated.setdefault('ratings', {})
    if not isinstance(scores, dict):
        scores = {}
        updated['ratings'] = scores
    for old in list(scores):
        if str(old).casefold() in {src.name.casefold(), dst.name.casefold()}:
            scores.pop(old)
    if value:
        scores[dst.name] = value

    # Even no-rename changes (same star rating) repair missing JSON data.
    if dst != src:
        # Check using casefold since Windows directories are case insensitive.
        if any(p.name.casefold() == dst.name.casefold() for p in src.parent.iterdir() if p != src):
            raise FileExistsError(f'A file with this name already exists: {dst.name}')
        os.rename(src, dst)  # Same directory and filesystem: fast atomic rename.
    try:
        _write_sidecar(src.parent, updated)
    except Exception as exc:
        if dst != src:
            try:
                os.rename(dst, src)
            except OSError as rollback_error:
                raise RuntimeError(
                    f'Renamed to {dst.name}, sidecar failed; rollback failed: {rollback_error}'
                ) from exc
        raise
    return str(dst)
