"""Pure selection logic for bounded, fair, true live visible-card previews."""
from __future__ import annotations


def select_visible_live_paths(paths, limit: int, offset: int = 0, hover: str | None = None) -> list[str]:
    """Choose up to `limit` visible files, prioritizing hover without duplicates.

    When there are too many visible videos to decode concurrently, the caller
    rotates offset to give each viewport video playback time. No thumbnails or
    fake snapshot animation is generated for inactive files.
    """
    ordered = list(dict.fromkeys(path for path in paths if path))
    if not ordered:
        return []
    budget = max(1, min(24, int(limit)))
    if len(ordered) <= budget:
        return ordered
    start = offset % len(ordered)
    rotated = ordered[start:] + ordered[:start]
    result = []
    if hover in ordered:
        result.append(hover)
    for path in rotated:
        if path not in result:
            result.append(path)
        if len(result) >= budget:
            break
    return result
