@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PIP_DEFAULT_TIMEOUT=60"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py") else (set "PY=python")

echo Installing build dependencies...
%PY% -m pip install --prefer-binary --timeout 60 --retries 2 ^
  --index-url https://mirror.novin.cloud/artifactory/api/pypi/pypi/simple/ ^
  --trusted-host mirror.novin.cloud ^
  -r requirements.txt pyinstaller
if not errorlevel 1 goto build

%PY% -m pip install --prefer-binary --timeout 60 --retries 2 ^
  --index-url https://mirror-pypi.runflare.com/simple ^
  --trusted-host mirror-pypi.runflare.com ^
  -r requirements.txt pyinstaller
if not errorlevel 1 goto build

%PY% -m pip install --prefer-binary --timeout 90 --retries 4 ^
  --index-url https://pypi.org/simple ^
  -r requirements.txt pyinstaller
if errorlevel 1 goto failed

:build
%PY% -m PyInstaller --noconfirm --clean --windowed --name VideoShelf ^
  --collect-all imageio_ffmpeg ^
  main.py
echo.
echo Build complete: dist\VideoShelf
pause
exit /b 0

:failed
echo Build dependencies could not be installed.
pause
exit /b 1
