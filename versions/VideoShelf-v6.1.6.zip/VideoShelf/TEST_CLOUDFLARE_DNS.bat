@echo off
chcp 65001 >nul
title VideoShelf - Cloudflare DNS SRV Test
echo ============================================================
echo Cloudflare Edge DNS diagnostic
echo ============================================================
echo.
echo [1] System DNS - required SRV record:
powershell -NoProfile -Command "Resolve-DnsName -Name '_v2-origintunneld._tcp.argotunnel.com' -Type SRV -ErrorAction Continue | Format-Table NameTarget,Port,Priority,Weight -AutoSize"
echo.
echo [2] Cloudflare DNS 1.1.1.1 - same SRV record:
powershell -NoProfile -Command "Resolve-DnsName -Name '_v2-origintunneld._tcp.argotunnel.com' -Type SRV -Server '1.1.1.1' -ErrorAction Continue | Format-Table NameTarget,Port,Priority,Weight -AutoSize"
echo.
echo [3] Feature hostname with system DNS:
powershell -NoProfile -Command "Resolve-DnsName -Name 'cfd-features.argotunnel.com' -Type A -ErrorAction Continue | Format-Table Name,IPAddress -AutoSize"
echo.
echo If [1] fails but [2] works, your current Windows/router/ISP DNS resolver is the problem.
echo No inbound port-forward is required for Cloudflare Tunnel.
echo.
pause
