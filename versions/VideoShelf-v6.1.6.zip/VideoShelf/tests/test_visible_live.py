"""v6.1.1 regression tests: live-visible selection, rotation, source integration."""
import ast
from pathlib import Path
import unittest

from visible_scheduler import select_visible_live_paths

ROOT = Path(__file__).resolve().parents[1]


class SchedulerTests(unittest.TestCase):
    def test_within_limit_shows_every_video(self):
        for n in (0, 1, 5, 8):
            paths=[f'/videos/{i}.mp4' for i in range(n)]
            self.assertEqual(select_visible_live_paths(paths, 8), paths)

    def test_more_than_limit_is_bounded_and_rotates(self):
        paths=[f'v{i}.mkv' for i in range(20)]
        observed=set()
        for offset in range(20):
            chosen=select_visible_live_paths(paths, 8, offset)
            self.assertEqual(len(chosen), 8)
            observed.update(chosen)
        self.assertEqual(observed, set(paths))

    def test_hover_gets_priority_without_duplicate_decoder(self):
        paths=[f'v{i}' for i in range(20)]
        result=select_visible_live_paths(paths, 8, hover='v18')
        self.assertEqual(result[0], 'v18')
        self.assertEqual(len(result), len(set(result)))
        self.assertEqual(len(result), 8)
        self.assertNotIn('absent', result)

    def test_resists_duplicate_paths_and_outside_hover(self):
        result=select_visible_live_paths(['a','b','a','c'],2,0,'offscreen')
        self.assertEqual(result, ['a','b'])
        self.assertEqual(select_visible_live_paths([],8), [])
        self.assertEqual(select_visible_live_paths(['a'],0), ['a'])

    def test_single_card_rotation_does_not_restart_other_seven(self):
        paths=[str(x) for x in range(12)]
        first=set(select_visible_live_paths(paths, 8, 0))
        next_page=set(select_visible_live_paths(paths, 8, 1))
        self.assertEqual(len(first & next_page), 7)


class MainIntegrationTests(unittest.TestCase):
    def test_visible_mode_uses_live_decoder_not_legacy_jpeg_preview(self):
        tree=ast.parse((ROOT/'main.py').read_text(encoding='utf8'))
        library=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='LibraryTab')
        visible=next(x for x in library.body if isinstance(x,ast.FunctionDef) and x.name=='on_visible_rows')
        called=[x.func.attr for x in ast.walk(visible) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute)]
        self.assertIn('set_visible',called)
        self.assertNotIn('request_preview',called)
        self.assertIn('stop', called)

    def test_visible_card_stream_shares_hover_clock(self):
        tree=ast.parse((ROOT/'main.py').read_text(encoding='utf8'))
        cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='VisibleCardPreview')
        self.assertEqual(cls.bases[0].id,'SmoothHoverPreview')
        manager=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='VisibleLivePreviews')
        self.assertIn('_rotate',[x.name for x in manager.body if isinstance(x,ast.FunctionDef)])


if __name__=='__main__':
    unittest.main()
