"""Regression tests for 6.1.6; no PySide6 required on CI."""
import ast
import types
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'main.py').read_text(encoding='utf8')
TREE=ast.parse(SOURCE)

def method(name, func):
    cl=next(x for x in TREE.body if isinstance(x,ast.ClassDef) and x.name==name)
    return next(x for x in cl.body if isinstance(x,ast.FunctionDef) and x.name==func)

class FakeBar:
    def __init__(self): self.n=400
    def minimum(self):return 0
    def maximum(self):return 1000
    def value(self):return self.n
    def setValue(self,value):self.n=value
class FakeAnimation:
    state_code=0
    def stop(self):self.state_code=0
    def state(self):return self.state_code
    def setStartValue(self,value):self.start_value=value
    def setEndValue(self,value):self.end=value
    def start(self):self.state_code=2
class FakeEvent:
    def __init__(self,angle,pixel=0): self.angle=angle;self.pixel=pixel;self.accepted=False
    def pixelDelta(self):return types.SimpleNamespace(y=lambda:self.pixel)
    def angleDelta(self):return types.SimpleNamespace(y=lambda:self.angle)
    def accept(self):self.accepted=True
class FakeView:
    _wheel_target=None
    def __init__(self):self.bar=FakeBar();self._scroll_anim=FakeAnimation()
    def verticalScrollBar(self):return self.bar
class ScrollTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        node=method('SmartVideoView','wheelEvent')
        namespace={'QAbstractAnimation':types.SimpleNamespace(State=types.SimpleNamespace(Running=2))}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'test','exec'),namespace)
        cls.wheel=staticmethod(namespace['wheelEvent'])
    def test_single_notch_moves_only_small_portion_of_card(self):
        view=FakeView();e=FakeEvent(-120)
        self.wheel(view,e)
        self.assertTrue(e.accepted)
        self.assertEqual(view._scroll_anim.end,474)
    def test_large_wheel_burst_is_clamped(self):
        view=FakeView();self.wheel(view,FakeEvent(-720))
        self.assertEqual(view._scroll_anim.end,548)
    def test_touchpad_uses_direct_pixels(self):
        view=FakeView();self.wheel(view,FakeEvent(0,-17))
        self.assertEqual(view.bar.value(),417)
    def test_target_resets_on_new_gesture(self):
        view=FakeView();view._wheel_target=900
        self.wheel(view,FakeEvent(-120))
        self.assertEqual(view._wheel_target,474)
class MultiPlayerTests(unittest.TestCase):
    def test_each_click_opens_independent_player(self):
        body=ast.unparse(method('LibraryTab','play_internal'))
        self.assertIn('player = InternalVideoPlayer(self.cfg, self)',body)
        self.assertIn('self._players.append(player)',body)
        self.assertIn('self._max_players',body)
        self.assertNotIn('self.internal_player.open_file',body)
    def test_clean_close_and_shutdown(self):
        self.assertIn('self._players.remove(player)',ast.unparse(method('LibraryTab','close_internal_player')))
        self.assertIn('player.shutdown()',ast.unparse(method('LibraryTab','shutdown_players')))
        self.assertIn('player.deleteLater()',ast.unparse(method('LibraryTab','shutdown_players')))
    def test_ratings_and_safe_delete_still_have_priority_over_play(self):
        body=ast.unparse(method('SmartVideoView','mousePressEvent'))
        self.assertLess(body.index('self.delete_requested.emit(path)'),body.index('self.rating_requested.emit'))
        self.assertLess(body.index('self.rating_requested.emit'),body.index('self._press_path = idx.data(PATH_ROLE)'))
        self.assertIn('Qt.ControlModifier',body)
        self.assertIn('Qt.ShiftModifier',body)
    def test_activate_only_after_release_and_check_drag(self):
        release=ast.unparse(method('SmartVideoView','mouseReleaseEvent'))
        self.assertIn('manhattanLength()',release)
        self.assertIn('self.play_requested.emit(path)',release)
        self.assertIn('not self._scrolling',release)
    def test_player_click_wheel_and_double_click(self):
        body=ast.unparse(method('InternalVideoPlayer','eventFilter'))
        self.assertIn('self.volume.setValue',body)
        self.assertIn('self.video_zoom.setValue',body)
        self.assertIn('self.toggle_fullscreen()',body)
        self.assertIn('self._surface_click.start()',body)
if __name__=='__main__':unittest.main()

class RuntimeMultiplePlayerTests(unittest.TestCase):
    """Run the actual LibraryTab methods with fake Qt widgets (without PySide6)."""
    def test_four_independent_players_and_no_replacement(self):
        from tempfile import TemporaryDirectory
        class Signal:
            def __init__(self): self.callback = None
            def connect(self, cb): self.callback=cb
        class Player:
            def __init__(self, cfg, owner):
                self.back_requested=Signal();self.path=None;self.moved=[]
            def open_file(self, path):self.path=path
            def _screen_rect(self):return types.SimpleNamespace(x=lambda:0,y=lambda:0,right=lambda:1920,bottom=lambda:1080)
            def x(self):return 500
            def y(self):return 200
            def width(self):return 400
            def height(self):return 300
            def move(self,x,y):self.moved.append((x,y))
        node=method('LibraryTab','play_internal')
        ns={'Path':Path,'InternalVideoPlayer':Player}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'multi_test','exec'),ns)
        with TemporaryDirectory() as d:
            paths=[]
            for idx in range(4):
                p=Path(d)/f'{idx}.mp4';p.write_bytes(b'file');paths.append(str(p))
            class Owner:
                cfg={}
                _players=[]
                _max_players=10
                previews_stopped=0
                def stop_all_previews(self):self.previews_stopped+=1
                def close_internal_player(self,p):pass
            owner=Owner()
            for p in paths:ns['play_internal'](owner,p)
            self.assertEqual(len(owner._players),4)
            self.assertEqual([p.path for p in owner._players],paths)
            self.assertEqual(len({id(p) for p in owner._players}),4)
            self.assertEqual(owner.previews_stopped,4)
            self.assertTrue(owner._players[-1].moved)

    def test_unrelated_window_survives_close(self):
        class Player:
            def __init__(self, name):self.name=name;self.deleted=False
            def deleteLater(self):self.deleted=True
        a,b=Player('a'),Player('b')
        node=method('LibraryTab','close_internal_player')
        class Timer:
            @staticmethod
            def singleShot(ms,callback):callback()
        namespace={'QTimer':Timer}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'close_test','exec'),namespace)
        class Owner:
            _players=[a,b]
            _pending_rating_renames={}
        owner=Owner()
        namespace['close_internal_player'](owner,a)
        self.assertEqual(owner._players,[b])
        self.assertTrue(a.deleted)
        self.assertFalse(b.deleted)
