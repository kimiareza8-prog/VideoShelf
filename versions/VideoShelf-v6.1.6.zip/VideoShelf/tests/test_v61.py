"""Regression tests for v6.1 (Qt-free)."""
from __future__ import annotations
import json
import errno
from unittest.mock import patch
import os
import subprocess
import tempfile
import threading
import time
import unittest
from pathlib import Path

import imageio_ffmpeg

from file_actions import move_video
from library_core import LibraryCatalog
from preview_engine import PreviewDecoderPool, PreviewSpec, ffmpeg_command


class PortableMoveTests(unittest.TestCase):
    def test_move_carries_all_metadata_and_preserves_source_siblings(self):
        with tempfile.TemporaryDirectory() as td:
            src, dst = Path(td)/'from', Path(td)/'to'
            src.mkdir();dst.mkdir()
            movie = src/'movie.mp4';movie.write_bytes(b'video')
            (src/'other.mp4').write_bytes(b'keep')
            sidecar = {'version':1,'ratings':{'movie.mp4':8,'other.mp4':5},
                       'favorites':{'movie.mp4':True},'collections':{'movie.mp4':['Watch later']}}
            (src/'.videoshelf.json').write_text(json.dumps(sidecar))
            moved = Path(move_video(str(movie),str(dst)))
            self.assertEqual(moved.read_bytes(),b'video')
            self.assertFalse(movie.exists())
            source_meta=json.loads((src/'.videoshelf.json').read_text())
            target_meta=json.loads((dst/'.videoshelf.json').read_text())
            self.assertEqual(source_meta['ratings']['other.mp4'],5)
            self.assertNotIn('movie.mp4',source_meta['ratings'])
            self.assertEqual(target_meta['ratings']['movie.mp4'],8)
            self.assertTrue(target_meta['favorites']['movie.mp4'])
            self.assertEqual(target_meta['collections']['movie.mp4'],['Watch later'])

    def test_collision_never_overwrites_and_metadata_follows_rename(self):
        with tempfile.TemporaryDirectory() as td:
            src, dst = Path(td)/'src', Path(td)/'dst'
            src.mkdir();dst.mkdir()
            (dst/'movie.mp4').write_bytes(b'original')
            (src/'movie.mp4').write_bytes(b'new video')
            (src/'.videoshelf.json').write_text(json.dumps({'ratings':{'movie.mp4':9}}))
            path=Path(move_video(str(src/'movie.mp4'),str(dst)))
            self.assertEqual(path.name,'movie (2).mp4')
            self.assertEqual((dst/'movie.mp4').read_bytes(),b'original')
            self.assertEqual(path.read_bytes(),b'new video')
            data=json.loads((dst/'.videoshelf.json').read_text())
            self.assertEqual(data['ratings']['movie (2).mp4'],9)

    def test_cross_drive_fallback_stages_copy_before_removal(self):
        with tempfile.TemporaryDirectory() as td:
            src, dst=Path(td)/'s', Path(td)/'d';src.mkdir();dst.mkdir()
            f=src/'file.mp4';f.write_bytes(b'x'*50000)
            real_rename=os.rename
            def cross_volume(*args, **kwargs):
                raise OSError(errno.EXDEV, 'cross-device')
            with patch('file_actions.os.rename', side_effect=cross_volume):
                out=Path(move_video(str(f),str(dst)))
            self.assertEqual(out.read_bytes(),b'x'*50000)
            self.assertFalse(f.exists())
            self.assertEqual(list(dst.glob('*.partial')),[])

    def test_corrupt_source_sidecar_prevents_move_and_keeps_video(self):
        with tempfile.TemporaryDirectory() as td:
            src, dst=Path(td)/'s', Path(td)/'d';src.mkdir();dst.mkdir()
            f=src/'x.mp4';f.write_bytes(b'safe')
            (src/'.videoshelf.json').write_text('not a json')
            with self.assertRaises(ValueError):
                move_video(str(f),str(dst))
            self.assertEqual(f.read_bytes(),b'safe')


class SqliteScaleTests(unittest.TestCase):
    def test_lookup_does_not_depend_on_stale_other_library_rows(self):
        with tempfile.TemporaryDirectory() as td:
            db = LibraryCatalog(Path(td)/'c.db')
            old=[(f'/no/old/{i}.mp4',f'{i}.mp4',i+1,1.0) for i in range(3500)]
            db.index_scan(old)
            with db._connect() as con:
                con.executemany('UPDATE videos SET duration=30,width=640,height=360 WHERE path=?',
                                ((x[0],) for x in old))
            new=[(f'/new/{i}.mp4',f'{i}.mp4',i+1,1.0) for i in range(900)]
            db.index_scan(new)
            with db._connect() as con:
                con.executemany('UPDATE videos SET duration=12,width=1920,height=1080 WHERE path=?',
                                ((x[0],) for x in new))
            info=db.cached_metadata(new)
            self.assertEqual(len(info),900)
            self.assertTrue(all(info[row[0]]==(12.0,1920,1080) for row in new))


class DecoderTests(unittest.TestCase):
    def test_command_uses_actual_motion_interpolation_only_when_enabled(self):
        cmd=ffmpeg_command('ffmpeg','v.mp4',4,PreviewSpec(fps=60,speed=2.0,
                          interpolate=True,width=64,height=36),gpu=False)
        self.assertIn('-readrate',cmd)
        self.assertIn('2.00',cmd)
        self.assertIn('minterpolate=fps=30.0000:mi_mode=mci',cmd[cmd.index('-vf')+1])
        plain=ffmpeg_command('ffmpeg','v.mp4',0,PreviewSpec(interpolate=False))
        self.assertNotIn('minterpolate',plain[plain.index('-vf')+1])

    def test_pool_reuses_bounded_threads_and_cancels_obsolete_work(self):
        pool=PreviewDecoderPool(max_workers=2)
        ids=set();lock=threading.Lock()
        def job(cancel):
            with lock: ids.add(threading.get_ident())
            cancel.wait(0.075)
        try:
            for i in range(35):
                pool.cancel_all()
                pool.submit(i,job)
            time.sleep(0.16)
            self.assertLessEqual(len(ids),2)
        finally:
            pool.shutdown()
            self.assertFalse(pool.processes)

    def test_shutdown_kills_active_ffmpeg_child(self):
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        started = threading.Event()
        processes = []
        pool = PreviewDecoderPool(max_workers=2)
        def job(stop):
            process = subprocess.Popen([exe, '-hide_banner', '-loglevel', 'error',
                '-f', 'lavfi', '-i', 'testsrc2=size=64x36:rate=12',
                '-f', 'null', '-'], stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            processes.append(process)
            pool.attach(1, process)
            started.set()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill();process.wait(timeout=4)
            finally:
                pool.detach(1, process)
        pool.submit(1, job)
        self.assertTrue(started.wait(5), 'ffmpeg failed to launch')
        pool.shutdown()
        self.assertEqual(len(processes), 1)
        self.assertIsNotNone(processes[0].poll())
        self.assertFalse(pool.processes)

    def test_minterpolate_ffmpeg_produces_frames(self):
        exe=imageio_ffmpeg.get_ffmpeg_exe()
        with tempfile.TemporaryDirectory() as td:
            file=str(Path(td)/'input.mp4')
            created=subprocess.run([exe,'-hide_banner','-loglevel','error','-f','lavfi',
               '-i','testsrc2=size=64x36:rate=12:duration=2.0','-c:v','mpeg4','-y',file],
               capture_output=True,timeout=20)
            self.assertEqual(created.returncode,0,created.stderr.decode(errors='replace'))
            spec=PreviewSpec(fps=60,speed=2.0,interpolate=True,width=64,height=36,segment_seconds=2)
            cmd=ffmpeg_command(exe,file,0,spec)
            with subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE) as child:
                stdout,stderr=child.communicate(timeout=30)
            self.assertEqual(child.returncode,0,stderr.decode(errors='replace'))
            frames=len(stdout)//(64*36*3)
            self.assertGreaterEqual(frames,48)  # ~60 30fps frames across two seconds


if __name__=='__main__':
    unittest.main(verbosity=2)
