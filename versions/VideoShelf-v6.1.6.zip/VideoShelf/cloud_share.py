from __future__ import annotations

CLOUDFLARE_SHARE_VERSION = "6.0.0"

MAX_RATING = 20

import base64
import hashlib
import html
import json
import mimetypes
import os
import platform
import queue
import re
import secrets
import socket
import ssl
import struct
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, Signal


WIN_FLAGS = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
CLOUDFLARED_PINNED_VERSION = "2026.9.1"
CLOUDFLARED_ASSET = "cloudflared-windows-amd64.exe"
CLOUDFLARED_SHA256 = "2837888cc0f5d58f15b6dc478376de90b4d3ba5241c7947455d1e0a0df429712"
CLOUDFLARED_OFFICIAL_URL = (
    f"https://github.com/cloudflare/cloudflared/releases/download/{CLOUDFLARED_PINNED_VERSION}/"
    f"{CLOUDFLARED_ASSET}"
)
# v4.3 ships the verified official Windows x64 binary inside tools/cloudflared.exe.
# Normal startup performs NO cloudflared download.
CLOUDFLARED_BUNDLED = True



def _human_size(num: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(max(0, num))
    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit in ("GB", "TB"):
                return f"{value:.2f} {unit}"
            if unit == "MB":
                return f"{value:.1f} {unit}"
            return f"{value:.0f} {unit}"
        value /= 1024
    return f"{num} B"


def _human_duration(seconds: float) -> str:
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _video_id(path: str) -> str:
    return hashlib.sha1(path.encode("utf-8", errors="ignore")).hexdigest()[:24]


def _run_hidden(cmd, **kwargs):
    kwargs.setdefault("creationflags", WIN_FLAGS)
    return subprocess.run(cmd, **kwargs)


class ByteLRU:
    """Small in-memory byte cache. Never writes preview/poster files to disk."""

    def __init__(self, max_bytes: int = 256 * 1024 * 1024):
        self.max_bytes = max_bytes
        self._items: OrderedDict[str, bytes] = OrderedDict()
        self._size = 0
        self._lock = threading.RLock()

    def get(self, key: str) -> Optional[bytes]:
        with self._lock:
            value = self._items.pop(key, None)
            if value is None:
                return None
            self._items[key] = value
            return value

    def put(self, key: str, value: bytes):
        if not value:
            return
        with self._lock:
            old = self._items.pop(key, None)
            if old is not None:
                self._size -= len(old)
            self._items[key] = value
            self._size += len(value)
            while self._size > self.max_bytes and self._items:
                _, victim = self._items.popitem(last=False)
                self._size -= len(victim)

    def clear(self):
        with self._lock:
            self._items.clear()
            self._size = 0


class WebLibraryState:
    def __init__(self, ffmpeg_path: str, ram_cache_mb: int = 256):
        self.ffmpeg_path = ffmpeg_path
        self.token = secrets.token_urlsafe(24)
        self.token_expires_at = 0.0
        self.expire_minutes = 240
        self._password_salt = secrets.token_bytes(16)
        self._password_digest = b''
        self._verified_credentials = set()
        self._lock = threading.RLock()
        self._videos: list[dict] = []
        self._by_id: dict[str, dict] = {}
        self.cache = ByteLRU(ram_cache_mb * 1024 * 1024)
        self.poster_slots = threading.BoundedSemaphore(4)
        self.preview_slots = threading.BoundedSemaphore(2)
        self.transcode_slots = threading.BoundedSemaphore(2)

    def set_password(self, password: str):
        # Password is never written to config.json or included in public URLs.
        self._password_salt = secrets.token_bytes(16)
        self._verified_credentials.clear()
        self._password_digest = (hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                                  self._password_salt, 200000) if password else b'')

    def verify_password(self, password: str) -> bool:
        if not self._password_digest:
            return True
        encoded = password.encode('utf-8')
        # Cache only *successful* authentication per live share session; browser
        # requests for 100 posters must not each redo 200k PBKDF2 iterations.
        fingerprint = hashlib.sha256(self._password_salt + encoded).digest()
        with self._lock:
            if fingerprint in self._verified_credentials:
                return True
        digest = hashlib.pbkdf2_hmac('sha256', encoded, self._password_salt, 200000)
        correct = secrets.compare_digest(self._password_digest, digest)
        if correct:
            with self._lock:
                if len(self._verified_credentials) >= 16:
                    self._verified_credentials.clear()
                self._verified_credentials.add(fingerprint)
        return correct

    def update_videos(self, videos: list[dict]):
        clean = []
        by_id = {}
        for raw in videos or []:
            path = str(raw.get("path") or "")
            if not path:
                continue
            p = Path(path)
            try:
                if not p.is_file():
                    continue
            except OSError:
                continue
            vid = _video_id(path)
            item = {
                "id": vid,
                "path": path,
                "name": str(raw.get("name") or p.name),
                "size": int(raw.get("size") or 0),
                "duration": float(raw.get("duration") or 0.0),
                "width": int(raw.get("width") or 0),
                "height": int(raw.get("height") or 0),
                "mtime": float(raw.get("mtime") or 0.0),
                "rating": max(0, min(MAX_RATING, int(raw.get("rating") or 0))),
                "favorite": bool(raw.get("favorite", False)),
            }
            clean.append(item)
            by_id[vid] = item
        with self._lock:
            self._videos = clean
            self._by_id = by_id

    @staticmethod
    def _public_item(item: dict) -> dict:
        resolution = ''
        if item['width'] and item['height']:
            resolution = f"{item['width']}×{item['height']}"
        return {
            'id': item['id'], 'name': item['name'],
            'size': item['size'], 'sizeText': _human_size(item['size']),
            'duration': item['duration'],
            'durationText': _human_duration(item['duration']) if item['duration'] else '',
            'resolution': resolution, 'mtime': item['mtime'],
            'rating': int(item.get('rating') or 0),
            'favorite': bool(item.get('favorite', False)),
        }

    def public_items(self) -> list[dict]:
        # Legacy client API; new browser uses public_page() instead.
        with self._lock:
            return [self._public_item(v) for v in self._videos]

    def public_page(self, page: int = 0, limit: int = 80, search: str = '',
                    rating: int = 0, kind: str = 'all', sort: str = 'name') -> dict:
        """Server-side filtering and pagination avoid 50k-item JSON responses."""
        page = max(0, min(1_000_000, int(page)))
        limit = max(1, min(150, int(limit)))
        needle = str(search or '').casefold()[:160]
        rating = max(0, min(MAX_RATING, int(rating)))
        with self._lock:
            source = list(self._videos)
        filtered = []
        for item in source:
            if needle and needle not in item['name'].casefold():
                continue
            if int(item.get('rating') or 0) < rating:
                continue
            if kind == 'favorites' and not item.get('favorite'):
                continue
            if kind == '1080' and int(item.get('height') or 0) < 1080:
                continue
            if kind == '2160' and int(item.get('height') or 0) < 2160:
                continue
            filtered.append(item)
        if sort == 'rating':
            filtered.sort(key=lambda v: (-int(v.get('rating') or 0), v['name'].casefold()))
        elif sort == 'size':
            filtered.sort(key=lambda v: -int(v.get('size') or 0))
        elif sort == 'duration':
            filtered.sort(key=lambda v: -float(v.get('duration') or 0))
        elif sort == 'date':
            filtered.sort(key=lambda v: -float(v.get('mtime') or 0))
        else:
            filtered.sort(key=lambda v: v['name'].casefold())
        total = len(filtered)
        offset = page * limit
        return {
            'videos': [self._public_item(v) for v in filtered[offset:offset + limit]],
            'total': total, 'page': page, 'limit': limit,
            'hasMore': offset + limit < total,
        }

    def get(self, vid: str) -> Optional[dict]:
        with self._lock:
            item = self._by_id.get(vid)
            return dict(item) if item else None

    def _probe_duration(self, item: dict) -> float:
        if item.get("duration", 0) > 0:
            return float(item["duration"])
        try:
            proc = _run_hidden(
                [self.ffmpeg_path, "-hide_banner", "-i", item["path"]],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=30,
            )
            m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", proc.stderr or "")
            if m:
                return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
        except Exception:
            pass
        return 30.0

    def poster_bytes(self, item: dict) -> bytes:
        key = f'poster:{item["id"]}:{item.get("mtime", 0)}'
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        with self.poster_slots:
            cached = self.cache.get(key)
            if cached is not None:
                return cached
            cmd = [
                self.ffmpeg_path, "-hide_banner", "-loglevel", "error",
                "-ss", "2.0", "-i", item["path"],
                "-frames:v", "1", "-vf", "scale=480:-2",
                "-q:v", "5", "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1",
            ]
            try:
                proc = _run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
                if proc.returncode != 0 or not proc.stdout:
                    cmd[5] = "0.1"
                    proc = _run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
                data = proc.stdout if proc.returncode == 0 else b""
            except Exception:
                data = b""
            if data:
                self.cache.put(key, data)
            return data

    def preview_mp4_bytes(self, item: dict) -> bytes:
        key = f'preview:{item["id"]}:{item.get("mtime", 0)}'
        cached = self.cache.get(key)
        if cached is not None:
            return cached

        with self.preview_slots:
            # Re-check after waiting for a slot.
            cached = self.cache.get(key)
            if cached is not None:
                return cached

            duration = self._probe_duration(item)
            anchors = (0.05, 0.27, 0.50, 0.73, 0.95)
            starts = [min(max(0.0, duration * r), max(0.0, duration - 2.05)) for r in anchors]

            cmd = [self.ffmpeg_path, "-hide_banner", "-loglevel", "error"]
            for start in starts:
                cmd += ["-ss", f"{start:.3f}", "-t", "2.0", "-i", item["path"]]

            chains = []
            labels = []
            for i in range(5):
                label = f"v{i}"
                chains.append(
                    f"[{i}:v]fps=5,scale=480:-2:force_original_aspect_ratio=decrease,"
                    f"pad=480:270:(ow-iw)/2:(oh-ih)/2:black,setsar=1,setpts=PTS-STARTPTS[{label}]"
                )
                labels.append(f"[{label}]")
            chains.append("".join(labels) + "concat=n=5:v=1:a=0,format=yuv420p[vout]")

            cmd += [
                "-filter_complex", ";".join(chains),
                "-map", "[vout]", "-an",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "31",
                "-movflags", "frag_keyframe+empty_moov+default_base_moof",
                "-f", "mp4", "pipe:1",
            ]
            try:
                proc = _run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
                data = proc.stdout if proc.returncode == 0 else b""
            except Exception:
                data = b""
            if data:
                self.cache.put(key, data)
            return data


class VideoHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, handler_class, state: WebLibraryState):
        self.state = state
        super().__init__(server_address, handler_class)


class LibraryRequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "VideoShelfWeb/1.0"

    def log_message(self, format, *args):
        # Keep cloud share quiet inside the desktop app.
        return

    @property
    def state(self) -> WebLibraryState:
        return self.server.state

    def _parsed(self):
        return urllib.parse.urlsplit(self.path)

    def _token_ok(self, parsed=None) -> bool:
        parsed = parsed or self._parsed()
        query = urllib.parse.parse_qs(parsed.query)
        token = (query.get("token") or [""])[0]
        return (secrets.compare_digest(token, self.state.token)
                and (not self.state.token_expires_at or time.time() < self.state.token_expires_at))

    def _password_ok(self):
        if not self.state._password_digest:
            return True
        header = self.headers.get('Authorization', '')
        if not header.startswith('Basic '):
            return False
        try:
            decoded = base64.b64decode(header[6:].strip(), validate=True).decode('utf-8')
            # Username ignored, only the password is used.
            return self.state.verify_password(decoded.partition(':')[2])
        except (ValueError, UnicodeError):
            return False

    def _request_password(self, head_only=False):
        data = b'Authentication required'
        self.send_response(401)
        self.send_header('WWW-Authenticate', 'Basic realm="VideoShelf Library", charset="UTF-8"')
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self._common_headers()
        self.end_headers()
        if not head_only:
            self.wfile.write(data)

    def _common_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")

    def _send_bytes(self, data: bytes, content_type: str, status=200, head_only=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self._common_headers()
        self.end_headers()
        if not head_only:
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _send_json(self, obj, status=200, head_only=False):
        data = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._send_bytes(data, "application/json; charset=utf-8", status, head_only)

    def _deny(self, head_only=False):
        body = (
            "<!doctype html><meta charset='utf-8'><title>VideoShelf</title>"
            "<style>body{background:#0b0d11;color:#fff;font-family:Segoe UI;padding:40px}</style>"
            "<h2>لینک دسترسی معتبر نیست</h2><p>لینک کامل را از داخل برنامه VideoShelf کپی کنید.</p>"
        ).encode("utf-8")
        self._send_bytes(body, "text/html; charset=utf-8", 403, head_only)

    def do_HEAD(self):
        self._dispatch(head_only=True)

    def do_GET(self):
        self._dispatch(head_only=False)

    def _dispatch(self, head_only=False):
        parsed = self._parsed()
        path = urllib.parse.unquote(parsed.path)

        if path == "/health":
            return self._send_json({"ok": True}, head_only=head_only)

        if not self._token_ok(parsed):
            return self._deny(head_only)
        if not self._password_ok():
            return self._request_password(head_only)

        if path == "/" or path == "/index.html":
            body = WEB_HTML.encode("utf-8")
            return self._send_bytes(body, "text/html; charset=utf-8", head_only=head_only)

        if path == "/api/videos":
            # Preserve original all-videos API when page is omitted.
            args = urllib.parse.parse_qs(parsed.query)
            if 'page' in args:
                try:
                    page = int((args.get('page') or ['0'])[0])
                    limit = int((args.get('limit') or ['80'])[0])
                    rating = int((args.get('rating') or ['0'])[0])
                except (TypeError, ValueError):
                    return self._send_json({'error': 'Invalid pagination'}, 400, head_only)
                return self._send_json(self.state.public_page(
                    page=page, limit=limit,
                    search=(args.get('q') or [''])[0],
                    rating=rating,
                    kind=(args.get('kind') or ['all'])[0],
                    sort=(args.get('sort') or ['name'])[0],
                ), head_only=head_only)
            return self._send_json({'videos': self.state.public_items()}, head_only=head_only)

        m = re.fullmatch(r"/poster/([0-9a-f]{24})\.jpg", path)
        if m:
            item = self.state.get(m.group(1))
            if not item:
                return self._send_bytes(b"", "text/plain", 404, head_only)
            data = self.state.poster_bytes(item)
            if not data:
                return self._send_bytes(b"", "text/plain", 404, head_only)
            return self._send_bytes(data, "image/jpeg", head_only=head_only)

        m = re.fullmatch(r"/preview/([0-9a-f]{24})\.mp4", path)
        if m:
            item = self.state.get(m.group(1))
            if not item:
                return self._send_bytes(b"", "text/plain", 404, head_only)
            data = self.state.preview_mp4_bytes(item)
            if not data:
                return self._send_bytes(b"", "text/plain", 503, head_only)
            return self._send_bytes(data, "video/mp4", head_only=head_only)

        m = re.fullmatch(r"/media/([0-9a-f]{24})", path)
        if m:
            item = self.state.get(m.group(1))
            if not item:
                return self._send_bytes(b"", "text/plain", 404, head_only)
            return self._serve_media(item, head_only=head_only)

        m = re.fullmatch(r"/transcode/([0-9a-f]{24})", path)
        if m:
            item = self.state.get(m.group(1))
            if not item:
                return self._send_bytes(b"", "text/plain", 404, head_only)
            if head_only:
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4")
                self._common_headers()
                self.end_headers()
                return
            return self._serve_transcode(item)

        self._send_bytes(b"Not found", "text/plain; charset=utf-8", 404, head_only)

    def _serve_media(self, item: dict, head_only=False):
        path = Path(item["path"])
        try:
            size = path.stat().st_size
        except OSError:
            return self._send_bytes(b"", "text/plain", 404, head_only)

        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        range_header = self.headers.get("Range", "")
        start = 0
        end = size - 1
        status = 200

        if range_header:
            m = re.match(r"bytes=(\d*)-(\d*)", range_header.strip())
            if m:
                left, right = m.groups()
                try:
                    if left:
                        start = int(left)
                        end = int(right) if right else size - 1
                    elif right:
                        suffix = int(right)
                        start = max(0, size - suffix)
                        end = size - 1
                    if start >= size or start < 0 or end < start:
                        self.send_response(416)
                        self.send_header("Content-Range", f"bytes */{size}")
                        self.end_headers()
                        return
                    end = min(end, size - 1)
                    status = 206
                except ValueError:
                    start, end, status = 0, size - 1, 200

        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        safe_name = urllib.parse.quote(path.name)
        self.send_header("Content-Disposition", f"inline; filename*=UTF-8''{safe_name}")
        self._common_headers()
        self.end_headers()
        if head_only:
            return

        try:
            with path.open("rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def _serve_transcode(self, item: dict):
        # Browser fallback for containers/codecs it cannot decode directly.
        if not self.state.transcode_slots.acquire(timeout=20):
            return self._send_bytes(b"Busy", "text/plain", 503)
        proc = None
        try:
            cmd = [
                self.state.ffmpeg_path, "-hide_banner", "-loglevel", "error",
                "-i", item["path"],
                "-map", "0:v:0", "-map", "0:a:0?",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "27",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "128k", "-ac", "2",
                "-movflags", "frag_keyframe+empty_moov+default_base_moof",
                "-f", "mp4", "pipe:1",
            ]
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                creationflags=WIN_FLAGS,
                bufsize=1024 * 1024,
            )
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Connection", "close")
            self.send_header("Accept-Ranges", "none")
            self._common_headers()
            self.end_headers()
            while True:
                chunk = proc.stdout.read(256 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            if proc is not None and proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
            self.state.transcode_slots.release()


class LocalWebLibrary:
    def __init__(self, ffmpeg_path: str, ram_cache_mb: int = 256):
        self.state = WebLibraryState(ffmpeg_path, ram_cache_mb)
        self.server: Optional[VideoHTTPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.port = 0

    def update_videos(self, videos: list[dict]):
        self.state.update_videos(videos)

    def start(self) -> int:
        if self.server:
            return self.port
        # New share session = new access token. Old copied URLs are invalid after restart.
        self.state.token = secrets.token_urlsafe(24)
        self.state.token_expires_at = time.time() + max(5, int(self.state.expire_minutes)) * 60
        self.server = VideoHTTPServer(("127.0.0.1", 0), LibraryRequestHandler, self.state)
        self.port = int(self.server.server_address[1])
        self.thread = threading.Thread(target=self.server.serve_forever, name="VideoShelfWeb", daemon=True)
        self.thread.start()
        return self.port

    def stop(self):
        server = self.server
        self.server = None
        if server:
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass
        self.state.cache.clear()
        self.state.token_expires_at = 0.0
        self.state.token = secrets.token_urlsafe(24)
        self.port = 0

    @property
    def token(self) -> str:
        return self.state.token


class CloudShareManager(QObject):
    status_changed = Signal(str)
    url_changed = Signal(str)
    download_progress = Signal(int)
    running_changed = Signal(bool)
    error = Signal(str)
    cloudflared_version = Signal(str)
    provider_changed = Signal(str)
    log_line = Signal(str)
    log_reset = Signal()
    diagnostics_result = Signal(object)

    MIN_NATIVE_PRECHECK = (2026, 5, 2)
    STARTUP_TIMEOUT = 65.0
    PUBLIC_VERIFY_TIMEOUT = 22.0
    READY_POLL_INTERVAL = 0.75
    MONITOR_INTERVAL = 15.0

    def __init__(self, root: Path, ffmpeg_path: str, parent=None):
        super().__init__(parent)
        self.root = Path(root)
        self.tools_dir = self.root / "tools"
        self.cloudflared_path = self.tools_dir / "cloudflared.exe"
        self.ffmpeg_path = ffmpeg_path
        self.web = LocalWebLibrary(ffmpeg_path)
        self._videos: list[dict] = []
        self._lock = threading.RLock()
        self._worker_lock = threading.Lock()
        self._diagnostics_lock = threading.Lock()
        self._diagnostics_running = False
        self._tunnel_proc: Optional[subprocess.Popen] = None
        self._public_base_url = ""
        self._metrics_base = ""
        self._stopping = False
        self._desired_running = False
        self._reconnect_pending = False
        self._generation = 0
        self._log_lock = threading.RLock()
        self._log_tail: list[str] = []
        self._log_file: Optional[Path] = None
        self._session_started = 0.0
        self._tunnel_flags: set[str] = set()
        self._provider = ""
        self._restart_count = 0
        self._last_stable_since = 0.0
        self._blocked_network = False
        self._warp_assist_requested = False
        self._last_transport_precheck = {"quic": None, "http2": None, "dns": None, "hard_fail": False, "time": 0.0}

    # ---------- public API ----------

    def update_library(self, videos: list[dict]):
        with self._lock:
            self._videos = list(videos or [])
        self.web.update_videos(self._videos)

    def _begin_start(self, warp_assist: bool = False):
        self._desired_running = True
        self._stopping = False
        self._blocked_network = False
        self._warp_assist_requested = bool(warp_assist)
        self._last_transport_precheck = {"quic": None, "http2": None, "dns": None, "hard_fail": False, "time": time.time()}

        proc = self._tunnel_proc
        if proc and proc.poll() is None and self._public_base_url:
            self.url_changed.emit(self.public_url())
            self.running_changed.emit(True)
            return

        if self._diagnostics_running or self._diagnostics_lock.locked():
            self.status_changed.emit("تست شبکه Cloudflare در حال اجراست؛ بعد از پایان تست Start را بزنید.")
            self.error.emit("برای جلوگیری از ساخت Quick Tunnel تستی هم‌زمان، ابتدا تست شبکه را تمام کنید و سپس Tunnel را شروع کنید.")
            self._desired_running = False
            self._warp_assist_requested = False
            return

        if self._worker_lock.locked():
            self.status_changed.emit("Cloudflare از قبل در حال راه‌اندازی است…")
            return

        name = "CloudShareStartWARP" if warp_assist else "CloudShareStart"
        threading.Thread(target=self._start_worker, name=name, daemon=True).start()

    def start_share(self):
        self._begin_start(False)

    def start_share_with_warp(self):
        """Explicit Cloudflare-only rescue path for networks that block cloudflared/7844.

        This is intentionally opt-in because enabling WARP changes the device's network path.
        If the official Cloudflare WARP client is installed, VideoShelf asks it to connect,
        verifies warp=on, and only then retries cloudflared.
        """
        self._begin_start(True)

    def stop_share(self):
        self._desired_running = False
        self._stopping = True
        self._reconnect_pending = False
        self._blocked_network = False
        self._generation += 1

        proc = self._tunnel_proc
        self._tunnel_proc = None
        self._provider = ""
        self._metrics_base = ""
        self._stop_process(proc)

        self.web.stop()
        self._public_base_url = ""
        self.url_changed.emit("")
        self.provider_changed.emit("")
        self._own_log("Tunnel stopped by user")
        self.status_changed.emit("اشتراک‌گذاری خاموش است")
        self.running_changed.emit(False)
        self._stopping = False
        self._restart_count = 0
        self._warp_assist_requested = False

    def run_network_diagnostics(self):
        # Reserve the diagnostics slot synchronously so Start cannot race with the
        # background thread before it acquires its lock. Python locks may be
        # released by the worker thread after completion.
        if not self._diagnostics_lock.acquire(blocking=False):
            self.status_changed.emit("تست شبکه از قبل در حال اجراست…")
            return
        self._diagnostics_running = True

        def worker():
            try:
                self.status_changed.emit("در حال اجرای تست کامل شبکه Cloudflare…")
                self.diagnostics_result.emit({"phase": "running"})
                self._own_log("===== Manual Cloudflare diagnostics requested =====")
                self._ensure_cloudflared()

                # If a real Tunnel is already starting/running, never create a second
                # temporary Quick Tunnel. Reuse the real cloudflared logs/precheck.
                proc = self._tunnel_proc
                share_busy = self._worker_lock.locked() or (proc is not None and proc.poll() is None) or self._desired_running
                if share_busy:
                    self._own_log("Diagnostics mode: REAL-TUNNEL evidence only; temporary Quick Tunnel probe disabled")
                else:
                    self._own_log("Diagnostics mode: standalone; one temporary transport probe may be used if real evidence is unavailable")

                report = self._network_diagnostics(allow_temporary_transport_probe=not share_busy)
                self.diagnostics_result.emit(report)
                verdict = report.get("verdict", "")
                self.status_changed.emit(verdict or "تست شبکه Cloudflare تمام شد")
            except Exception as exc:
                self._own_log(f"Manual diagnostics failed: {exc}")
                self.status_changed.emit("تست شبکه ناموفق بود")
                self.diagnostics_result.emit({
                    "phase": "done", "items": {},
                    "verdict": f"خطا در اجرای تست: {exc}",
                    "verdict_state": "fail", "error": str(exc),
                })
                self.error.emit(str(exc))
            finally:
                self._diagnostics_running = False
                try:
                    self._diagnostics_lock.release()
                except RuntimeError:
                    pass

        threading.Thread(target=worker, name="CloudflareDiagnostics", daemon=True).start()

    def redownload_cloudflared(self):
        """Verify the bundled official cloudflared binary.

        Kept under the old signal name for UI compatibility. v4.3 intentionally
        does not delete or download cloudflared during normal operation.
        """
        def worker():
            if self._tunnel_proc and self._tunnel_proc.poll() is None:
                self.error.emit("برای بررسی cloudflared ابتدا اشتراک‌گذاری را متوقف کنید.")
                return
            try:
                self._ensure_cloudflared(force=True)
                self.status_changed.emit("cloudflared داخلی رسمی بررسی شد و آماده است")
            except Exception as exc:
                self.error.emit(str(exc))

        threading.Thread(target=worker, name="CloudflaredVerify", daemon=True).start()

    @staticmethod
    def _find_warp_cli() -> Optional[Path]:
        if os.name != "nt":
            return None
        candidates = []
        for env_name in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(Path(base) / "Cloudflare" / "Cloudflare WARP" / "warp-cli.exe")
        # Common consumer/Zero Trust installation path.
        candidates.append(Path(r"C:\Program Files\Cloudflare\Cloudflare WARP\warp-cli.exe"))
        for candidate in candidates:
            try:
                if candidate.exists():
                    return candidate
            except OSError:
                pass
        # PATH fallback without importing shutil just for this lookup.
        for folder in os.environ.get("PATH", "").split(os.pathsep):
            if not folder:
                continue
            candidate = Path(folder) / "warp-cli.exe"
            try:
                if candidate.exists():
                    return candidate
            except OSError:
                pass
        return None

    def _run_warp_cli(self, cli: Path, args: list[str], timeout: float = 20.0) -> tuple[int, str]:
        try:
            cp = _run_hidden(
                [str(cli), *args],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
            out = (cp.stdout or "").strip()
            self._own_log(f"WARP CLI: {' '.join(args)} -> exit={cp.returncode}")
            if out:
                for line in out.splitlines()[-12:]:
                    self._own_log(f"WARP: {line}")
            return cp.returncode, out
        except subprocess.TimeoutExpired:
            self._own_log(f"WARP CLI timeout: {' '.join(args)}")
            return 124, "timeout"
        except Exception as exc:
            self._own_log(f"WARP CLI failed: {' '.join(args)} -> {type(exc).__name__}: {exc}")
            return 125, str(exc)

    @staticmethod
    def _trace_warp_state(timeout: float = 8.0) -> tuple[bool, str]:
        req = urllib.request.Request(
            "https://www.cloudflare.com/cdn-cgi/trace",
            headers={"User-Agent": "VideoShelf-WARP-Check/4.4"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                text = resp.read(65536).decode("utf-8", errors="replace")
            fields = {}
            for line in text.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    fields[k.strip().lower()] = v.strip()
            state = fields.get("warp", "").lower()
            return state == "on", f"warp={state or 'unknown'} colo={fields.get('colo','?')} ip={fields.get('ip','?')}"
        except Exception as exc:
            return False, f"trace failed: {type(exc).__name__}: {exc}"

    def _prepare_warp_assist(self) -> tuple[bool, str]:
        """Turn on the *official installed* Cloudflare WARP client after explicit user request."""
        if os.name != "nt":
            return False, "Cloudflare WARP rescue در این نسخه فقط برای Windows است."
        cli = self._find_warp_cli()
        if not cli:
            return False, (
                "Cloudflare WARP روی Windows نصب نیست. برنامه عمداً WARP را مخفیانه دانلود یا نصب نمی‌کند. "
                "نسخه رسمی Cloudflare WARP را نصب کنید، یک بار شرایط آن را تأیید کنید، سپس دکمه WARP Rescue را دوباره بزنید."
            )

        self._own_log(f"===== Cloudflare WARP rescue requested; warp-cli={cli} =====")
        self.status_changed.emit("Cloudflare WARP: در حال بررسی و اتصال از مسیر MASQUE/443…")

        # Use only commands that the installed client advertises. Different WARP generations
        # have slightly different CLI surfaces, so unsupported tuning is non-fatal.
        _, help_text = self._run_warp_cli(cli, ["--help"], timeout=10)
        low_help = help_text.lower()

        # Prefer MASQUE because Cloudflare documents UDP/443 with several fallback ports,
        # including TCP/443, for the Cloudflare One Client. Failure to set it is not fatal;
        # recent clients already default to MASQUE.
        if "tunnel" in low_help and "protocol" in low_help:
            self._run_warp_cli(cli, ["tunnel", "protocol", "set", "MASQUE"], timeout=15)

        # On clients that expose the modern `mode` command, ensure full traffic (not DNS-only).
        if "mode" in low_help:
            code, out = self._run_warp_cli(cli, ["mode", "warp+doh"], timeout=15)
            if code != 0:
                # Some Windows consumer versions use a shorter mode value.
                self._run_warp_cli(cli, ["mode", "warp"], timeout=15)

        code, out = self._run_warp_cli(cli, ["connect"], timeout=20)
        if code != 0:
            return False, (
                "warp-cli نتوانست WARP را وصل کند. اگر برنامه Cloudflare WARP تازه نصب شده، "
                "یک بار خود برنامه WARP را باز کنید و ثبت/شرایط استفاده را کامل کنید.\n" + out[-1200:]
            )

        deadline = time.monotonic() + 25.0
        last = ""
        while time.monotonic() < deadline and self._desired_running and not self._stopping:
            _, status = self._run_warp_cli(cli, ["status"], timeout=6)
            last = status
            if "connected" in status.lower() and "disconnected" not in status.lower():
                on, detail = self._trace_warp_state(timeout=8)
                self._own_log(f"WARP trace: {detail}")
                if on:
                    self.provider_changed.emit("Cloudflare WARP/MASQUE → Cloudflare Quick Tunnel")
                    self.status_changed.emit("Cloudflare WARP فعال شد؛ Tunnel دوباره از داخل WARP امتحان می‌شود…")
                    return True, detail
            time.sleep(1.5)

        on, detail = self._trace_warp_state(timeout=8)
        self._own_log(f"WARP final trace: {detail}")
        if on:
            self.provider_changed.emit("Cloudflare WARP/MASQUE → Cloudflare Quick Tunnel")
            return True, detail
        return False, f"WARP به حالت فعال نرسید. status={last[-900:]} | {detail}"

    def repair_windows_firewall(self):
        """Create the minimum Windows Defender Firewall egress rules cloudflared needs.

        This never opens inbound ports.  Rules are restricted to the exact cloudflared.exe
        path and are recreated by stable names, so repeated clicks stay idempotent.
        """
        def worker():
            if os.name != "nt":
                self.error.emit("اصلاح خودکار Firewall فقط روی Windows پشتیبانی می‌شود.")
                return
            try:
                self.status_changed.emit("در حال آماده‌سازی cloudflared و درخواست دسترسی Administrator…")
                self._own_log("===== Windows Firewall auto-fix requested =====")
                self._ensure_cloudflared()

                exe = str(self.cloudflared_path.resolve()).replace("'", "''")
                rules = (
                    ("VideoShelf Cloudflare TCP 7844", "TCP", "7844"),
                    ("VideoShelf Cloudflare UDP 7844", "UDP", "7844"),
                    ("VideoShelf Cloudflare TCP 443", "TCP", "443"),
                )

                lines = [
                    "$ErrorActionPreference = 'Stop'",
                    f"$exe = '{exe}'",
                    "if (-not (Test-Path -LiteralPath $exe)) { throw 'cloudflared.exe not found' }",
                ]
                for name, proto, port in rules:
                    desc = "VideoShelf Cloudflare outbound rule - no inbound port is opened"
                    lines += [
                        f"Get-NetFirewallRule -DisplayName '{name}' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue",
                        (
                            f"New-NetFirewallRule -DisplayName '{name}' -Description '{desc}' "
                            f"-Direction Outbound -Action Allow -Enabled True -Profile Any "
                            f"-Program $exe -Protocol {proto} -RemotePort {port} | Out-Null"
                        ),
                    ]
                lines += [
                    "$created = @()",
                    "foreach ($n in @('VideoShelf Cloudflare TCP 7844','VideoShelf Cloudflare UDP 7844','VideoShelf Cloudflare TCP 443')) {",
                    "  $r = Get-NetFirewallRule -DisplayName $n -ErrorAction SilentlyContinue",
                    "  if ($null -eq $r) { throw ('Firewall rule was not created: ' + $n) }",
                    "  $created += $n",
                    "}",
                    "Write-Output ('VIDEOSHELF_FIREWALL_OK:' + ($created -join ','))",
                ]
                inner = "\r\n".join(lines)
                encoded = base64.b64encode(inner.encode("utf-16le")).decode("ascii")

                ps_exe = str(Path(os.environ.get("SystemRoot", r"C:\\Windows")) /
                             "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe")
                if not Path(ps_exe).exists():
                    ps_exe = "powershell.exe"

                # Use a non-elevated launcher only to request UAC for the small encoded rule script.
                # Start-Process -Verb RunAs is the standard Windows elevation path.
                quoted_ps = ps_exe.replace("'", "''")
                outer = (
                    "$ErrorActionPreference='Stop'; "
                    f"$p=Start-Process -FilePath '{quoted_ps}' "
                    f"-ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand','{encoded}') "
                    "-Verb RunAs -Wait -PassThru; exit $p.ExitCode"
                )
                result = _run_hidden(
                    [ps_exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", outer],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=120,
                )
                output = (result.stdout or "").strip()
                if output:
                    for line in output.splitlines()[-20:]:
                        self._own_log(f"Firewall: {line}")
                if result.returncode != 0:
                    raise RuntimeError(
                        "ساخت Ruleهای Windows Firewall انجام نشد. اگر پنجره UAC را Cancel کردید، دوباره دکمه را بزنید."
                    )

                self._own_log(
                    "Firewall rules installed: cloudflared TCP/7844 OUT, UDP/7844 OUT, TCP/443 OUT. "
                    "No inbound rule was created."
                )
                self.status_changed.emit("Firewall ویندوز برای Cloudflare اصلاح شد؛ حالا Tunnel را شروع کنید.")
            except subprocess.TimeoutExpired:
                self._own_log("Firewall auto-fix timed out while waiting for UAC/PowerShell")
                self.error.emit("مهلت اصلاح Firewall تمام شد. پنجره UAC را بررسی کنید و دوباره امتحان کنید.")
            except Exception as exc:
                self._own_log(f"Firewall auto-fix failed: {type(exc).__name__}: {exc}")
                self.status_changed.emit("اصلاح Firewall انجام نشد")
                self.error.emit(str(exc))

        threading.Thread(target=worker, name="CloudflareFirewallFix", daemon=True).start()

    def public_url(self) -> str:
        if not self._public_base_url:
            return ""
        return f"{self._public_base_url}/?token={urllib.parse.quote(self.web.token)}"

    def local_url(self) -> str:
        if not self.web.port:
            return ""
        return f"http://127.0.0.1:{self.web.port}/?token={urllib.parse.quote(self.web.token)}"

    # ---------- cloudflared binary ----------

    def _ensure_cloudflared(self, force=False):
        """Validate the bundled cloudflared.exe; never download on startup."""
        self.tools_dir.mkdir(parents=True, exist_ok=True)
        path = self.cloudflared_path
        if not path.exists():
            raise RuntimeError(
                "cloudflared.exe داخلی پیدا نشد. این نسخه باید فایل رسمی را داخل "
                "VideoShelf\\tools\\cloudflared.exe داشته باشد؛ ZIP را کامل Extract کنید."
            )
        size = path.stat().st_size
        if size < 5 * 1024 * 1024:
            raise RuntimeError(f"cloudflared.exe داخلی ناقص است (size={size} bytes). ZIP را دوباره Extract کنید.")

        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
        actual_sha = digest.hexdigest().lower()
        if actual_sha != CLOUDFLARED_SHA256.lower():
            raise RuntimeError(
                "cloudflared.exe داخلی تغییر کرده یا خراب است. "
                f"SHA-256={actual_sha}; expected={CLOUDFLARED_SHA256}"
            )
        if not self._cloudflared_is_valid():
            raise RuntimeError("cloudflared.exe داخلی وجود دارد ولی روی Windows اجرا نشد.")

        self.download_progress.emit(100)
        self._own_log(
            f"Bundled cloudflared verified; version={CLOUDFLARED_PINNED_VERSION}; sha256={actual_sha}"
        )
        self._emit_version()

    def _cloudflared_is_valid(self):
        try:
            proc = _run_hidden(
                [str(self.cloudflared_path), "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
            )
            return proc.returncode == 0 and "cloudflared" in (proc.stdout or "").lower()
        except Exception:
            return False

    def _version_text(self) -> str:
        proc = _run_hidden(
            [str(self.cloudflared_path), "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
        )
        return (proc.stdout or "").strip().splitlines()[0] if proc.stdout else ""

    def _version_tuple(self) -> tuple[int, int, int]:
        try:
            text = self._version_text()
            match = re.search(r"(20\d{2})\.(\d{1,2})\.(\d{1,3})", text)
            if match:
                return tuple(int(x) for x in match.groups())
        except Exception:
            pass
        return (0, 0, 0)

    def _emit_version(self):
        try:
            version = self._version_text()
            if version:
                self.cloudflared_version.emit(version)
        except Exception:
            pass

    def _tunnel_help_flags(self) -> set[str]:
        flags: set[str] = set()
        try:
            proc = _run_hidden(
                [str(self.cloudflared_path), "tunnel", "--help"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=15,
            )
            text = proc.stdout or ""
        except Exception as exc:
            self._own_log(f"cloudflared help inspection failed: {exc}")
            text = ""

        for name in (
            "protocol", "region", "edge-ip-version", "no-autoupdate",
            "loglevel", "retries", "metrics", "output", "url",
        ):
            if f"--{name}" in text:
                flags.add(name)
        return flags

    # ---------- local/public health ----------

    def _check_local_origin(self, port: int) -> bool:
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{port}/health",
                headers={"User-Agent": "VideoShelf/4.2-health"},
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                status = int(getattr(resp, "status", 0) or 0)
                self._own_log(f"Local origin health http://127.0.0.1:{port}/health -> {status}")
                return status == 200
        except Exception as exc:
            self._own_log(f"Local origin health FAILED -> {exc}")
            return False

    def _public_health(self, base_url: str, timeout=6):
        try:
            req = urllib.request.Request(
                f"{base_url.rstrip('/')}/health",
                headers={"User-Agent": "VideoShelf/4.2-health", "Cache-Control": "no-cache"},
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read(2048)
                status = int(getattr(resp, "status", 0) or 0)
                if status == 200 and b'"ok":true' in body.replace(b" ", b"").lower():
                    return True, "ok", "200"
                return False, f"http-{status}", body.decode("utf-8", errors="replace")[:500]
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read(4096).decode("utf-8", errors="replace")
            except Exception:
                body = ""
            if exc.code == 530 and ("1033" in body or "cloudflare tunnel error" in body.lower()):
                return False, "1033", body[:500]
            return False, f"http-{exc.code}", body[:500]
        except Exception as exc:
            return False, "network", f"{type(exc).__name__}: {exc}"

    # ---------- metrics/readiness ----------

    @staticmethod
    def _free_local_port() -> int:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])
        finally:
            sock.close()

    def _metrics_json(self, path: str, timeout=1.5):
        if not self._metrics_base:
            return None
        try:
            with urllib.request.urlopen(f"{self._metrics_base}{path}", timeout=timeout) as resp:
                raw = resp.read(65536)
                status = int(getattr(resp, "status", 0) or 0)
                if status != 200:
                    return None
                if not raw:
                    return {}
                try:
                    return json.loads(raw.decode("utf-8", errors="replace"))
                except Exception:
                    return {"_raw": raw.decode("utf-8", errors="replace")}
        except Exception:
            return None

    def _ready_connections(self) -> Optional[int]:
        if not self._metrics_base:
            return None
        try:
            req = urllib.request.Request(f"{self._metrics_base}/ready")
            with urllib.request.urlopen(req, timeout=1.5) as resp:
                if int(getattr(resp, "status", 0) or 0) != 200:
                    return 0
                raw = resp.read(32768)
                if not raw:
                    return 1
                try:
                    obj = json.loads(raw.decode("utf-8", errors="replace"))
                    if isinstance(obj, dict) and "readyConnections" in obj:
                        return max(0, int(obj.get("readyConnections") or 0))
                except Exception:
                    pass
                return 1
        except urllib.error.HTTPError as exc:
            if exc.code in (404, 503):
                return 0
            return None
        except Exception:
            return None

    def _quick_tunnel_url_from_metrics(self) -> str:
        payload = self._metrics_json("/quicktunnel")
        if not payload:
            return ""

        candidates = []
        if isinstance(payload, dict):
            for key in ("hostname", "url", "quickTunnel", "quick_tunnel"):
                value = payload.get(key)
                if value:
                    candidates.append(str(value))
            raw = payload.get("_raw")
            if raw:
                candidates.append(str(raw))
        else:
            candidates.append(str(payload))

        for value in candidates:
            match = re.search(r"(?:https://)?([a-z0-9-]+\.trycloudflare\.com)", value, re.I)
            if match:
                return "https://" + match.group(1).lower()
        return ""

    # ---------- logs ----------

    def _append_log(self, line: str):
        line = (line or "").strip()
        if not line:
            return
        with self._log_lock:
            self._log_tail.append(line)
            del self._log_tail[:-2500]
            log_file = self._log_file
        if log_file is not None:
            try:
                with log_file.open("a", encoding="utf-8", errors="replace") as handle:
                    handle.write(line + "\n")
            except Exception:
                pass
        try:
            self.log_line.emit(line)
        except Exception:
            pass

    def _own_log(self, message: str):
        stamp = time.strftime("%H:%M:%S")
        self._append_log(f"[VideoShelf {stamp}] {message}")

    def _recent_logs(self, count=40) -> str:
        with self._log_lock:
            return "\n".join(self._log_tail[-count:])

    def _prepare_session_log(self):
        try:
            log_dir = self.root / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d-%H%M%S")
            self._log_file = log_dir / f"cloudflare-{stamp}.log"
        except Exception:
            self._log_file = None

    @staticmethod
    def _log_message(raw_line: str) -> str:
        line = (raw_line or "").strip()
        if not line:
            return ""
        if line.startswith("{"):
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    return str(obj.get("message") or obj.get("msg") or obj.get("event") or line)
            except Exception:
                pass
        return line

    def _drain_output(self, proc: subprocess.Popen, line_queue: "queue.Queue[str]"):
        try:
            if not proc.stdout:
                return
            for raw in proc.stdout:
                line = raw.rstrip("\r\n")
                if not line:
                    continue
                self._append_log(line)
                try:
                    line_queue.put_nowait(line)
                except queue.Full:
                    try:
                        line_queue.get_nowait()
                    except queue.Empty:
                        pass
                    try:
                        line_queue.put_nowait(line)
                    except queue.Full:
                        pass
        except Exception as exc:
            self._append_log(f"log-reader: {exc}")
        finally:
            try:
                if proc.stdout:
                    proc.stdout.close()
            except Exception:
                pass

    def _check_windows_firewall_rules(self):
        """Inspect VideoShelf egress rules AND effective outbound profile policy.

        Dedicated allow rules are optional when Windows Firewall already allows outbound
        traffic by default. Missing VideoShelf rules must therefore never be treated as
        proof that Cloudflare is blocked.
        """
        if os.name != "nt":
            return {"state": "unknown", "summary": "فقط Windows", "detail": "Firewall inspection is Windows-only.", "blocking_policy": False}
        try:
            exe = str(self.cloudflared_path.resolve()).replace("'", "''")
            script = r'''
$ErrorActionPreference = 'Stop'
$exe = '__EXE__'
$names = @(
  'VideoShelf Cloudflare TCP 7844',
  'VideoShelf Cloudflare UDP 7844',
  'VideoShelf Cloudflare TCP 443'
)
$rows = @()
foreach ($n in $names) {
  $r = Get-NetFirewallRule -DisplayName $n -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($null -eq $r) {
    $rows += [pscustomobject]@{Name=$n; Present=$false; Good=$false; Info='missing'}
    continue
  }
  $pf = $r | Get-NetFirewallPortFilter | Select-Object -First 1
  $af = $r | Get-NetFirewallApplicationFilter | Select-Object -First 1
  $good = (($r.Enabled -eq 'True') -and ($r.Direction -eq 'Outbound') -and ($r.Action -eq 'Allow') -and ($af.Program -eq $exe))
  $rows += [pscustomobject]@{
    Name=$n; Present=$true; Good=$good;
    Info=('Enabled=' + $r.Enabled + '; Direction=' + $r.Direction + '; Action=' + $r.Action + '; Protocol=' + $pf.Protocol + '; RemotePort=' + ($pf.RemotePort -join ',') + '; Program=' + $af.Program)
  }
}
$profiles = @(Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultOutboundAction)
[pscustomobject]@{Rules=$rows; Profiles=$profiles} | ConvertTo-Json -Depth 5 -Compress
'''.replace('__EXE__', exe)
            ps_exe = str(Path(os.environ.get("SystemRoot", r"C:\\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe")
            if not Path(ps_exe).exists():
                ps_exe = "powershell.exe"
            cp = _run_hidden(
                [ps_exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                encoding="utf-8", errors="replace", timeout=15,
            )
            raw = (cp.stdout or "").strip()
            payload = json.loads(raw) if raw else {}
            rules = payload.get("Rules") or []
            profiles = payload.get("Profiles") or []
            if isinstance(rules, dict):
                rules = [rules]
            if isinstance(profiles, dict):
                profiles = [profiles]

            good = len(rules) == 3 and all(bool(x.get("Good")) for x in rules)
            present = sum(1 for x in rules if x.get("Present"))
            rule_detail = " | ".join(f"{x.get('Name')}: {x.get('Info')}" for x in rules)
            active_profiles = [p for p in profiles if str(p.get("Enabled", "")).lower() == "true"]
            profile_detail = "; ".join(
                f"{p.get('Name')}: Enabled={p.get('Enabled')}, DefaultOutbound={p.get('DefaultOutboundAction')}"
                for p in profiles
            )
            blocking_policy = any(str(p.get("DefaultOutboundAction", "")).lower() == "block" for p in active_profiles)
            detail = (rule_detail + (" | Profiles: " + profile_detail if profile_detail else "")).strip(" |")
            if good:
                return {"state": "pass", "summary": "هر ۳ Rule خروجی VideoShelf فعال‌اند", "detail": detail, "blocking_policy": blocking_policy}
            if blocking_policy:
                return {"state": "warn", "summary": f"Outbound ویندوز روی حداقل یک Profile حالت Block دارد و Ruleهای VideoShelf کامل نیستند ({present}/3)", "detail": detail, "blocking_policy": True}
            return {"state": "info", "summary": f"Rule اختصاصی کامل نیست ({present}/3)، اما Outbound ویندوز Block نشده؛ این به‌تنهایی مشکل محسوب نمی‌شود", "detail": detail, "blocking_policy": False}
        except Exception as exc:
            return {"state": "unknown", "summary": "بررسی Rule/Profile ممکن نشد", "detail": f"{type(exc).__name__}: {exc}", "blocking_policy": False}

    @staticmethod
    def _tcp_probe(ip: str, port: int, timeout: float = 3.0):
        started = time.monotonic()
        sock = None
        try:
            sock = socket.create_connection((ip, port), timeout=timeout)
            ms = int((time.monotonic() - started) * 1000)
            return True, f"TCP connect OK ({ms} ms)"
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"
        finally:
            try:
                if sock:
                    sock.close()
            except Exception:
                pass

    @staticmethod
    def _tls_host_probe(host: str, port: int = 443, timeout: float = 5.0):
        started = time.monotonic()
        raw = tls = None
        try:
            raw = socket.create_connection((host, port), timeout=timeout)
            raw.settimeout(timeout)
            ctx = ssl.create_default_context()
            tls = ctx.wrap_socket(raw, server_hostname=host)
            ms = int((time.monotonic() - started) * 1000)
            return True, f"TLS OK ({ms} ms)"
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"
        finally:
            try:
                if tls:
                    tls.close()
                elif raw:
                    raw.close()
            except Exception:
                pass

    def _warp_diagnostic(self):
        cli = self._find_warp_cli()
        if not cli:
            return {"state": "info", "summary": "WARP نصب نیست", "detail": "اختیاری است؛ فقط برای Rescue استفاده می‌شود."}
        try:
            code, out = self._run_warp_cli(cli, ["status"], timeout=8)
            on, trace = self._trace_warp_state(timeout=5)
            if on:
                return {"state": "pass", "summary": "WARP فعال است", "detail": trace + (f" | {out[-500:]}" if out else "")}
            return {"state": "info", "summary": "WARP نصب است ولی فعال نیست", "detail": trace + (f" | {out[-500:]}" if out else "")}
        except Exception as exc:
            return {"state": "warn", "summary": "WARP پیدا شد ولی وضعیتش خوانده نشد", "detail": str(exc)}

    # ---------- diagnostics ----------

    def _tls_edge_probe(self, ip: str, timeout=3.0):
        raw = None
        tls = None
        started = time.monotonic()
        try:
            raw = socket.create_connection((ip, 7844), timeout=timeout)
            raw.settimeout(timeout)
            context = ssl.create_default_context()
            context.set_alpn_protocols(["h2"])
            tls = context.wrap_socket(raw, server_hostname="h2.cftunnel.com")
            ms = int((time.monotonic() - started) * 1000)
            alpn = tls.selected_alpn_protocol()
            if alpn != "h2":
                return False, f"unexpected ALPN={alpn!r} ({ms} ms)"
            return True, f"TLS/SNI OK ({ms} ms, ALPN=h2)"
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"
        finally:
            try:
                if tls:
                    tls.close()
                elif raw:
                    raw.close()
            except Exception:
                pass

    def _transport_evidence_from_recent_logs(self):
        """Reconstruct Cloudflare's own transport precheck from the real tunnel log."""
        pre = {"quic": None, "http2": None, "dns": None, "hard_fail": False}
        evidence = []
        text = self._recent_logs(700)
        for raw in text.splitlines():
            msg = self._log_message(raw)
            self._update_precheck(pre, raw)
            low = raw.lower()
            if "failed to dial a quic connection" in low or "failed to dial to edge with quic" in low:
                if pre.get("quic") is not True:
                    pre["quic"] = False
                evidence.append(raw)
            elif "registered tunnel connection" in low:
                if "quic" in low:
                    pre["quic"] = True
                elif "http2" in low or "http/2" in low:
                    pre["http2"] = True
                evidence.append(raw)
            elif "udp connectivity" in low or "tcp connectivity" in low or "precheck complete" in low:
                evidence.append(raw)
        snap = dict(getattr(self, "_last_transport_precheck", {}) or {})
        for k in ("quic", "http2", "dns"):
            if snap.get(k) is not None:
                pre[k] = snap[k]
        if snap.get("hard_fail"):
            pre["hard_fail"] = True
        return pre, "\n".join(evidence[-24:])

    def _active_cloudflared_transport_probe(self, timeout: float = 34.0, allow_temporary: bool = True):
        """Read real cloudflared transport evidence first.

        A temporary Quick Tunnel probe is allowed only for an explicit standalone
        diagnostic run. It is NEVER launched while the real share is starting/running.
        """
        pre, evidence = self._transport_evidence_from_recent_logs()
        if pre.get("quic") is not None and pre.get("http2") is not None:
            return pre, evidence or "live/recent cloudflared precheck"

        if not allow_temporary:
            detail = evidence or "No complete transport precheck has been emitted by the real Tunnel yet."
            return pre, detail

        cmd = [
            str(self.cloudflared_path), "tunnel", "--url", "http://127.0.0.1:9",
            "--protocol", "auto",
            "--edge-ip-version", "4", "--retries", "1",
            "--output", "json", "--loglevel", "info", "--no-autoupdate",
        ]
        self._own_log("===== TEMPORARY Cloudflare transport probe (standalone diagnostics only) =====")
        proc = None
        q = queue.Queue()
        lines = []
        try:
            proc = subprocess.Popen(
                cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", creationflags=WIN_FLAGS,
                bufsize=1, env=self._isolated_cloudflared_env(),
            )
            def reader():
                try:
                    if proc.stdout:
                        for line in proc.stdout:
                            q.put(line.rstrip("\r\n"))
                except Exception:
                    pass
            threading.Thread(target=reader, name="CloudflaredTransportProbe", daemon=True).start()
            deadline = time.monotonic() + timeout
            decided_at = None
            while time.monotonic() < deadline:
                got = False
                while True:
                    try:
                        raw = q.get_nowait()
                    except queue.Empty:
                        break
                    got = True
                    if not raw:
                        continue
                    lines.append(raw)
                    self._append_log(raw)
                    msg = self._log_message(raw)
                    self._update_precheck(pre, raw)
                    low = raw.lower()
                    if "failed to dial a quic connection" in low or "failed to dial to edge with quic" in low:
                        if pre.get("quic") is not True:
                            pre["quic"] = False
                    if "registered tunnel connection" in low:
                        if "quic" in low:
                            pre["quic"] = True
                        elif "http2" in low or "http/2" in low:
                            pre["http2"] = True
                if pre.get("quic") is not None and pre.get("http2") is not None:
                    if decided_at is None:
                        decided_at = time.monotonic()
                    elif time.monotonic() - decided_at > 0.8:
                        break
                if proc.poll() is not None and not got:
                    break
                time.sleep(0.12)
        except Exception as exc:
            lines.append(f"transport probe failed: {type(exc).__name__}: {exc}")
        finally:
            if proc is not None:
                self._stop_process(proc)
        return pre, "\n".join(lines[-40:])

    def _powershell_dns_query(self, name: str, record_type: str = "A", server: str = ""):
        """Query Windows DNS resolver (or an explicit resolver) and return structured evidence."""
        if os.name != "nt":
            return False, "Windows-only DNS diagnostic"
        ps = [
            "$ErrorActionPreference='Stop';",
            f"$r=Resolve-DnsName -Name '{name}' -Type {record_type}",
        ]
        if server:
            ps[-1] += f" -Server '{server}'"
        if record_type.upper() == "SRV":
            ps.append("$r | Where-Object {$_.Type -eq 'SRV'} | Select-Object NameTarget,Port,Priority,Weight | ConvertTo-Json -Compress")
        else:
            ps.append("$r | Where-Object {$_.IPAddress} | Select-Object Name,IPAddress,Type | ConvertTo-Json -Compress")
        try:
            cp = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", " ".join(ps)],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=10, creationflags=WIN_FLAGS,
            )
            out = (cp.stdout or "").strip()
            err = (cp.stderr or "").strip()
            if cp.returncode != 0 or not out:
                return False, (err or out or f"exit={cp.returncode}")[:700]
            return True, out[:1200]
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"

    def _cloudflare_srv_dns_diagnostic(self):
        """Cloudflare edge discovery depends on SRV DNS, not only ordinary A lookups."""
        srv_name = "_v2-origintunneld._tcp.argotunnel.com"
        sys_ok, sys_detail = self._powershell_dns_query(srv_name, "SRV")
        cf_ok, cf_detail = self._powershell_dns_query(srv_name, "SRV", "1.1.1.1")
        feature_ok, feature_detail = self._powershell_dns_query("cfd-features.argotunnel.com", "A")
        if sys_ok:
            state = "pass"
            summary = "SRV موردنیاز Edge discovery با DNS فعلی ویندوز Resolve می‌شود"
        elif cf_ok:
            state = "warn"
            summary = "DNS فعلی ویندوز SRV کلادفلر را Resolve نمی‌کند، اما 1.1.1.1 موفق است"
        else:
            state = "fail"
            summary = "SRV موردنیاز Edge discovery نه با DNS فعلی و نه با 1.1.1.1 Resolve نشد"
        detail = (
            f"System SRV={'PASS' if sys_ok else 'FAIL'}: {sys_detail} | "
            f"1.1.1.1 SRV={'PASS' if cf_ok else 'FAIL'}: {cf_detail} | "
            f"cfd-features(system)={'PASS' if feature_ok else 'FAIL'}: {feature_detail}"
        )
        return {
            "state": state, "summary": summary, "detail": detail,
            "system_srv_ok": sys_ok, "cloudflare_srv_ok": cf_ok, "feature_dns_ok": feature_ok,
        }

    def _network_diagnostics(self, allow_temporary_transport_probe: bool = True):
        self._own_log(f"===== Cloudflare network diagnostics v{CLOUDFLARE_SHARE_VERSION} =====")
        self._own_log(f"OS: {platform.platform()}")
        self._own_log(f"Machine: {platform.machine()} | Python: {platform.python_version()}")
        self._own_log(f"cloudflared path: {self.cloudflared_path}")

        items = {}
        def put(key, state, summary, detail=""):
            items[key] = {"state": state, "summary": summary, "detail": detail}
            self._own_log(f"TEST {key}: {state.upper()} | {summary}" + (f" | {detail}" if detail else ""))

        try:
            self._ensure_cloudflared()
            ver = self._version_text()
            put("binary", "pass", f"cloudflared داخلی سالم — {ver}", f"SHA256={CLOUDFLARED_SHA256}")
        except Exception as exc:
            put("binary", "fail", "cloudflared داخلی مشکل دارد", str(exc))

        fw = self._check_windows_firewall_rules()
        items["firewall"] = fw
        self._own_log(f"TEST firewall: {fw['state'].upper()} | {fw['summary']} | {fw.get('detail','')}")

        all_ips = []
        dns_ok = True
        dns_detail = []
        for host in ("region1.v2.argotunnel.com", "region2.v2.argotunnel.com"):
            ips = []
            try:
                for info in socket.getaddrinfo(host, 7844, socket.AF_INET, socket.SOCK_STREAM):
                    ip = info[4][0]
                    if ip not in ips:
                        ips.append(ip)
                dns_detail.append(f"{host} -> {', '.join(ips[:6])}")
                all_ips.extend(ip for ip in ips if ip not in all_ips)
            except Exception as exc:
                dns_ok = False
                dns_detail.append(f"{host} -> FAIL {exc}")
        put("dns", "pass" if dns_ok and all_ips else "fail",
            "DNS هر دو Edge کلادفلر Resolve شد" if dns_ok and all_ips else "DNS Edgeهای Cloudflare مشکل دارد",
            " | ".join(dns_detail))

        dns_srv = self._cloudflare_srv_dns_diagnostic()
        items["dns_srv"] = dns_srv
        self._own_log(
            f"TEST dns_srv: {dns_srv['state'].upper()} | {dns_srv['summary']} | {dns_srv.get('detail','')}"
        )

        tcp_pass = False
        tcp_details = []
        for ip in all_ips[:6]:
            ok, detail = self._tcp_probe(ip, 7844, timeout=3.0)
            tcp_details.append(f"{ip}: {detail}")
            if ok:
                tcp_pass = True
                break
        put("tcp7844", "pass" if tcp_pass else "fail",
            "TCP socket روی 7844 تا Edge باز می‌شود" if tcp_pass else "TCP socket روی 7844 تا Edge پاسخ نمی‌دهد",
            " | ".join(tcp_details))

        http2_tls = False
        tls_details = []
        for ip in all_ips[:6]:
            ok, detail = self._tls_edge_probe(ip)
            tls_details.append(f"{ip}: {detail}")
            if ok:
                http2_tls = True
                break
        put("http2", "pass" if http2_tls else "fail",
            "TLS/HTTP2 واقعی Cloudflare روی TCP/7844 سالم است" if http2_tls else "TCP باز می‌شود ولی TLS/HTTP2 Cloudflare روی 7844 کامل نمی‌شود",
            " | ".join(tls_details))

        api_ok, api_detail = self._tls_host_probe("api.cloudflare.com", 443, 6.0)
        put("api443", "pass" if api_ok else "fail",
            "api.cloudflare.com روی TCP/443 در دسترس است" if api_ok else "Cloudflare API روی 443 در دسترس نیست", api_detail)
        quick_ok, quick_detail = self._tls_host_probe("api.trycloudflare.com", 443, 6.0)
        put("quick443", "pass" if quick_ok else "fail",
            "Quick Tunnel API روی TCP/443 در دسترس است" if quick_ok else "api.trycloudflare.com روی 443 در دسترس نیست", quick_detail)

        pre, transport_detail = self._active_cloudflared_transport_probe(allow_temporary=allow_temporary_transport_probe)
        if pre.get("quic") is True:
            put("udp7844", "pass", "QUIC/UDP 7844 طبق Pre-check واقعی cloudflared سالم است", transport_detail[-1800:])
        elif pre.get("quic") is False:
            put("udp7844", "fail", "QUIC/UDP 7844 طبق Pre-check/اتصال واقعی cloudflared Fail است", transport_detail[-1800:])
        else:
            put("udp7844", "unknown", "برای QUIC/UDP 7844 هنوز evidence قطعی از cloudflared نداریم", transport_detail[-1800:])

        if pre.get("http2") is True:
            items["http2"] = {"state": "pass", "summary": "HTTP/2/TCP 7844 طبق Pre-check واقعی cloudflared سالم است", "detail": transport_detail[-1800:]}
            self._own_log("TEST http2-native: PASS | cloudflared native precheck")
        elif pre.get("http2") is False:
            items["http2"] = {"state": "fail", "summary": "HTTP/2/TCP 7844 طبق Pre-check واقعی cloudflared Fail است", "detail": transport_detail[-1800:] + (" | Python TLS: " + " | ".join(tls_details[-2:]) if tls_details else "")}
            self._own_log("TEST http2-native: FAIL | cloudflared native precheck")

        items["warp"] = self._warp_diagnostic()
        fw_blocking = bool(fw.get("blocking_policy"))
        udp_state = items.get("udp7844", {}).get("state")
        h2_state = items.get("http2", {}).get("state")
        dns_good = items.get("dns", {}).get("state") == "pass"
        dns_srv_state = items.get("dns_srv", {}).get("state")
        dns_srv_system_ok = bool(items.get("dns_srv", {}).get("system_srv_ok"))
        dns_srv_cf_ok = bool(items.get("dns_srv", {}).get("cloudflare_srv_ok"))
        raw_tcp_good = items.get("tcp7844", {}).get("state") == "pass"
        api_good = items.get("api443", {}).get("state") == "pass"
        quick_good = items.get("quick443", {}).get("state") == "pass"

        if udp_state == "pass" or h2_state == "pass":
            verdict = "حداقل یکی از Transportهای واقعی Cloudflare روی 7844 سالم است؛ از نظر شبکه Tunnel باید قابل برقراری باشد."
            verdict_state = "pass"
        elif dns_srv_state == "warn" and (not dns_srv_system_ok) and dns_srv_cf_ok:
            verdict = "مشکل DNS مشخص شد: Resolver فعلی ویندوز SRV موردنیاز Cloudflare Edge را جواب نمی‌دهد، ولی 1.1.1.1 جواب می‌دهد. Port Forward یا Inbound Rule لازم نیست؛ گلوگاه فعلی DNS سیستم/مودم/ISP است."
            verdict_state = "warn"
        elif dns_srv_state == "fail" and dns_good:
            verdict = "DNS معمولی A-record کار می‌کند ولی SRV موردنیاز Edge discovery کلادفلر Fail است. این دقیقاً می‌تواند باعث DNS prerequisite failed در cloudflared شود؛ تمرکز باید روی DNS resolver باشد، نه بازکردن پورت ورودی."
            verdict_state = "fail"
        elif fw_blocking:
            verdict = "Windows Firewall روی حداقل یک Profile، Outbound را Block کرده و Rule اختصاصی کامل نیست؛ اول Auto-Fix Firewall را اجرا کن و دوباره تست بگیر."
            verdict_state = "warn"
        elif dns_good and raw_tcp_good and h2_state == "fail" and udp_state == "fail" and api_good and quick_good:
            verdict = "Windows Firewall مانع ساده‌ی خروجی نیست: DNS و 443 سالم‌اند و TCP socket روی 7844 باز می‌شود، اما هر دو Transport واقعی Cloudflare (TLS/HTTP2 و QUIC) Fail می‌شوند. این الگو بیشتر با فیلترینگ/Inspection یا Drop در مسیر بعد از اتصال خام سازگار است (روتر، ISP، DPI یا نرم‌افزار امنیتی دارای فیلتر شبکه). باز کردن Ruleهای بیشتر ویندوز احتمالاً کمکی نمی‌کند."
            verdict_state = "fail"
        elif dns_good and h2_state == "fail" and udp_state == "fail":
            verdict = "هر دو Transport واقعی 7844 Fail هستند. چون Policy ویندوز Outbound را Block نکرده، تمرکز تست بعدی باید روی مسیر شبکه/روتر/ISP یا فیلتر امنیتی سیستم باشد، نه صرفاً ساخت Rule جدید."
            verdict_state = "fail"
        elif udp_state == "unknown":
            verdict = "HTTP/2 روی 7844 Fail است اما برای QUIC هنوز evidence قطعی نداریم. یک بار Tunnel را Start کن و سپس تست شبکه را دوباره بزن تا Pre-check واقعی cloudflared ثبت شود."
            verdict_state = "warn"
        else:
            verdict = "تست‌ها ناسازگار یا ناقص‌اند؛ جزئیات هر ردیف را بررسی کن."
            verdict_state = "warn"

        put("verdict", verdict_state, verdict, f"native_precheck={pre}")
        self._own_log("===== End diagnostics =====")
        return {
            "phase": "done", "items": items, "verdict": verdict,
            "verdict_state": verdict_state, "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "native_precheck": pre,
            "temporary_transport_probe_allowed": bool(allow_temporary_transport_probe),
        }

    # ---------- launch/readiness ----------

    def _isolated_cloudflared_env(self) -> dict[str, str]:
        env = os.environ.copy()
        # Quick Tunnels do not need a config file. Isolate the cloudflared home so a
        # user's ~/.cloudflared/config.yml cannot silently alter this app session.
        try:
            home = self.tools_dir / "quick-home"
            home.mkdir(parents=True, exist_ok=True)
            env["HOME"] = str(home)
            if os.name == "nt":
                env["USERPROFILE"] = str(home)
        except Exception:
            pass
        return env

    def _build_command(self, origin: str, protocol: str, metrics_port: int) -> list[str]:
        flags = self._tunnel_flags
        cmd = [str(self.cloudflared_path), "tunnel"]

        if "url" in flags:
            cmd += ["--url", origin]
        else:
            # --url is required for Quick Tunnel; modern cloudflared supports it.
            cmd += ["--url", origin]

        # IMPORTANT: Quick Tunnel has a known behavior/regression in recent cloudflared
        # builds where omitting --protocol makes the quick tunnel select QUIC instead of
        # behaving like auto. Never gate this flag on help-text detection: current
        # cloudflared accepts it for Quick Tunnels even when our help parser misses it.
        # Explicit AUTO restores protocol fallback; targeted retries may force HTTP2/QUIC.
        normalized_protocol = (protocol or "auto").strip().lower()
        if normalized_protocol not in {"auto", "quic", "http2"}:
            normalized_protocol = "auto"
        cmd += ["--protocol", normalized_protocol]
        if "edge-ip-version" in flags:
            cmd += ["--edge-ip-version", "4"]
        if "retries" in flags:
            cmd += ["--retries", "5"]
        if "metrics" in flags:
            cmd += ["--metrics", f"127.0.0.1:{metrics_port}"]
        if "output" in flags:
            cmd += ["--output", "json"]
        if "loglevel" in flags:
            cmd += ["--loglevel", "info"]
        if "no-autoupdate" in flags:
            cmd += ["--no-autoupdate"]
        return cmd

    @staticmethod
    def _update_precheck(precheck: dict, message: str):
        raw = (message or "").strip()
        if not raw:
            return

        # Prefer structured JSON emitted by modern cloudflared (`--output json`).
        if raw.startswith("{"):
            try:
                obj = json.loads(raw)
            except Exception:
                obj = None
            if isinstance(obj, dict):
                component = str(obj.get("component") or "").strip().lower()
                status = str(obj.get("status") or "").strip().lower()
                msg = str(obj.get("message") or obj.get("msg") or "").strip().lower()
                if msg == "precheck" or component:
                    if component == "udp connectivity":
                        if status == "pass":
                            precheck["quic"] = True
                        elif status == "fail" and precheck.get("quic") is not True:
                            precheck["quic"] = False
                    elif component == "tcp connectivity":
                        if status == "pass":
                            precheck["http2"] = True
                        elif status == "fail" and precheck.get("http2") is not True:
                            precheck["http2"] = False
                    elif component == "dns resolution":
                        if status == "pass":
                            precheck["dns"] = True
                        elif status == "fail" and precheck.get("dns") is not True:
                            precheck["dns"] = False
                if msg == "precheck complete" and bool(obj.get("hard_fail")):
                    precheck["hard_fail"] = True
                # Continue into text fallback as the message field may contain the pretty table.
                if obj.get("message"):
                    raw = str(obj.get("message"))

        low = raw.lower()
        status_match = re.search(r"\bstatus=(pass|fail|skip)\b", low)
        status = status_match.group(1) if status_match else ""

        if "precheck component=" in low:
            if 'component="udp connectivity"' in low:
                if status == "pass":
                    precheck["quic"] = True
                elif status == "fail" and precheck.get("quic") is not True:
                    precheck["quic"] = False
            elif 'component="tcp connectivity"' in low:
                if status == "pass":
                    precheck["http2"] = True
                elif status == "fail" and precheck.get("http2") is not True:
                    precheck["http2"] = False
            elif 'component="dns resolution"' in low:
                if status == "pass":
                    precheck["dns"] = True
                elif status == "fail" and precheck.get("dns") is not True:
                    precheck["dns"] = False

        if "udp connectivity" in low and " fail " in f" {low} ":
            if precheck.get("quic") is not True:
                precheck["quic"] = False
        if "udp connectivity" in low and " pass " in f" {low} ":
            precheck["quic"] = True
        if "tcp connectivity" in low and " fail " in f" {low} ":
            if precheck.get("http2") is not True:
                precheck["http2"] = False
        if "tcp connectivity" in low and " pass " in f" {low} ":
            precheck["http2"] = True
        if "precheck complete" in low and "hard_fail=true" in low:
            precheck["hard_fail"] = True

    def _launch_once(self, origin: str, protocol: str, generation: int):
        metrics_port = self._free_local_port()
        self._metrics_base = f"http://127.0.0.1:{metrics_port}"
        command = self._build_command(origin, protocol, metrics_port)
        env = self._isolated_cloudflared_env()

        self._own_log(f"===== cloudflared generation={generation} protocol={protocol} =====")
        self._own_log("Command: " + subprocess.list2cmdline(command))
        self._own_log(f"Metrics: {self._metrics_base}")

        line_queue: "queue.Queue[str]" = queue.Queue(maxsize=1200)
        try:
            proc = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=WIN_FLAGS,
                bufsize=1,
                env=env,
            )
        except Exception as exc:
            return {"ok": False, "reason": f"cloudflared اجرا نشد: {exc}", "precheck": {}}

        self._tunnel_proc = proc
        self._provider = "cloudflare"
        self.provider_changed.emit("Cloudflare Quick Tunnel")
        self._own_log(f"cloudflared PID={proc.pid}")

        threading.Thread(
            target=self._drain_output,
            args=(proc, line_queue),
            name=f"CloudflaredLogReader-{generation}",
            daemon=True,
        ).start()

        precheck = {"quic": None, "http2": None, "dns": None, "hard_fail": False}
        log_url = ""
        registered_log = False
        started = time.monotonic()
        hard_fail_seen_at = 0.0
        metrics_seen = False

        while time.monotonic() - started < self.STARTUP_TIMEOUT:
            if self._stopping or not self._desired_running or generation != self._generation:
                self._stop_process(proc)
                return {"ok": False, "reason": "stopped", "precheck": precheck}

            while True:
                try:
                    raw = line_queue.get_nowait()
                except queue.Empty:
                    break
                message = self._log_message(raw)
                self._update_precheck(precheck, raw)
                self._last_transport_precheck = {
                    "quic": precheck.get("quic"), "http2": precheck.get("http2"),
                    "dns": precheck.get("dns"), "hard_fail": bool(precheck.get("hard_fail")),
                    "time": time.time(),
                }
                low = message.lower()

                match = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", raw, re.I)
                if not match:
                    match = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", message, re.I)
                if match:
                    candidate = match.group(0).rstrip("/")
                    if candidate != log_url:
                        log_url = candidate
                        self._own_log(f"Quick Tunnel provisioned: {candidate}")
                        self.status_changed.emit("آدرس موقت ساخته شد؛ منتظر اتصال واقعی Connector…")

                if "registered tunnel connection" in low:
                    registered_log = True
                    self._own_log("cloudflared log confirms: Registered tunnel connection")

                if precheck.get("hard_fail") and not hard_fail_seen_at:
                    hard_fail_seen_at = time.monotonic()

            ready = self._ready_connections()
            if ready is not None:
                metrics_seen = True
            if ready and ready > 0:
                url = self._quick_tunnel_url_from_metrics() or log_url
                if url:
                    self._own_log(f"Connector READY: readyConnections={ready}")
                    self._own_log(f"Quick Tunnel hostname accepted: {url}")
                    return {
                        "ok": True,
                        "url": url,
                        "proc": proc,
                        "precheck": precheck,
                        "ready_via": "metrics",
                    }
                self.status_changed.emit("Connector وصل شد؛ در حال دریافت hostname از Cloudflare…")

            # Metrics are preferred. If this cloudflared build does not expose them,
            # preserve compatibility by accepting the official registration event.
            if registered_log and log_url and not metrics_seen and time.monotonic() - started > 4.0:
                self._own_log("Connector READY via official registration log (metrics endpoint unavailable)")
                return {
                    "ok": True,
                    "url": log_url,
                    "proc": proc,
                    "precheck": precheck,
                    "ready_via": "log",
                }

            if precheck.get("hard_fail"):
                # If Cloudflare itself confirms that both transports are unavailable,
                # there is no value in waiting or provisioning more random hostnames.
                if precheck.get("quic") is False and precheck.get("http2") is False:
                    self._own_log("Native Cloudflare precheck: QUIC FAIL + HTTP2 FAIL -> BLOCKED_NETWORK")
                    self._stop_process(proc)
                    return {
                        "ok": False,
                        "reason": "both-transports-blocked",
                        "precheck": precheck,
                    }
                if hard_fail_seen_at and time.monotonic() - hard_fail_seen_at > 3.0 and proc.poll() is not None:
                    break

            if proc.poll() is not None:
                break

            time.sleep(self.READY_POLL_INTERVAL)

        exit_code = proc.poll()
        if exit_code is None:
            self._stop_process(proc)
            reason = "startup-timeout"
        else:
            reason = f"cloudflared-exit-{exit_code}"

        return {
            "ok": False,
            "reason": reason,
            "precheck": precheck,
            "logs": self._recent_logs(55),
        }

    def _verify_public_after_ready(self, proc: subprocess.Popen, base_url: str, generation: int):
        deadline = time.monotonic() + self.PUBLIC_VERIFY_TIMEOUT
        last_kind = ""
        last_detail = ""
        self.status_changed.emit("Connector وصل است؛ در حال بررسی دسترسی عمومی…")

        # A short grace period avoids hammering a just-provisioned hostname with 1033.
        time.sleep(2.0)
        while time.monotonic() < deadline:
            if self._stopping or not self._desired_running or generation != self._generation:
                return False, "stopped", ""
            if proc.poll() is not None:
                return False, "process-exited", f"code={proc.returncode}"

            ready = self._ready_connections()
            if ready == 0:
                return False, "connector-lost", "readyConnections=0"

            ok, kind, detail = self._public_health(base_url, timeout=5)
            last_kind, last_detail = kind, detail
            if ok:
                self._own_log("Public health: OK (HTTP 200)")
                return True, kind, detail

            self._own_log(f"Public health after connector-ready: {kind} -> {str(detail)[:240]}")
            if kind == "1033":
                self.status_changed.emit("Connector وصل است؛ Cloudflare هنوز hostname را منتشر می‌کند…")
            elif kind == "network":
                self.status_changed.emit("Connector وصل است؛ DNS/تست عمومی این سیستم هنوز آماده نیست…")
            time.sleep(2.0)

        # /ready is the authoritative connector signal. If it is still healthy but
        # this machine cannot resolve/test the public hostname, keep the share usable
        # for other clients instead of destroying a valid tunnel.
        ready = self._ready_connections()
        if ready and ready > 0:
            self._own_log(
                f"Public verification did not complete ({last_kind}), but /ready still reports {ready} active connection(s)."
            )
            return True, "connector-ready-unverified", last_detail
        return False, last_kind or "verify-timeout", last_detail

    def _start_worker(self):
        if not self._worker_lock.acquire(blocking=False):
            return
        try:
            if not self._desired_running:
                return

            self._stopping = False
            self._blocked_network = False
            self.log_reset.emit()
            with self._log_lock:
                self._log_tail.clear()
            self._prepare_session_log()
            self._session_started = time.monotonic()
            self._own_log(f"===== VideoShelf Cloudflare sharing v{CLOUDFLARE_SHARE_VERSION} started =====")
            self.status_changed.emit("در حال آماده‌سازی Cloudflare Quick Tunnel…")
            self.running_changed.emit(False)
            self.url_changed.emit("")
            self.provider_changed.emit("Cloudflare Quick Tunnel")
            self._public_base_url = ""

            self._ensure_cloudflared()
            version_tuple = self._version_tuple()
            version_text = self._version_text()
            self._own_log(f"cloudflared: {version_text or 'unknown'}")
            if version_tuple != (0, 0, 0) and version_tuple < self.MIN_NATIVE_PRECHECK:
                self._own_log(
                    f"WARNING: cloudflared {version_tuple} predates native connectivity prechecks; update recommended."
                )

            self._tunnel_flags = self._tunnel_help_flags()
            self._own_log("Supported flags: " + (", ".join(sorted(self._tunnel_flags)) or "unknown"))

            with self._lock:
                videos = list(self._videos)
            self.web.update_videos(videos)
            port = self.web.start()
            self._own_log(f"Local web server started on 127.0.0.1:{port} | videos={len(videos)}")
            if not self._check_local_origin(port):
                self.web.stop()
                raise RuntimeError("وب‌سرور محلی VideoShelf پاسخ نمی‌دهد؛ Cloudflare اجرا نشد.")

            origin = f"http://127.0.0.1:{port}"
            self._generation += 1
            generation = self._generation

            # One standard Cloudflare process first. Let cloudflared own edge rotation
            # and internal retries. A second process is allowed only as a targeted
            # transport recovery when the native precheck proves the other transport works.
            self.status_changed.emit("Cloudflare در حال اتصال است — یک Tunnel، مدیریت retry توسط خود cloudflared…")
            self._own_log("Quick Tunnel compatibility fix: passing --protocol auto explicitly")
            result = self._launch_once(origin, "auto", generation)
            http2_attempted = False

            if not result.get("ok"):
                pre = result.get("precheck") or {}
                reason = result.get("reason") or "unknown"

                # Proven fallback used by mature projects: if a Quick Tunnel mints a URL
                # but never registers an edge connection, retry exactly once with HTTP/2.
                # This is intentionally attempted even when the native precheck reports
                # both transports failed, because it gives us a direct real-tunnel verdict
                # and works around Quick Tunnel builds that otherwise stay on QUIC.
                if self._desired_running and not self._stopping:
                    self._own_log(
                        "Compatibility fallback: AUTO did not register; retrying exactly once with --protocol http2"
                    )
                    self.status_changed.emit("Cloudflare: AUTO وصل نشد؛ یک‌بار HTTP/2 مستقیم امتحان می‌شود…")
                    self._stop_process(result.get("proc"))
                    self._tunnel_proc = None
                    self._metrics_base = ""
                    self._generation += 1
                    generation = self._generation
                    result = self._launch_once(origin, "http2", generation)
                    http2_attempted = True
                    if result.get("ok"):
                        self._own_log("HTTP/2 compatibility fallback succeeded")
                    else:
                        pre = result.get("precheck") or {}
                        reason = result.get("reason") or "unknown"

                if not result.get("ok") and (reason == "both-transports-blocked" or (
                    pre.get("quic") is False and pre.get("http2") is False
                )):
                    # Direct cloudflared transport is genuinely blocked after an explicit HTTP/2 retry. If the user explicitly
                    # pressed WARP Rescue, try exactly one Cloudflare-only alternate network path:
                    # WARP/MASQUE -> Internet -> Cloudflare Tunnel edge. No third-party relay.
                    if self._warp_assist_requested and self._desired_running and not self._stopping:
                        self._own_log("Direct 7844 blocked; explicit WARP rescue is enabled")
                        self._stop_process(result.get("proc"))
                        self._tunnel_proc = None
                        self._metrics_base = ""
                        ok, warp_detail = self._prepare_warp_assist()
                        if ok:
                            self._own_log(f"WARP rescue ready: {warp_detail}; retrying one cloudflared generation")
                            self._generation += 1
                            generation = self._generation
                            result = self._launch_once(origin, "auto", generation)
                            if not result.get("ok"):
                                pre = result.get("precheck") or {}
                                reason = result.get("reason") or "unknown"
                        else:
                            self._blocked_network = True
                            self.web.stop()
                            raise RuntimeError(
                                "مسیر مستقیم Cloudflare روی 7844 بسته است و WARP Rescue هم آماده نشد.\n\n"
                                + warp_detail
                            )

                    if not result.get("ok") and (reason == "both-transports-blocked" or (
                        pre.get("quic") is False and pre.get("http2") is False
                    )):
                        self._blocked_network = True
                        self.web.stop()
                        self._metrics_base = ""
                        suffix = (
                            " WARP Rescue هم امتحان شد ولی cloudflared همچنان به Edge نرسید."
                            if self._warp_assist_requested else
                            " برای امتحان مسیر Cloudflare-only روی 443، دکمه «نجات با Cloudflare WARP (443)» را بزنید."
                        )
                        raise RuntimeError(
                            "Cloudflare تأیید کرد مسیر مستقیم Tunnel مسدود است: "
                            "QUIC روی UDP/7844 و HTTP/2 روی TCP/7844." + suffix
                        )

                forced_protocol = ""
                if pre.get("quic") is False and pre.get("http2") is True:
                    forced_protocol = "http2"
                elif pre.get("http2") is False and pre.get("quic") is True:
                    forced_protocol = "quic"
                else:
                    logs = (result.get("logs") or self._recent_logs(55)).lower()
                    if "crypto_error" in logs or "no_application_protocol" in logs:
                        forced_protocol = "http2"

                if forced_protocol == "http2" and http2_attempted:
                    forced_protocol = ""

                if forced_protocol and self._desired_running and not self._stopping:
                    self._own_log(f"Targeted recovery: native evidence selects protocol={forced_protocol}")
                    self.status_changed.emit(f"Cloudflare: تلاش هدفمند با {forced_protocol.upper()}…")
                    # Keep the same web origin/token; only replace cloudflared generation.
                    self._generation += 1
                    generation = self._generation
                    result = self._launch_once(origin, forced_protocol, generation)

            if not result.get("ok"):
                detail = result.get("logs") or self._recent_logs(55)
                raise RuntimeError(
                    "Cloudflare Connector ثبت نشد. برخلاف نسخه قبلی، برنامه Tunnelهای تصادفی پشت‌سرهم نمی‌سازد.\n\n"
                    + (detail[-4500:] if detail else str(result.get("reason") or "unknown failure"))
                )

            proc = result["proc"]
            base_url = result["url"].rstrip("/")
            self._tunnel_proc = proc
            self._public_base_url = base_url
            self._own_log(f"Connector is READY: {base_url}")

            verified, verify_kind, verify_detail = self._verify_public_after_ready(proc, base_url, generation)
            if not verified:
                self._stop_process(proc)
                self._tunnel_proc = None
                self._public_base_url = ""
                raise RuntimeError(
                    f"Connector پس از اتصال پایدار نماند: {verify_kind} {verify_detail[:500]}"
                )

            self.url_changed.emit(self.public_url())
            self.running_changed.emit(True)
            self._reconnect_pending = False
            self._last_stable_since = time.monotonic()
            if verify_kind == "ok":
                self.status_changed.emit("Cloudflare Quick Tunnel آماده است — Connector و دسترسی عمومی تأیید شدند")
            else:
                self.status_changed.emit("Cloudflare Connector آماده است — تست عمومی این سیستم کامل نشد، لینک قابل استفاده است")

            threading.Thread(
                target=self._monitor_tunnel,
                args=(proc, base_url, generation),
                name=f"CloudTunnelMonitor-{generation}",
                daemon=True,
            ).start()

        except Exception as exc:
            self._own_log(f"FINAL ERROR: {exc}")
            self._public_base_url = ""
            proc = self._tunnel_proc
            self._tunnel_proc = None
            self._provider = ""
            self._metrics_base = ""
            self._stop_process(proc)
            self.running_changed.emit(False)
            self.url_changed.emit("")
            self.provider_changed.emit("Cloudflare Quick Tunnel")

            if self._blocked_network:
                self.status_changed.emit("Cloudflare Tunnel توسط شبکه روی پورت 7844 مسدود است")
            else:
                self.status_changed.emit("Cloudflare Quick Tunnel فعال نشد")

            if self._desired_running and not self._stopping:
                self.error.emit(str(exc))
                if not self._blocked_network:
                    self._schedule_reconnect("startup failure")
        finally:
            self._worker_lock.release()

    # ---------- supervision ----------

    @staticmethod
    def _stop_process(proc: Optional[subprocess.Popen]):
        if not proc:
            return
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def _monitor_tunnel(self, proc: subprocess.Popen, base_url: str, generation: int):
        ready_failures = 0
        metrics_unknown = 0
        last_public_check = 0.0

        while True:
            if self._stopping or not self._desired_running:
                return
            if generation != self._generation or self._tunnel_proc is not proc:
                return
            if proc.poll() is not None:
                self._handle_unexpected_disconnect(proc, f"cloudflared متوقف شد (code {proc.returncode}).")
                return

            time.sleep(3.0)
            if generation != self._generation or self._tunnel_proc is not proc:
                return

            ready = self._ready_connections()
            if ready is None:
                metrics_unknown += 1
            elif ready <= 0:
                ready_failures += 1
                metrics_unknown = 0
                self._own_log(f"Monitor: /ready reports no active connector ({ready_failures}/3)")
            else:
                ready_failures = 0
                metrics_unknown = 0

            if ready_failures >= 3:
                self._handle_unexpected_disconnect(proc, "Cloudflare Connector سه بار پیاپی از /ready خارج شد.")
                return

            now = time.monotonic()
            if now - last_public_check >= self.MONITOR_INTERVAL:
                last_public_check = now
                ok, kind, detail = self._public_health(base_url, timeout=6)
                if ok:
                    if self._last_stable_since and now - self._last_stable_since >= 300:
                        self._restart_count = 0
                    continue

                # Public DNS/1033 alone must not kill a healthy connector. /ready is
                # the authoritative signal for the process-to-Cloudflare connection.
                self._own_log(f"Monitor public health: {kind} -> {str(detail)[:240]}")
                if ready and ready > 0:
                    if kind == "1033":
                        self.status_changed.emit("Connector فعال است؛ Cloudflare موقتاً 1033 می‌دهد، اتصال حفظ شد")
                    elif kind == "network":
                        self.status_changed.emit("Connector فعال است؛ تست عمومی از این سیستم موقتاً در دسترس نیست")

            # If the metrics endpoint itself vanished for a long time but the process
            # is still alive, avoid an aggressive restart; process exit is stronger evidence.
            if metrics_unknown >= 10:
                self._own_log("Monitor: metrics endpoint unavailable for an extended period; process still alive")
                metrics_unknown = 0

    def _handle_unexpected_disconnect(self, proc: subprocess.Popen, reason: str):
        if self._stopping or not self._desired_running or self._tunnel_proc is not proc:
            return

        self._stop_process(proc)
        self._tunnel_proc = None
        self._provider = ""
        self._metrics_base = ""
        self._public_base_url = ""
        self.url_changed.emit("")
        self.running_changed.emit(False)
        self.provider_changed.emit("Cloudflare Quick Tunnel")
        self.status_changed.emit(reason + " تلاش مجدد با backoff…")
        self._schedule_reconnect(reason)

    def _schedule_reconnect(self, reason: str):
        if self._reconnect_pending or not self._desired_running or self._stopping or self._blocked_network:
            return

        self._restart_count += 1
        if self._restart_count > 6:
            self._own_log(f"Reconnect circuit opened after repeated failures. Last reason: {reason}")
            self.status_changed.emit("اتصال چند بار پیاپی شکست خورد؛ Retry خودکار متوقف شد. دوباره Start را بزنید.")
            self.error.emit("Cloudflare بیش از حد پشت‌سرهم قطع شد؛ برای جلوگیری از loop، Retry خودکار متوقف شد.")
            return

        delays = (1, 2, 5, 10, 30, 60)
        delay = delays[min(self._restart_count - 1, len(delays) - 1)]
        self._reconnect_pending = True
        self._own_log(f"Reconnect scheduled in {delay}s (attempt {self._restart_count}/6) because: {reason}")

        def reconnect():
            deadline = time.monotonic() + delay
            while time.monotonic() < deadline:
                if not self._desired_running or self._stopping:
                    self._reconnect_pending = False
                    return
                time.sleep(0.2)
            self._reconnect_pending = False
            if self._desired_running and not self._stopping:
                self._start_worker()

        threading.Thread(target=reconnect, name="CloudTunnelReconnect", daemon=True).start()

WEB_HTML = r'''<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>VideoShelf</title>
<style>
:root{color-scheme:dark;--bg:#0b0d11;--panel:#11151c;--panel2:#151a22;--line:#242d3a;--text:#f3f5f7;--muted:#8d98a8;--accent:#6ea8fe}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,"Segoe UI",Tahoma,sans-serif;min-height:100vh}
.top{position:sticky;top:0;z-index:20;background:rgba(11,13,17,.92);backdrop-filter:blur(18px);border-bottom:1px solid #1d2430;padding:18px clamp(16px,4vw,48px)}
.head{display:flex;align-items:center;gap:14px;margin-bottom:14px}.brand{font-weight:800;font-size:22px;letter-spacing:.2px}.pill{font-size:12px;color:#a9c9ff;border:1px solid #284a79;background:#13233a;padding:5px 9px;border-radius:999px}
.bar{display:flex;gap:10px;align-items:center}.search{flex:1;background:#10141b;border:1px solid #2b3441;color:#fff;border-radius:11px;padding:11px 14px;outline:0}.search:focus{border-color:var(--accent)}
select{background:#10141b;border:1px solid #2b3441;color:#fff;border-radius:11px;padding:10px 12px}.meta{margin-top:10px;color:var(--muted);font-size:12px}
.grid{padding:18px clamp(14px,3vw,40px) 60px;display:grid;grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:15px}.card{background:var(--panel);border:1px solid #222a35;border-radius:15px;overflow:hidden;cursor:pointer;transition:.16s transform,.16s border-color,.16s background}.card:hover{transform:translateY(-2px);border-color:#45566f;background:var(--panel2)}
.visual{position:relative;aspect-ratio:16/9;background:#090b0f;overflow:hidden}.visual img,.visual video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.visual video{display:none}.card.previewing .visual video{display:block}.card.previewing .visual img{display:none}
.previewBadge{position:absolute;top:9px;right:9px;background:rgba(6,9,14,.78);padding:5px 8px;border-radius:7px;font-size:10px;color:#dce8ff;display:none}.card.previewing .previewBadge{display:block}.body{padding:11px 12px 13px}.title{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:auto;text-align:right}.sub{margin-top:6px;color:var(--muted);font-size:12px;display:flex;gap:7px;flex-wrap:wrap}
.empty{padding:80px 24px;text-align:center;color:var(--muted);display:none}
.modal{position:fixed;inset:0;z-index:50;background:rgba(4,6,9,.88);backdrop-filter:blur(12px);display:none;align-items:center;justify-content:center;padding:20px}.modal.open{display:flex}.playerBox{width:min(1200px,96vw);max-height:94vh;background:#0d1117;border:1px solid #2a3442;border-radius:18px;overflow:hidden;box-shadow:0 30px 100px #000}.playerTop{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #222a35}.playerTitle{flex:1;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:auto}.close{border:1px solid #364253;background:#171d26;color:#fff;border-radius:9px;padding:7px 11px;cursor:pointer}.player{width:100%;max-height:calc(94vh - 95px);background:#000;display:block}.note{padding:8px 14px;color:#8d98a8;font-size:11px}.loading{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#9aa6b6;font-size:12px;background:#090b0f}
@media(max-width:650px){.bar{flex-wrap:wrap}.search{min-width:100%}.grid{grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:10px}.body{padding:9px}.title{font-size:13px}.top{padding:14px}.playerBox{width:100vw;border-radius:12px}}
</style>
</head>
<body>
<div class="top"><div class="head"><div class="brand">VideoShelf</div><div class="pill">Private Library</div></div><div class="bar"><input id="q" class="search" placeholder="جستجو بین فیلم‌ها…"><select id="sort"><option value="name">نام</option><option value="rating">امتیاز ★</option><option value="size">حجم</option><option value="duration">مدت</option><option value="date">تاریخ</option></select><select id="ratingFilter" aria-label="فیلتر امتیاز"><option value="0">همه امتیازها</option><option value="5">★ ۵+</option><option value="10">★ ۱۰+</option><option value="15">★ ۱۵+</option><option value="20">★ ۲۰</option></select><select id="kindFilter" aria-label="فیلتر کیفیت"><option value="all">همه</option><option value="favorites">علاقه‌مندی‌ها ♥</option><option value="1080">1080p+</option><option value="2160">4K+</option></select></div><div id="meta" class="meta">در حال بارگذاری…</div></div>
<div id="grid" class="grid"></div><div style="text-align:center;padding:0 0 35px"><button id="more" class="close" style="display:none">نمایش فیلم‌های بیشتر ↓</button></div><div id="empty" class="empty">فیلمی پیدا نشد.</div>
<div id="modal" class="modal"><div class="playerBox"><div class="playerTop"><button id="close" class="close">بستن</button><div id="playerTitle" class="playerTitle"></div></div><video id="player" class="player" controls autoplay playsinline></video><div id="note" class="note">اگر مرورگر فرمت اصلی را پشتیبانی نکند، پخش به‌صورت خودکار به Transcode زنده تغییر می‌کند.</div></div></div>
<script>
const qs=new URLSearchParams(location.search);const token=qs.get('token')||'';
const grid=document.getElementById('grid'),q=document.getElementById('q'),sort=document.getElementById('sort'),meta=document.getElementById('meta'),empty=document.getElementById('empty');
const ratingFilter=document.getElementById('ratingFilter'),kindFilter=document.getElementById('kindFilter'),more=document.getElementById('more');
const modal=document.getElementById('modal'),player=document.getElementById('player'),playerTitle=document.getElementById('playerTitle'),note=document.getElementById('note');
const PAGE=80;let page=0,total=0,rendered=0,hasMore=true,loading=false,requestId=0,searchTimer=null;
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function api(path){return path+(path.includes('?')?'&':'?')+'token='+encodeURIComponent(token)}
function reset(){
 requestId++;page=0;total=0;rendered=0;loading=false;hasMore=true;
 grid.replaceChildren();empty.style.display='none';more.style.display='none';loadMore();
}
async function loadMore(){
 if(loading||!hasMore)return;
 loading=true;const rid=requestId;
 more.disabled=true;meta.textContent='در حال بارگذاری…';
 const params=new URLSearchParams({page:String(page),limit:String(PAGE),q:q.value.trim(),sort:sort.value,rating:ratingFilter.value,kind:kindFilter.value});
 try{
  const response=await fetch(api('/api/videos?'+params));
  if(!response.ok)throw new Error('Request rejected');
  const data=await response.json();
  if(rid!==requestId)return;
  total=Number(data.total)||0;
  for(const v of data.videos||[]){
    const c=document.createElement('article');c.className='card';c.dataset.id=v.id;
    c.innerHTML=`<div class="visual"><div class="loading">پیش‌نمایش</div><img loading="lazy" src="${api('/poster/'+v.id+'.jpg')}" onload="this.previousElementSibling.style.display='none'"><video muted loop playsinline preload="none"></video><span class="previewBadge">PREVIEW</span></div><div class="body"><div class="title" title="${esc(v.name)}">${esc(v.name)} ${v.favorite?'♥':''}</div><div class="sub"><span>${esc(v.sizeText)}</span>${v.durationText?'<span>• '+esc(v.durationText)+'</span>':''}${v.resolution?'<span>• '+esc(v.resolution)+'</span>':''}<span>• ${Math.max(0,Math.min(20,v.rating||0))}/20</span></div></div>`;
    const vid=c.querySelector('video');let hoverTimer=null;
    c.addEventListener('mouseenter',()=>{hoverTimer=setTimeout(()=>{if(!vid.src)vid.src=api('/preview/'+v.id+'.mp4');c.classList.add('previewing');vid.play().catch(()=>{})},180)});
    c.addEventListener('mouseleave',()=>{clearTimeout(hoverTimer);c.classList.remove('previewing');try{vid.pause();vid.currentTime=0}catch(e){}});
    c.addEventListener('click',()=>openPlayer(v));grid.appendChild(c);
  }
  rendered+=Number((data.videos||[]).length);page++;
  hasMore=Boolean(data.hasMore);
  empty.style.display=total?'none':'block';
  more.style.display=hasMore?'inline-block':'none';
  meta.textContent=`نمایش ${rendered} از ${total} فیلم`;
 }catch(e){if(rid===requestId){meta.textContent='خطا در دریافت لیست فیلم‌ها';empty.style.display='block';empty.textContent='اتصال یا مجوز دسترسی را بررسی کنید.'}}
 finally{if(rid===requestId){loading=false;more.disabled=false}}
}
function openPlayer(v){playerTitle.textContent=v.name;modal.classList.add('open');document.body.style.overflow='hidden';note.textContent='در حال پخش فایل اصلی…';let fallback=false;player.onerror=()=>{if(fallback)return;fallback=true;note.textContent='فرمت اصلی در مرورگر پشتیبانی نشد؛ Transcode زنده فعال شد.';player.src=api('/transcode/'+v.id);player.load();player.play().catch(()=>{})};player.src=api('/media/'+v.id);player.load();player.play().catch(()=>{})}
function closePlayer(){modal.classList.remove('open');document.body.style.overflow='';player.pause();player.removeAttribute('src');player.load();}
document.getElementById('close').onclick=closePlayer;modal.addEventListener('click',e=>{if(e.target===modal)closePlayer()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closePlayer()});
q.addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(reset,220)});
for(const s of [sort,ratingFilter,kindFilter])s.addEventListener('change',reset);
more.addEventListener('click',loadMore);reset();
</script>
</body></html>'''
