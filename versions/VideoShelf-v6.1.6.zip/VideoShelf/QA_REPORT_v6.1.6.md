# VideoShelf v6.1.6 — Quality assurance

## Included changes

- Precise mouse-wheel scrolling for the main video grid (small bounded steps; pixel-precise touchpads).
- Click-to-open behavior, preserving star/delete buttons and Ctrl/Shift multi-selection.
- Independent floating `InternalVideoPlayer` instance for each activation, capped at ten concurrent windows.
- Independent close/shutdown cleanup and deferral of file rename if any player is using that file.
- Player surface mouse gestures: single click toggle, double-click fullscreen, wheel volume, Ctrl+wheel zoom.
- Reliable seek-slider press/drag/release handling and throttled video decoder seeks.

## Automated checks

- `python -m py_compile main.py cloud_share.py file_actions.py library_core.py preview_engine.py rating_names.py visible_scheduler.py`
- `python -m unittest discover -s tests -v`
- Regression tests for mouse wheel steps, trackpad input, simultaneous players, safe selection, player mouse gestures, ratings, file operations, 5-segment preview, web security and server-side pagination.

## What cannot be asserted from Linux CI

PySide6 is not installed in this validation environment, so GUI rendering, Windows DPI/scroll behavior, Qt Multimedia codecs, simultaneous audiovisual playback, and real seek/decoder smoothness remain **unverified**. Real multi-player performance depends on available RAM, CPU/GPU, codec and video resolution. No claims of a verified 60FPS playback or tested full Windows GUI are made.

## Manual Windows smoke checklist

1. Run `run.bat` from a newly extracted folder.
2. Scroll using both normal mouse wheel and touchpad (if available), including during thumbnail preview.
3. Click card -> player A; click another card -> player B; open two more movies. Close B; verify A/C/D continue.
4. Ctrl+click/Shift+click should select rather than start video; stars and trash should still work.
5. Seek by clicking the middle of the timeline, dragging across it and releasing; verify the correct final timestamp and no stuck slider.
6. Click video to pause/play; double click to fullscreen; wheel for volume and Ctrl+wheel for zoom.
7. With multiple players open, rate a playing file; close that file's window and verify postponed safe rename and portable JSON are intact.
8. Close the app and verify no preview FFmpeg processes remain running.

- Two additional Qt-free runtime tests verify four independent player instances and closing one window without destroying another.
