"""Regression tests for draggable player, seek pacing, zoom and rating rename."""
from pathlib import Path
import ast
import types
import unittest
import time

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'main.py').read_text(encoding='utf8')
TREE = ast.parse(SOURCE)

def cls(name):
    return next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == name)

def method(cl, name):
    return next(n for n in cl.body if isinstance(n, ast.FunctionDef) and n.name == name)

def source_of(method_node):
    return ast.unparse(method_node)


def isolate_method(class_name, method_name):
    """Exec only Qt-independent method body against stand-ins, not the full UI."""
    node = method(cls(class_name), method_name)
    mod = ast.Module(body=[node], type_ignores=[])
    return_namespace = {'time': time, 'QMediaPlayer': None}
    exec(compile(ast.fix_missing_locations(mod), '<isolated player method>', 'exec'), return_namespace)
    return return_namespace[method_name]


class FakeTimer:
    def __init__(self): self.running = False; self.calls = 0
    def start(self): self.running = True; self.calls += 1
    def stop(self): self.running = False
    def isActive(self): return self.running

class FakeMedia:
    def __init__(self): self.seeks = []
    def isSeekable(self): return True
    def duration(self): return 100000
    def setPosition(self, pos): self.seeks.append(pos)

class PlayerTests(unittest.TestCase):
    def test_player_window_is_independent_and_persists_geometry(self):
        player = cls('InternalVideoPlayer')
        init = source_of(method(player, '__init__'))
        self.assertIn('Qt.Window', init)
        self.assertIn('WindowCloseButtonHint', init)
        self.assertIn('player_window_geometry', source_of(method(player, '_persist_geometry')))
        self.assertIn('save_config', source_of(method(player, '_persist_geometry')))
        self.assertIn('setGeometry', source_of(method(player, '_restore_geometry')))
        self.assertIn('show', source_of(method(player, 'show_player')))
        self.assertIn('raise_', source_of(method(player, 'show_player')))
        self.assertIn('player.open_file(path)', source_of(method(cls('LibraryTab'), 'play_internal')))
        self.assertIn('self._players.append(player)', source_of(method(cls('LibraryTab'), 'play_internal')))
        self.assertNotIn('setCurrentWidget', source_of(method(cls('LibraryTab'), 'play_internal')))

    def test_window_controls_and_video_zoom_are_separate(self):
        player = cls('InternalVideoPlayer')
        init = source_of(method(player, '__init__'))
        self.assertIn('window_size', init)
        self.assertIn('video_zoom', init)
        self.assertIn('mini_button', init)
        self.assertIn('pin_button', init)
        for name in ('set_window_size_percent', 'toggle_fullscreen', 'fit_to_screen',
                     '_change_video_zoom', 'escape_action', 'set_always_on_top'):
            self.assertIsNotNone(method(player, name))
        self.assertIn('Qt.KeepAspectRatio', source_of(method(cls('ZoomVideoSurface'), '__init__')))

    def test_scrub_only_decodes_latest_drag_position_per_timer(self):
        fake = types.SimpleNamespace(_dragging=False, _pending_seek=None,
                                     _seek_timer=FakeTimer(), media=FakeMedia(),
                                     _set_time_text=lambda x: None)
        scrub = isolate_method('InternalVideoPlayer', '_scrub_to')
        apply_seek = isolate_method('InternalVideoPlayer', '_apply_pending_seek')
        for pos in (1000, 2000, 9000, 15000, 40000):
            scrub(fake, pos)
        self.assertEqual(fake._seek_timer.calls, 1, 'Dragging must not restart the decoder timer on every pixel')
        self.assertEqual(fake.media.seeks, [])
        apply_seek(fake)
        self.assertEqual(fake.media.seeks, [40000])

    def test_release_commits_exact_seek_and_resumes_normal_clock(self):
        fake = types.SimpleNamespace(_dragging=True, _pending_seek=22222,
                                     _seek_timer=FakeTimer(), media=FakeMedia(),
                                     _seek_ui_guard_until=0,
                                     seek_slider=types.SimpleNamespace(value=lambda: 11111))
        finish = isolate_method('InternalVideoPlayer', '_finish_scrub')
        finish(fake)
        self.assertEqual(fake.media.seeks, [22222])
        self.assertFalse(fake._dragging)
        self.assertGreater(fake._seek_ui_guard_until, time.monotonic())

    def test_hover_stays_stopped_while_floating_player_is_visible(self):
        lib = cls('LibraryTab')
        for m in ('on_scroll_state', 'on_hover_row', 'on_visible_rows', 'on_preview_mode_combo'):
            body = source_of(method(lib, m))
            self.assertIn('self.has_open_players()', body, m)
        self.assertIn('self.library.shutdown_players()', SOURCE)

    def test_file_rename_deferred_while_player_is_using_file(self):
        body = source_of(method(cls('LibraryTab'), '_flush_rating_renames'))
        self.assertIn('self.is_file_playing(path)', body)
        self.assertIn('needs_retry_wait = True', body)
        self.assertIn('rename_video_for_rating(path, value)', body)

    def test_five_preview_anchors_remain_untouched(self):
        from preview_engine import PREVIEW_ANCHORS, PREVIEW_SEGMENT_SECONDS
        self.assertEqual(tuple(PREVIEW_ANCHORS), (0.1, .3, .5, .7, .9))
        self.assertEqual(PREVIEW_SEGMENT_SECONDS, 3)

if __name__ == '__main__':
    unittest.main()
