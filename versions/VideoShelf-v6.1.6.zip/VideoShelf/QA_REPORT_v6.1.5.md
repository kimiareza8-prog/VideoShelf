# VideoShelf v6.1.5 — Testing & limitations

## Changes
- Rating range 0–20 with crisp anti-aliased vector stars, smaller than v6.1.3.
- A rating of 15 renames `Film.mp4` to `Film [★15].mp4` in the same folder; changing to 6 replaces the previous suffix, and zero removes it.
- Existing `.videoshelf.json` ratings, favorites, collections and other per-file dictionary metadata migrate with real on-disk renames. Collisions abort without overwriting the target file.
- Deferred rating renames while the same video is open in the built-in player; once it closes, pending renames are retried.
- Resizable **independent window** internal player. Move the window via its native title bar to any screen corner; its position and dimensions are saved to `config.json` and reused for future videos.
- Mini, fit-to-screen, fullscreen, always-on-top, separate window-size and video crop-zoom controls.
- Timeline scrubbing has immediate on-screen time updates but coalesces seek requests, and commits the final exact requested time on mouse release. Note: image seek responsiveness depends on codec, media index and storage speed.
- Background live previews stop while the floating player is visible. Existing five preview anchors (10/30/50/70/90%, three source seconds at 2x) remain unchanged.

## Automated checks performed in the build environment
- `python -m py_compile` — all Python sources compile.
- `python -m unittest discover -s tests -v` — 47 tests passed, including prior regressions, rating rename and player seek coalescing logic.
- ZIP integrity test and content audit performed before delivery.

## NOT verified in this environment
- End-to-end playback / native window dragging / GPU video rendering on Windows 10 or 11, because PySide6 and Windows graphics backends are unavailable here.
- Frame-perfect seeking of every codec: keyframe spacing and Qt Multimedia/FFmpeg backend differ by device and file.
- Rendering and crop zoom behavior on multi-monitor, high-DPI Windows configurations: intended behavior is implemented but needs an on-device smoke test.

## Usage
- Extract the ZIP into a NEW folder, run `run.bat`.
- Double click a video to open the separate floating player window. Drag by its normal Windows title bar, resize using Windows borders, the `اندازه پنجره` slider, `کوچک`, `اندازه صفحه`, or `تمام‌صفحه`.
- `زوم تصویر` crops in smoothly (100–220%) without intentionally distorting the video aspect ratio.
- Player window geometry is stored in program `config.json`, but video ratings are stored in each media folder's `.videoshelf.json` and encoded in the file name itself.
- Rename changes REAL filenames. Ensure other programs are not holding those files open; make backup before a bulk 20-star rating session.
