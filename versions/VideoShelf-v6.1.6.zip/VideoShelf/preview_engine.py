"""Bounded live-preview decoder scheduling and FFmpeg command construction.

Qt-independent so process lifecycle and interpolation can be tested headlessly.
FFmpeg is an external process per source/seek; reusable *worker threads* (not
fictional reusable FFmpeg decoders) avoid unbounded thread/process creation.
"""
from __future__ import annotations

import math
import re
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable


# The same five source-time samples are used by mouse-hover and visible-card
# live previews. Keeping these here makes the timing independent of Qt.
PREVIEW_ANCHORS = (0.10, 0.30, 0.50, 0.70, 0.90)
PREVIEW_SEGMENT_SECONDS = 3.0


def preview_segment_start(duration: float, segment_index: int) -> float | None:
    """Return an exact percentage of a known video length (never time zero).

    A clip near the end of a *short* video can be shorter than three seconds.
    Do not shift a 90%-anchor back toward the beginning to fill the clip.
    """
    if not math.isfinite(duration) or duration <= 0:
        return None
    ratio = PREVIEW_ANCHORS[segment_index % len(PREVIEW_ANCHORS)]
    return duration * ratio


def probe_video_duration(ffmpeg_exe: str, path: str, timeout: float = 6.0) -> float:
    """Read container duration before seeking when the library has not scanned it.

    FFmpeg prints media info to stderr even when it has no output specified.
    An unknown duration is deliberately *not* substituted with 0: that would
    begin the preview at the very start, contrary to the selected anchors.
    """
    try:
        completed = subprocess.run(
            [ffmpeg_exe, '-hide_banner', '-nostdin', '-i', path],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            timeout=timeout,
            creationflags=(subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0),
        )
        output = completed.stderr.decode('utf-8', errors='replace')
        match = re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)', output)
        if match:
            return int(match[1]) * 3600 + int(match[2]) * 60 + float(match[3])
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass
    return 0.0


@dataclass(frozen=True)
class PreviewSpec:
    fps: int = 60
    speed: float = 2.0
    interpolate: bool = False
    width: int = 512
    height: int = 288
    segment_seconds: float = PREVIEW_SEGMENT_SECONDS

    def normalized(self) -> 'PreviewSpec':
        fps = max(24, min(60, int(self.fps)))
        speed = float(self.speed)
        if not math.isfinite(speed):
            speed = 2.0
        return PreviewSpec(fps, max(1.0, min(3.0, speed)), bool(self.interpolate),
                           max(16, min(1920, int(self.width))),
                           max(16, min(1080, int(self.height))),
                           max(1.0, min(180.0, float(self.segment_seconds))))


def ffmpeg_command(executable: str, path: str, start: float, spec: PreviewSpec,
                   gpu: bool = False) -> list[str]:
    """Decode at target *source-time* FPS, then consume at speed× wall FPS.

    minterpolate creates motion-compensated intermediate frames, not duplicated
    snapshots. It is intentionally opt-in because it can saturate CPUs.
    """
    s = spec.normalized()
    # Cap target source-time FPS so frame generation stays affordable at 3x.
    source_fps = max(8.0, min(60.0, s.fps / s.speed))
    filt = (f"scale={s.width}:{s.height}:force_original_aspect_ratio=increase:flags=bilinear,"
            f"crop={s.width}:{s.height},")
    if s.interpolate:
        # FFmpeg minterpolate frame-rate conversion uses adjacent decoded frames.
        filt += f"minterpolate=fps={source_fps:.4f}:mi_mode=mci:mc_mode=obmc:me_mode=bidir"
    else:
        filt += f"fps={source_fps:.4f}"
    return [
        executable, '-hide_banner', '-loglevel', 'error', '-nostdin',
        '-ss', f'{max(0.0, float(start)):.3f}', '-readrate', f'{s.speed:.2f}',
        *(['-hwaccel', 'auto'] if gpu else []),
        '-i', path, '-an', '-sn', '-dn', '-t', f'{s.segment_seconds:.3f}',
        '-vf', filt, '-threads', '0', '-pix_fmt', 'rgb24',
        '-f', 'rawvideo', 'pipe:1',
    ]


def terminate(proc: subprocess.Popen | None, hard: bool = False) -> None:
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.kill() if hard else proc.terminate()
    except (ProcessLookupError, OSError, ValueError):
        pass


class PreviewDecoderPool:
    """Persistent, bounded *worker-thread* pool with cooperative cancellation.

    Each hover generation owns its FFmpeg child. On rapid movement, queued
    obsolete generations are cancelled and running children terminated.
    No Qt objects are touched by these workers.
    """
    def __init__(self, max_workers: int = 2):
        self.lock = threading.RLock()
        self.events: dict[int, threading.Event] = {}
        self.processes: dict[int, subprocess.Popen] = {}
        self._futures = {}
        self._closing = False
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(3, max_workers)),
                                            thread_name_prefix='VideoShelfDecode')

    def submit(self, generation: int, work: Callable[[threading.Event], None]) -> None:
        with self.lock:
            if self._closing:
                return
            event = threading.Event()
            self.events[generation] = event
            def runner():
                if not event.is_set():
                    work(event)
            future = self._executor.submit(runner)
            self._futures[generation] = future
            def complete(_):
                with self.lock:
                    self.events.pop(generation, None)
                    self._futures.pop(generation, None)
                    self.processes.pop(generation, None)
            future.add_done_callback(complete)

    def attach(self, generation: int, process: subprocess.Popen):
        with self.lock:
            if self._closing or self.events.get(generation) is None or self.events[generation].is_set():
                terminate(process, hard=True)
                return False
            self.processes[generation] = process
            return True

    def detach(self, generation: int, process: subprocess.Popen):
        with self.lock:
            if self.processes.get(generation) is process:
                self.processes.pop(generation, None)

    def cancel_all(self, hard: bool = False):
        with self.lock:
            jobs = list(self.events.values())
            processes = list(self.processes.values())
            futures = list(self._futures.values())
            for event in jobs:
                event.set()
            for future in futures:
                future.cancel()
        for process in processes:
            terminate(process, hard=hard)

    def shutdown(self):
        with self.lock:
            if self._closing:
                return
            self._closing = True
        self.cancel_all(hard=True)
        self._executor.shutdown(wait=True, cancel_futures=True)
        with self.lock:
            self.events.clear()
            self.processes.clear()
            self._futures.clear()
