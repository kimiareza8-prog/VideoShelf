"""Regression tests for stable ratings, native in-app player and scroll scheduling.

Qt-free AST and behavioral tests allow running these on the CI/Linux build host;
actual Qt multimedia and Windows codecs still need a Windows smoke test.
"""
import ast
from pathlib import Path
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
TREE = ast.parse((ROOT / 'main.py').read_text(encoding='utf-8'))


def cls(name):
    return next(node for node in TREE.body if isinstance(node, ast.ClassDef) and node.name == name)


def method(obj, name):
    return next(node for node in obj.body if isinstance(node, ast.FunctionDef) and node.name == name)


def calls(node):
    return [n.func.attr for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)]


class RatingsStableTests(unittest.TestCase):
    def setUp(self):
        class FakeBase:
            def __init__(self):
                self.source = None
                self.dynamic = None
                self.sort_count = 0
            def setDynamicSortFilter(self, enabled):
                self.dynamic = enabled
            def sourceModel(self):
                return self.source
            def invalidate(self):
                pass
            def sort(self, *args):
                self.sort_count += 1
        Qt = types.SimpleNamespace(AscendingOrder=0)
        definition = cls('SortFilterProxy')
        module = ast.fix_missing_locations(ast.Module(body=[definition], type_ignores=[]))
        namespace = {'QSortFilterProxyModel': FakeBase, 'Qt': Qt}
        exec(compile(module, 'sort_proxy_test', 'exec'), namespace)
        self.proxy = namespace['SortFilterProxy']()
        self.items = [types.SimpleNamespace(path=f'/f/{n}', name=n, rating=r)
                      for n, r in [('a', 3), ('b', 8), ('c', 5)]]
        self.proxy.source = types.SimpleNamespace(items=self.items)
        self.idx = lambda row: types.SimpleNamespace(row=lambda: row)

    def test_rating_click_changes_value_but_not_comparison_position(self):
        self.assertFalse(self.proxy.dynamic)
        self.proxy.set_sort_key('rating')
        self.assertTrue(self.proxy.lessThan(self.idx(1), self.idx(0)))
        self.items[0].rating = 10
        self.assertTrue(self.proxy.lessThan(self.idx(1), self.idx(0)))
        self.assertEqual(self.proxy._rating_sort_snapshot['/f/a'], 3)

    def test_user_can_explicitly_apply_updated_rating_order(self):
        self.proxy.set_sort_key('rating')
        self.items[0].rating = 10
        self.proxy.apply_rating_order()
        self.assertTrue(self.proxy.lessThan(self.idx(0), self.idx(1)))
        self.assertEqual(self.proxy._rating_sort_snapshot['/f/a'], 10)

    def test_rating_handlers_do_not_automatically_sort_or_invalidate(self):
        library = cls('LibraryTab')
        for name in ('on_rating_requested', 'rate_selected'):
            self.assertNotIn('sort', calls(method(library, name)))
            self.assertNotIn('invalidateFilter', calls(method(library, name)))
        self.assertIn('setCurrentIndex', calls(method(library, 'on_scan_ready')))
        body = ast.unparse(method(library, 'on_scan_ready'))
        self.assertIn('files_fingerprint == self._last_scan_files_fingerprint', body)


class PlayerAndPreviewTests(unittest.TestCase):
    def test_player_is_embedded_with_native_media_and_seek(self):
        player = cls('InternalVideoPlayer')
        for name in ('open_file', 'stop', 'seek_relative', 'toggle_play', '_playback_error'):
            self.assertIsNotNone(method(player, name))
        self.assertIn('setSource', calls(method(player, 'open_file')))
        self.assertIn('play', calls(method(player, 'open_file')))
        self.assertIn('stop_all_previews', calls(method(cls('LibraryTab'), 'play_internal')))
        # v6.1.5 upgrades the previously embedded player to a draggable window.
        self.assertIn('show_player', calls(method(player, 'open_file')))
        self.assertNotIn('setCurrentWidget', calls(method(cls('LibraryTab'), 'play_internal')))
        self.assertIn('PySide6>=6.7', (ROOT/'requirements.txt').read_text(encoding='utf-8'))

    def test_live_cards_do_not_rotate_or_restart_while_scrolling(self):
        preview = cls('VisibleLivePreviews')
        for name in ('set_visible', 'update_settings'):
            self.assertNotIn('start', calls(method(preview, name)))
        self.assertIn('set_scrolling', [x.name for x in preview.body if isinstance(x, ast.FunctionDef)])
        self.assertIn('stop', calls(method(cls('LibraryTab'), 'on_scroll_state')))
        view = cls('SmartVideoView')
        self.assertIn('emit', calls(method(view, '_scroll_moved')))
        self.assertIn('emit_visible_rows', calls(method(view, '_scroll_settled')))


if __name__ == '__main__':
    unittest.main()
