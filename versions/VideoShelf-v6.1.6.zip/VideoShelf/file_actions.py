"""Portable, collision-safe movie move operations independent of Qt."""
from __future__ import annotations
import json
import errno
import os
import shutil
import uuid
from pathlib import Path

SIDECAR = '.videoshelf.json'
SECTIONS = ('ratings', 'favorites', 'collections')


def _read_sidecar(folder: Path) -> dict:
    path = folder / SIDECAR
    if not path.exists():
        return {'version': 1}
    obj = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(obj, dict):
        raise ValueError(f'Invalid VideoShelf metadata: {path}')
    return obj


def _write_sidecar(folder: Path, obj: dict):
    target = folder / SIDECAR
    # Other portable maps may be added in future versions (e.g. watch progress).
    # Never delete their records when the last rating is cleared.
    if not any(value for key, value in obj.items() if key != 'version'):
        target.unlink(missing_ok=True)
        return
    temp = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def _move_file(source: Path, candidate: Path):
    """Fast same-volume rename or staged cross-volume copy with rollback.

    A partially copied file is never exposed under its final destination name.
    Original is deleted only after a complete staged copy exists.
    """
    if candidate.exists() or candidate.is_symlink():
        raise FileExistsError(str(candidate))
    try:
        os.rename(source, candidate)
        return
    except OSError as exc:
        if exc.errno != errno.EXDEV and getattr(exc, 'winerror', None) != 17:
            raise

    staging = candidate.with_name(candidate.name + '.' + uuid.uuid4().hex + '.partial')
    published = False
    try:
        shutil.copy2(source, staging)
        if staging.stat().st_size != source.stat().st_size:
            raise OSError('Cross-drive copy size mismatch')
        if candidate.exists() or candidate.is_symlink():
            raise FileExistsError(str(candidate))
        os.replace(staging, candidate)
        published = True
        source.unlink()  # Commit: only remove source after copy fully succeeded.
    except Exception:
        staging.unlink(missing_ok=True)
        if published and source.exists():
            candidate.unlink(missing_ok=True)
        raise


def move_video(path: str, destination_dir: str) -> str:
    """Move video plus portable metadata; never overwrite destination files.

    First stage destination sidecar, roll back file and metadata on failure;
    only then remove source sidecar entries. Unexpected source sidecar errors
    are reported rather than silently pretending the move was lossless.
    """
    source = Path(path).resolve(strict=True)
    if not source.is_file():
        raise ValueError(f'Not a file: {source}')
    directory = Path(destination_dir).resolve(strict=True)
    if not directory.is_dir():
        raise NotADirectoryError(str(directory))
    if source.parent == directory:
        return str(source)

    src_data = _read_sidecar(source.parent)
    moved_values = {}
    for field in SECTIONS:
        values = src_data.get(field, {})
        if isinstance(values, dict):
            for name, value in values.items():
                if str(name).casefold() == source.name.casefold():
                    moved_values[field] = value
                    break

    candidate = directory / source.name
    counter = 2
    while candidate.exists() or candidate.is_symlink():
        candidate = directory / f'{source.stem} ({counter}){source.suffix}'
        counter += 1
    dst_before = _read_sidecar(directory)
    dst_data = json.loads(json.dumps(dst_before))  # no mutation to backup
    for field, value in moved_values.items():
        section = dst_data.setdefault(field, {})
        if not isinstance(section, dict):
            section = {}
            dst_data[field] = section
        # No stale rating from a previously-deleted destination name.
        for name in list(section):
            if str(name).casefold() == candidate.name.casefold():
                section.pop(name, None)
        if value:
            section[candidate.name] = value

    # Stage metadata BEFORE moving the file so a read-only destination cannot
    # strand a moved movie without its rating. Roll back on move failure.
    staged = False
    try:
        if moved_values:
            _write_sidecar(directory, dst_data)
            staged = True
        _move_file(source, candidate)
    except Exception:
        if staged:
            _write_sidecar(directory, dst_before)
        raise

    try:
        if moved_values:
            for field in SECTIONS:
                section = src_data.get(field, {})
                if isinstance(section, dict):
                    for name in list(section):
                        if str(name).casefold() == source.name.casefold():
                            section.pop(name, None)
            _write_sidecar(source.parent, src_data)
    except Exception as exc:
        # Never silently discard metadata. Roll the video back if possible.
        try:
            _move_file(candidate, source)
            if staged:
                _write_sidecar(directory, dst_before)
        except Exception as rollback_exc:
            raise RuntimeError(f'Moved to {candidate}, but metadata cleanup failed: {exc}; rollback failed: {rollback_exc}') from exc
        raise RuntimeError(f'Move rolled back; source metadata was not writable: {exc}') from exc
    return str(candidate)
