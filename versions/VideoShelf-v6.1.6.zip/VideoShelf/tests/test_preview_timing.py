"""v6.1.2: percentage anchors, short segments and never fallback to time zero."""
import ast
import tempfile
import subprocess
import unittest
from pathlib import Path

from preview_engine import (
    PREVIEW_ANCHORS, PREVIEW_SEGMENT_SECONDS,
    PreviewSpec, ffmpeg_command, preview_segment_start, probe_video_duration,
)


ROOT = Path(__file__).resolve().parents[1]


class PreviewTimingTests(unittest.TestCase):
    def test_five_exact_percentage_anchors_for_movie(self):
        self.assertEqual(PREVIEW_ANCHORS, (.10, .30, .50, .70, .90))
        self.assertEqual(PREVIEW_SEGMENT_SECONDS, 3.)
        self.assertEqual([preview_segment_start(100., i) for i in range(6)],
                         [10., 30., 50., 70., 90., 10.])
        self.assertTrue(all(preview_segment_start(100., i) > 0 for i in range(5)))

    def test_unknown_duration_never_seeks_from_zero(self):
        for bad in (0, -1, float('nan'), float('inf')):
            self.assertIsNone(preview_segment_start(bad, 0))
        self.assertAlmostEqual(preview_segment_start(2.5, 0), .25)
        self.assertAlmostEqual(preview_segment_start(2.5, 4), 2.25)

    def test_ffmpeg_command_is_three_source_seconds_at_2x(self):
        for i in range(5):
            start = preview_segment_start(100.0, i)
            cmd = ffmpeg_command('ffmpeg', 'video.mp4', start,
                                 PreviewSpec(fps=60, speed=2.,
                                             segment_seconds=PREVIEW_SEGMENT_SECONDS))
            self.assertEqual(cmd[cmd.index('-ss') + 1], f'{start:.3f}')
            self.assertEqual(cmd[cmd.index('-t') + 1], '3.000')
            self.assertEqual(cmd[cmd.index('-readrate') + 1], '2.00')

    def test_hover_and_visible_card_use_same_engine(self):
        source = (ROOT / 'main.py').read_text(encoding='utf-8')
        tree = ast.parse(source)
        hover = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                     and n.name == 'SmoothHoverPreview')
        visible = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                       and n.name == 'VisibleCardPreview')
        self.assertEqual(visible.bases[0].id, 'SmoothHoverPreview')
        self.assertIn('probe_video_duration(self._ffmpeg, path)', source)
        self.assertIn('PREVIEW_SEGMENT_SECONDS', source)

    def test_probe_ffmpeg_container_length(self):
        try:
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            self.skipTest('ffmpeg unavailable')
        with tempfile.TemporaryDirectory() as td:
            movie = str(Path(td) / 'sample.mp4')
            result = subprocess.run([exe, '-hide_banner', '-loglevel', 'error',
                                     '-f', 'lavfi', '-i',
                                     'color=c=black:s=64x64:r=10:d=4',
                                     '-c:v', 'mpeg4', '-y', movie],
                                    capture_output=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr.decode(errors='replace'))
            duration = probe_video_duration(exe, movie)
            self.assertAlmostEqual(duration, 4., delta=.15)
            self.assertGreater(preview_segment_start(duration, 0), 0)


if __name__ == '__main__':
    unittest.main()
