# VideoShelf v6.1.3 — QA report

## Automated checks

- 27 inherited tests: pass
- 5 new tests: stable rating comparator, explicit rating refresh, rating handlers, integrated player hooks, scroll-safe visible previews
- `python -m compileall`: pass for all source files
- ZIP CRC/structure: checked during packaging

## Changes and ownership

- `SortFilterProxy` freezes the rating-order snapshot until the user presses «اعمال ترتیب جدید ★».
- `on_scan_ready` avoids full model resets when only portable sidecars change.
- `InternalVideoPlayer` uses one long-lived Qt Multimedia instance on a `QStackedWidget` page. It is native and entirely inside the app window.
- Opening the player calls `stop_all_previews` before starting QMediaPlayer.
- Scroll changes emit immediate pause/cancel for visible FFmpeg slots; after 190ms of no scrollbar change the *current* viewport list is applied.
- The periodic visible-slot rotation is disabled to avoid churn; the hover path is the highest-priority visible thumbnail when more than the configured limit is on-screen.

## NOT tested in this environment

- PySide6 QtWidgets/QtMultimedia runtime: modules are unavailable here.
- Actual Windows playback and codecs/seek on Python 3.13.
- Frame pacing and responsiveness on 4K or many-video libraries.

## Windows smoke test

1. Unzip into an empty folder and run `run.bat`; the full PySide6 package is required for native playback.
2. With Sort «امتیاز ★», scroll down and rate a card. Its position must not move. Click «اعمال ترتیب جدید ★» to reorder.
3. Set Preview «روی صفحه», scroll quickly, then stop: live card previews should resume only after scrolling stops, with no automatic reshuffle every 2.5 seconds.
4. Double-click any video, confirm in-window playback, audio and seeking; press Esc to go back to library.
5. If a codec fails to load, try the explicit external-player button and inspect Qt Multimedia backend/codec support.
