import ast
import base64
import hashlib
import importlib
import json
import os
import shutil
import sys
import tempfile
import time
import types
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from library_core import LibraryCatalog, library_folders, duplicate_groups


def portable_functions():
    module = ast.parse((ROOT / 'main.py').read_text(encoding='utf-8'))
    needed = {
        'folder_metadata_path', '_load_folder_metadata', 'read_local_rating',
        'write_local_rating', '_portable_value', '_write_portable_field',
        'read_local_favorite', 'read_local_collections', 'clear_portable_video_metadata',
    }
    nodes = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in needed]
    env = {'Path': Path, 'Optional': __import__('typing').Optional, 'os': os,
           'json': json, 'MAX_RATING': 10, 'FOLDER_META_FILENAME': '.videoshelf.json'}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(ROOT / 'main.py'), 'exec'), env)
    return env


class CatalogTests(unittest.TestCase):
    def test_folder_dedup_and_order(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = str(Path(d) / 'A'), str(Path(d) / 'B')
            folders = library_folders({'folder': a, 'folders': [a, b, b]})
            self.assertEqual(folders, [a, b])

    def test_sqlite_reopens_and_invalidates_changed_file(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'movie.mp4'
            path.write_bytes(b'abc')
            st = path.stat()
            rows = [(str(path), path.name, st.st_size, st.st_mtime)]
            db_file = Path(d) / 'catalog.sqlite3'
            db = LibraryCatalog(db_file)
            db.index_scan(rows)
            db.store_metadata(str(path), 120.0, 1920, 1080)
            self.assertEqual(db.cached_metadata(rows)[str(path)], (120.0, 1920, 1080))
            self.assertEqual(LibraryCatalog(db_file).cached_metadata(rows)[str(path)][0], 120.0)
            path.write_bytes(b'abcdefg')
            st = path.stat()
            new_rows = [(str(path), path.name, st.st_size, st.st_mtime)]
            db.index_scan(new_rows)
            self.assertNotIn(str(path), db.cached_metadata(new_rows))

    def test_duplicate_exact_content_only(self):
        with tempfile.TemporaryDirectory() as d:
            a, b, c = [Path(d) / f'{x}.mp4' for x in ('A', 'B', 'C')]
            a.write_bytes(b'alpha' * 20000)
            b.write_bytes(a.read_bytes())
            c.write_bytes(b'bravo' * 20000)
            self.assertEqual(duplicate_groups([str(a), str(b), str(c)]), [[str(a), str(b)]])

    def test_metadata_is_portable_and_fields_are_preserved(self):
        env = portable_functions()
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / 'Movies'
            folder.mkdir()
            video = folder / 'movie.mp4'
            video.write_bytes(b'data')
            self.assertTrue(env['write_local_rating'](str(video), 8))
            self.assertTrue(env['_write_portable_field'](str(video), 'favorites', True))
            self.assertTrue(env['_write_portable_field'](str(video), 'collections', ['Sci-Fi', 'Watch later']))
            self.assertTrue(env['write_local_rating'](str(video), 9))
            json_path = folder / '.videoshelf.json'
            data = json.loads(json_path.read_text(encoding='utf-8'))
            self.assertEqual(data['ratings']['movie.mp4'], 9)
            self.assertTrue(data['favorites']['movie.mp4'])
            self.assertEqual(data['collections']['movie.mp4'], ['Sci-Fi', 'Watch later'])
            moved = Path(d) / 'Moved'
            folder.rename(moved)
            copied_path = moved / 'movie.mp4'
            self.assertEqual(env['read_local_rating'](str(copied_path)), 9)
            self.assertTrue(env['read_local_favorite'](str(copied_path)))
            self.assertEqual(env['read_local_collections'](str(copied_path)), ['Sci-Fi', 'Watch later'])
            env['clear_portable_video_metadata'](str(copied_path))
            self.assertFalse((moved / '.videoshelf.json').exists())


class WebAuthTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # cloud_share's HTTP classes need only QObject/Signal at import time.
        qt = types.ModuleType('PySide6.QtCore')
        qt.QObject = type('QObject', (), {'__init__': lambda self, *args, **kwargs: None})
        qt.Signal = lambda *args: object()
        root = types.ModuleType('PySide6')
        root.QtCore = qt
        sys.modules.setdefault('PySide6', root)
        sys.modules.setdefault('PySide6.QtCore', qt)
        cls.cloud = importlib.import_module('cloud_share')

    def test_expiry_password_and_old_token_invalidation(self):
        web = self.cloud.LocalWebLibrary('/usr/bin/ffmpeg')
        web.state.expire_minutes = 15
        web.state.set_password('secret-pass')
        port = web.start()
        base = f'http://127.0.0.1:{port}'
        token = web.token
        def status(url, password=None):
            headers = {}
            if password is not None:
                key = base64.b64encode(('guest:' + password).encode()).decode()
                headers['Authorization'] = 'Basic ' + key
            request = urllib.request.Request(url, headers=headers)
            try:
                with urllib.request.urlopen(request, timeout=3) as response:
                    return response.status
            except urllib.error.HTTPError as exc:
                return exc.code
        try:
            self.assertEqual(status(base + '/health'), 200)
            self.assertEqual(status(base + '/api/videos?token=wrong'), 403)
            protected = base + '/api/videos?token=' + token
            self.assertEqual(status(protected), 401)
            self.assertEqual(status(protected, 'bad'), 401)
            self.assertEqual(status(protected, 'secret-pass'), 200)
            web.state.token_expires_at = time.time() - 1
            self.assertEqual(status(protected, 'secret-pass'), 403)
        finally:
            web.stop()
        self.assertNotEqual(token, web.token)

    def test_server_side_pagination_filters_and_sort(self):
        with tempfile.TemporaryDirectory() as d:
            web = self.cloud.LocalWebLibrary('/usr/bin/ffmpeg')
            data = []
            for idx in range(9):
                f = Path(d) / f'movie{idx}.mp4'
                f.write_bytes(b'file' + bytes([idx]))
                data.append({'path': str(f), 'name': f.name, 'size': idx + 1,
                             'rating': idx + 1, 'favorite': (idx % 2 == 0),
                             'width': 1920, 'height': 1080})
            web.state.update_videos(data)
            port = web.start()
            base = f'http://127.0.0.1:{port}/api/videos?token={web.token}'
            try:
                query = '&page=0&limit=2&sort=rating&rating=5&kind=favorites'
                with urllib.request.urlopen(base + query, timeout=4) as response:
                    first = json.load(response)
                self.assertEqual(first['total'], 3)  # ratings 5, 7, 9
                self.assertEqual([x['rating'] for x in first['videos']], [9, 7])
                self.assertTrue(first['hasMore'])
                with urllib.request.urlopen(base + query.replace('page=0', 'page=1'), timeout=4) as response:
                    second = json.load(response)
                self.assertEqual([x['rating'] for x in second['videos']], [5])
                self.assertFalse(second['hasMore'])
                with urllib.request.urlopen(base + '&page=0&limit=4&q=movie8', timeout=4) as response:
                    search = json.load(response)
                self.assertEqual(search['total'], 1)
            finally:
                web.stop()


if __name__ == '__main__':
    unittest.main(verbosity=2)
