@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title VideoShelf 6.1.6 - Iran Mirrors

set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PIP_DEFAULT_TIMEOUT=60"

where py >nul 2>&1
if %errorlevel%==0 (set "PY=py") else (set "PY=python")

echo ==========================================
echo VideoShelf 6.1.6
echo ==========================================
%PY% --version
echo.
echo [1/3] Novin Cloud Iran mirror...
%PY% -m pip install --prefer-binary --timeout 60 --retries 2 ^
  --index-url https://mirror.novin.cloud/artifactory/api/pypi/pypi/simple/ ^
  --trusted-host mirror.novin.cloud ^
  -r requirements.txt
if not errorlevel 1 goto installed

echo.
echo [2/3] Runflare Iran mirror...
%PY% -m pip install --prefer-binary --timeout 60 --retries 2 ^
  --index-url https://mirror-pypi.runflare.com/simple ^
  --trusted-host mirror-pypi.runflare.com ^
  -r requirements.txt
if not errorlevel 1 goto installed

echo.
echo [3/3] Official PyPI fallback...
%PY% -m pip install --prefer-binary --timeout 90 --retries 4 ^
  --index-url https://pypi.org/simple ^
  -r requirements.txt
if errorlevel 1 goto failed

:installed
echo.
echo Starting VideoShelf 6.1.6...
%PY% main.py
if errorlevel 1 (
  echo.
  echo VideoShelf exited with an error.
  pause
)
exit /b 0

:failed
echo.
echo ERROR: Could not install dependencies.
%PY% -m pip config list
pause
exit /b 1
