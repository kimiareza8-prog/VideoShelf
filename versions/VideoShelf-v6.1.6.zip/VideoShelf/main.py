
import sys
import os
import re
import json
import time
import shutil
import hashlib
import threading
import subprocess
import tempfile
import webbrowser
import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from collections import OrderedDict, deque
from typing import Optional

from PySide6.QtCore import (
    Qt, QSize, QRect, QPoint, QTimer, Signal, QObject, QRunnable, QThreadPool,
    QAbstractListModel, QModelIndex, QSortFilterProxyModel, QItemSelectionModel,
    QPropertyAnimation, QAbstractAnimation, QEasingCurve, QUrl, QEvent
)
from PySide6.QtGui import (
    QPixmap, QImage, QPainter, QColor, QFont, QPainterPath, QPen, QBrush, QFontMetrics, QLinearGradient, QCursor, QShortcut, QKeySequence
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFileDialog, QTabWidget, QMessageBox, QComboBox, QSlider, QSpinBox,
    QFrame, QProgressBar, QListView, QAbstractItemView, QStyledItemDelegate,
    QStyle, QButtonGroup, QMenu, QScrollArea, QPlainTextEdit, QStackedWidget, QGridLayout,
    QGraphicsOpacityEffect, QDialog, QDialogButtonBox, QListWidget, QListWidgetItem, QCheckBox, QSizePolicy
)

# Qt Multimedia is included with the full PySide6 distribution. Show a useful
# fallback when an old Essentials-only installation is still present.
try:
    from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
    from PySide6.QtMultimediaWidgets import QVideoWidget
except ImportError:
    QMediaPlayer = QAudioOutput = QVideoWidget = None

import imageio_ffmpeg
from send2trash import send2trash
from cloud_share import CloudShareManager
from library_core import LibraryCatalog, library_folders, duplicate_groups
from preview_engine import (
    PreviewSpec, ffmpeg_command, PreviewDecoderPool, terminate,
    PREVIEW_ANCHORS, PREVIEW_SEGMENT_SECONDS, preview_segment_start, probe_video_duration,
)
from visible_scheduler import select_visible_live_paths
from file_actions import move_video
from rating_names import rename_video_for_rating, rated_filename, rating_from_filename
try:
    import psutil  # optional performance counters
except ImportError:
    psutil = None


APP_NAME = "VideoShelf"
APP_VERSION = "6.1.6 Precision Mouse Scroll + Multi-Window Player"
MAX_RATING = 20
FOLDER_META_FILENAME = ".videoshelf.json"

VIDEO_EXTS = {
    ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".webm", ".mpeg", ".mpg",
    ".ts", ".m2ts", ".mts", ".flv", ".3gp", ".vob"
}

ROLE_BASE = int(Qt.UserRole) + 100
PATH_ROLE = ROLE_BASE + 1
NAME_ROLE = ROLE_BASE + 2
SIZE_ROLE = ROLE_BASE + 3
MTIME_ROLE = ROLE_BASE + 4
DURATION_ROLE = ROLE_BASE + 5
RESOLUTION_ROLE = ROLE_BASE + 6
POSTER_ROLE = ROLE_BASE + 7
PREVIEW_ROLE = ROLE_BASE + 8
PREVIEW_ACTIVE_ROLE = ROLE_BASE + 9
META_READY_ROLE = ROLE_BASE + 10
RATING_ROLE = ROLE_BASE + 11
FAVORITE_ROLE = ROLE_BASE + 12
COLLECTIONS_ROLE = ROLE_BASE + 13

WIN_FLAGS = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT = app_root()
CONFIG_PATH = ROOT / "config.json"
CACHE_DIR = ROOT / "cache" / "previews"


def ffmpeg_path() -> str:
    return imageio_ffmpeg.get_ffmpeg_exe()


def human_size(num: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(max(0, num))
    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit in ("GB", "TB"):
                return f"{value:.2f} {unit}"
            if unit == "MB":
                return f"{value:.1f} {unit}"
            return f"{value:.0f} {unit}"
        value /= 1024
    return f"{num} B"


def human_duration(seconds: float) -> str:
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def load_config() -> dict:
    defaults = {
        "folder": "",
        "recursive": True,
        "preview_mode": "hover",
        "cache_enabled": False,
        "clear_cache_on_exit": False,
        "card_width": 286,
        "workers": max(2, min(6, (os.cpu_count() or 4) // 2)),
        "sort": "name",
        "ram_limit_mb": 384,
        "hover_fps": 4,
        "hover_video_fps": 60,
        "hover_video_speed": 2.0,
        "visible_fps": 1,  # legacy: replaced by live FFmpeg in 6.1.1
        "visible_live_limit": 8,
        "ratings": {},
        "folders": [],
        "watch_folders": True,
        "gpu_decode": False,
        "hover_interpolation": False,
        "share_expire_minutes": 240,
    }
    if CONFIG_PATH.exists():
        try:
            loaded = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                defaults.update(loaded)
        except Exception:
            pass
    return defaults


def save_config(cfg: dict):
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def rating_key(path: str) -> str:
    # Legacy config key. Kept only for migration/fallback from pre-4.8 versions.
    try:
        return os.path.normcase(os.path.abspath(path))
    except Exception:
        return str(path)


def folder_metadata_path(video_path: str) -> Path:
    return Path(video_path).parent / FOLDER_META_FILENAME


def _load_folder_metadata(folder: Path) -> dict:
    meta_path = folder / FOLDER_META_FILENAME
    if not meta_path.exists():
        return {"version": 1, "ratings": {}}
    try:
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("metadata root is not an object")
        ratings = data.get("ratings", {})
        if not isinstance(ratings, dict):
            ratings = {}
        data["ratings"] = ratings
        for field_name in ("favorites", "collections"):
            if not isinstance(data.get(field_name, {}), dict):
                data[field_name] = {}
        return data
    except Exception:
        # A damaged sidecar must never block the library scan.
        return {"version": 1, "ratings": {}}


def read_local_rating(video_path: str) -> Optional[int]:
    p = Path(video_path)
    data = _load_folder_metadata(p.parent)
    ratings = data.get("ratings", {})
    wanted = p.name.casefold()
    for name, value in ratings.items():
        if str(name).casefold() != wanted:
            continue
        try:
            return max(0, min(MAX_RATING, int(value)))
        except Exception:
            return 0
    return None


def write_local_rating(video_path: str, rating: int) -> bool:
    """Persist a rating beside the video so it survives app reinstall/moves.

    One .videoshelf.json is used per physical folder. Keys are file names rather
    than absolute paths, so moving the whole folder does not break ratings.
    """
    p = Path(video_path)
    folder = p.parent
    meta_path = folder / FOLDER_META_FILENAME
    tmp_path = folder / (FOLDER_META_FILENAME + ".tmp")
    value = max(0, min(MAX_RATING, int(rating)))
    try:
        data = _load_folder_metadata(folder)
        ratings = data.setdefault("ratings", {})
        if not isinstance(ratings, dict):
            ratings = {}
            data["ratings"] = ratings

        # Windows paths are case-insensitive. Remove case variants before writing.
        wanted = p.name.casefold()
        for old_name in list(ratings):
            if str(old_name).casefold() == wanted:
                ratings.pop(old_name, None)
        if value:
            ratings[p.name] = value

        if not any(v for k, v in data.items() if k != 'version'):
            if meta_path.exists():
                meta_path.unlink()
            if tmp_path.exists():
                tmp_path.unlink()
            return True

        payload = data  # Preserve favorites, collections, and future metadata fields.
        tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp_path, meta_path)
        return True
    except Exception:
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except Exception:
            pass
        return False




def _portable_value(video_path: str, field_name: str, fallback=None):
    data = _load_folder_metadata(Path(video_path).parent)
    values = data.get(field_name, {})
    if isinstance(values, dict):
        for name, value in values.items():
            if str(name).casefold() == Path(video_path).name.casefold():
                return value
    return fallback


def _write_portable_field(video_path: str, field_name: str, value) -> bool:
    """Atomic folder-local write; all fields survive each other's updates."""
    p = Path(video_path)
    metadata = folder_metadata_path(video_path)
    tmp = metadata.with_name(metadata.name + '.tmp')
    try:
        data = _load_folder_metadata(p.parent)
        values = data.get(field_name, {})
        if not isinstance(values, dict):
            values = {}
        for old in list(values):
            if str(old).casefold() == p.name.casefold():
                values.pop(old)
        if value:
            values[p.name] = value
        data[field_name] = values
        if not any(v for k, v in data.items() if k != 'version'):
            metadata.unlink(missing_ok=True)
        else:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
            os.replace(tmp, metadata)
        return True
    except (OSError, TypeError, ValueError):
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        return False


def read_local_favorite(video_path: str) -> bool:
    return bool(_portable_value(video_path, 'favorites', False))


def read_local_collections(video_path: str) -> list[str]:
    value = _portable_value(video_path, 'collections', [])
    return [x for x in value if isinstance(x, str)] if isinstance(value, list) else []


def clear_portable_video_metadata(video_path: str) -> None:
    write_local_rating(video_path, 0)
    _write_portable_field(video_path, 'favorites', False)
    _write_portable_field(video_path, 'collections', [])


def clear_cache_dir():
    if CACHE_DIR.exists():
        shutil.rmtree(CACHE_DIR, ignore_errors=True)


def cache_key(path: str) -> str:
    p = Path(path)
    try:
        st = p.stat()
        raw = f"{p.resolve()}|{st.st_size}|{st.st_mtime_ns}"
    except OSError:
        raw = str(p.resolve())
    return hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()


def run_hidden(cmd, **kwargs):
    kwargs.setdefault("creationflags", WIN_FLAGS)
    return subprocess.run(cmd, **kwargs)


def parse_jpeg_stream(data: bytes) -> list[bytes]:
    frames = []
    pos = 0
    while True:
        start = data.find(b"\xff\xd8", pos)
        if start < 0:
            break
        end = data.find(b"\xff\xd9", start + 2)
        if end < 0:
            break
        frames.append(data[start:end + 2])
        pos = end + 2
    return frames


@dataclass
class VideoItem:
    path: str
    name: str
    size: int
    mtime: float
    duration: float = 0.0
    width: int = 0
    height: int = 0
    meta_ready: bool = False
    poster: Optional[QPixmap] = None
    preview_frames: list[QPixmap] = field(default_factory=list)
    preview_quality: int = 0  # 0 none, 1 lightweight visible, 2 full hover
    preview_frame_index: int = 0
    preview_active: bool = False
    rating: int = 0
    favorite: bool = False
    collections: list[str] = field(default_factory=list)

    @property
    def resolution(self) -> str:
        return f"{self.width}×{self.height}" if self.width and self.height else ""


class VideoModel(QAbstractListModel):
    def __init__(self):
        super().__init__()
        self.items: list[VideoItem] = []
        self.path_to_row: dict[str, int] = {}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.items)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self.items)):
            return None
        item = self.items[index.row()]
        if role in (Qt.DisplayRole, NAME_ROLE):
            return item.name
        if role == PATH_ROLE:
            return item.path
        if role == SIZE_ROLE:
            return item.size
        if role == MTIME_ROLE:
            return item.mtime
        if role == DURATION_ROLE:
            return item.duration
        if role == RESOLUTION_ROLE:
            return item.resolution
        if role == POSTER_ROLE:
            return item.poster
        if role == PREVIEW_ROLE:
            if item.preview_frames:
                return item.preview_frames[item.preview_frame_index % len(item.preview_frames)]
            return None
        if role == PREVIEW_ACTIVE_ROLE:
            return item.preview_active
        if role == META_READY_ROLE:
            return item.meta_ready
        if role == RATING_ROLE:
            return item.rating
        if role == FAVORITE_ROLE:
            return item.favorite
        if role == COLLECTIONS_ROLE:
            return item.collections
        return None

    def set_items(self, items: list[VideoItem]):
        self.beginResetModel()
        self.items = items
        self._reindex()
        self.endResetModel()

    def clear(self):
        self.set_items([])

    def _reindex(self):
        self.path_to_row = {x.path: i for i, x in enumerate(self.items)}

    def row_for_path(self, path: str) -> int:
        return self.path_to_row.get(path, -1)

    def item_for_path(self, path: str) -> Optional[VideoItem]:
        row = self.row_for_path(path)
        return self.items[row] if row >= 0 else None

    def notify_row(self, row: int, roles=None):
        if 0 <= row < len(self.items):
            idx = self.index(row, 0)
            self.dataChanged.emit(idx, idx, roles or [])

    def set_metadata(self, path: str, duration: float, w: int, h: int):
        row = self.row_for_path(path)
        if row < 0:
            return
        item = self.items[row]
        item.duration = duration
        item.width = w
        item.height = h
        item.meta_ready = True
        self.notify_row(row, [DURATION_ROLE, RESOLUTION_ROLE, META_READY_ROLE])

    def set_poster(self, path: str, pixmap: QPixmap):
        row = self.row_for_path(path)
        if row < 0:
            return
        self.items[row].poster = pixmap
        self.notify_row(row, [POSTER_ROLE])

    def set_rating(self, path: str, rating: int):
        row = self.row_for_path(path)
        if row < 0:
            return
        value = max(0, min(MAX_RATING, int(rating)))
        if self.items[row].rating == value:
            return
        self.items[row].rating = value
        self.notify_row(row, [RATING_ROLE])

    def rename_item_path(self, old_path: str, new_path: str):
        """Rename in place: never reset the model or lose the viewport index."""
        row = self.row_for_path(old_path)
        if row < 0 or old_path == new_path:
            return
        item = self.items[row]
        self.path_to_row.pop(old_path, None)
        self.path_to_row[new_path] = row
        item.path = new_path
        item.name = Path(new_path).name
        self.notify_row(row, [PATH_ROLE, NAME_ROLE, Qt.DisplayRole])

    def set_favorite(self, path: str, value: bool):
        row = self.row_for_path(path)
        if row >= 0 and self.items[row].favorite != bool(value):
            self.items[row].favorite = bool(value)
            self.notify_row(row, [FAVORITE_ROLE])

    def set_collections(self, path: str, values: list[str]):
        row = self.row_for_path(path)
        if row >= 0:
            self.items[row].collections = list(values)
            self.notify_row(row, [COLLECTIONS_ROLE])

    def set_preview(self, path: str, frames: list[QPixmap], quality: int):
        row = self.row_for_path(path)
        if row < 0:
            return
        item = self.items[row]
        item.preview_frames = frames
        item.preview_quality = max(item.preview_quality, quality)
        item.preview_frame_index = 0
        self.notify_row(row, [PREVIEW_ROLE])

    def set_preview_active(self, path: str, active: bool):
        row = self.row_for_path(path)
        if row < 0:
            return
        item = self.items[row]
        if item.preview_active != active:
            item.preview_active = active
            self.notify_row(row, [PREVIEW_ACTIVE_ROLE])

    def advance_preview(self, path: str):
        row = self.row_for_path(path)
        if row < 0:
            return
        item = self.items[row]
        if not item.preview_frames:
            return
        item.preview_frame_index = (item.preview_frame_index + 1) % len(item.preview_frames)
        self.notify_row(row, [PREVIEW_ROLE])

    def clear_preview(self, path: str):
        row = self.row_for_path(path)
        if row < 0:
            return
        item = self.items[row]
        item.preview_frames = []
        item.preview_quality = 0
        item.preview_frame_index = 0
        item.preview_active = False
        self.notify_row(row, [PREVIEW_ROLE, PREVIEW_ACTIVE_ROLE])

    def remove_paths(self, paths: list[str]):
        rows = sorted(
            [self.path_to_row[p] for p in paths if p in self.path_to_row],
            reverse=True
        )
        for row in rows:
            self.beginRemoveRows(QModelIndex(), row, row)
            self.items.pop(row)
            self.endRemoveRows()
        self._reindex()


class SortFilterProxy(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.filter_text = ""
        self.sort_key = "name"
        self.filter_rating = 0
        self.filter_quality = 'all'
        self.filter_extension = 'all'
        self.filter_favorites = False
        self.filter_collection = ''
        # Live rating edits must never rearrange cards under the user's cursor.
        # Sorting is based on a snapshot until explicitly reapplied.
        self._rating_sort_snapshot = {}
        self._name_sort_snapshot = {}
        self.setDynamicSortFilter(False)

    def set_filter_text(self, text: str):
        self.filter_text = text.strip().lower()
        self.invalidateFilter()

    def set_sort_key(self, key: str, *, refresh_rating: bool = False):
        if key == "name" and (self.sort_key != "name" or refresh_rating
                              or not self._name_sort_snapshot):
            model = self.sourceModel()
            self._name_sort_snapshot = {item.path: item.name.lower() for item in model.items}
        if key == "rating" and (self.sort_key != "rating" or refresh_rating
                                or not self._rating_sort_snapshot):
            model = self.sourceModel()
            self._rating_sort_snapshot = {item.path: item.rating for item in model.items}
        self.sort_key = key
        self.invalidate()
        self.sort(0, Qt.AscendingOrder)

    def apply_rating_order(self):
        self.set_sort_key("rating", refresh_rating=True)

    def filterAcceptsRow(self, source_row, source_parent):
        model: VideoModel = self.sourceModel()
        item = model.items[source_row]
        if self.filter_text and self.filter_text not in (item.name + ' ' + str(Path(item.path).parent.name)).lower():
            return False
        if self.filter_favorites and not item.favorite:
            return False
        if self.filter_collection and self.filter_collection not in item.collections:
            return False
        if item.rating < self.filter_rating:
            return False
        if self.filter_extension != 'all' and Path(item.path).suffix.lower() != self.filter_extension:
            return False
        if self.filter_quality == '4k' and item.height < 2160:
            return False
        if self.filter_quality == 'fhd' and item.height < 1080:
            return False
        if self.filter_quality == 'small' and item.size >= 1024**3:
            return False
        return True

    def lessThan(self, left, right):
        model: VideoModel = self.sourceModel()
        a = model.items[left.row()]
        b = model.items[right.row()]
        key = self.sort_key
        if key == "size":
            return a.size > b.size
        if key == "duration":
            return a.duration > b.duration
        if key == "date":
            return a.mtime > b.mtime
        if key == "rating":
            a_rating = self._rating_sort_snapshot.get(a.path, a.rating)
            b_rating = self._rating_sort_snapshot.get(b.path, b.rating)
            if a_rating != b_rating:
                return a_rating > b_rating
            return (a.name.casefold(), a.path) < (b.name.casefold(), b.path)
        return (self._name_sort_snapshot.get(a.path, a.name.lower()) <
                self._name_sort_snapshot.get(b.path, b.name.lower()))

    def remap_path(self, old_path: str, new_path: str):
        """Keep frozen sort positions stable across automatic file renaming."""
        for snapshot in (self._rating_sort_snapshot, self._name_sort_snapshot):
            if old_path in snapshot:
                snapshot[new_path] = snapshot.pop(old_path)


class VideoCardDelegate(QStyledItemDelegate):
    def __init__(self, view):
        super().__init__(view)
        self.view = view
        self.card_width = 286
        # Vector star, rendered at actual DPI: no pixelated tiny font glyphs.
        self._star_path = QPainterPath()
        for vertex in range(10):
            theta = -math.pi / 2 + vertex * math.pi / 5
            radius = 5.0 if vertex % 2 == 0 else 2.18
            x, y = math.cos(theta) * radius, math.sin(theta) * radius
            if vertex == 0:
                self._star_path.moveTo(x, y)
            else:
                self._star_path.lineTo(x, y)
        self._star_path.closeSubpath()
        self._poster_cache = OrderedDict()

    def set_card_width(self, width: int):
        self.card_width = int(width)
        self._poster_cache.clear()
        self.sizeHintChanged.emit(QModelIndex())

    def sizeHint(self, option, index):
        preview_w = self.card_width - 20
        preview_h = int(preview_w * 9 / 16)
        return QSize(self.card_width, preview_h + 98)

    def star_rects(self, item_rect: QRect):
        rect = item_rect.adjusted(1, 1, -1, -1)
        preview_h = int((rect.width() - 20) * 9 / 16)
        title_y = rect.y() + 10 + preview_h + 10
        star_y = title_y + 23

        # Reserve the right side of the rating row for the per-card delete button.
        delete_w = 26
        gap = 8
        side_margin = 12
        stars_area = max(100, rect.width() - side_margin * 2 - delete_w - gap)
        # All twenty hit boxes stay on one row, including the minimum card size.
        star_w = max(5, min(15, stars_area // MAX_RATING))
        star_h = 22
        total = star_w * MAX_RATING
        start_x = rect.x() + side_margin + max(0, (stars_area - total) // 2)
        return [
            QRect(start_x + i * star_w, star_y, star_w, star_h)
            for i in range(MAX_RATING)
        ]

    def delete_rect(self, item_rect: QRect) -> QRect:
        rect = item_rect.adjusted(1, 1, -1, -1)
        preview_h = int((rect.width() - 20) * 9 / 16)
        title_y = rect.y() + 10 + preview_h + 10
        star_y = title_y + 23
        return QRect(rect.right() - 12 - 26 + 1, star_y, 26, 23)

    def delete_hit_at(self, index, item_rect: QRect, point: QPoint) -> bool:
        return bool(index.isValid() and self.delete_rect(item_rect).contains(point))

    def star_value_at(self, index, item_rect: QRect, point: QPoint) -> int:
        if not index.isValid():
            return 0
        for i, r in enumerate(self.star_rects(item_rect), start=1):
            if r.contains(point):
                return i
        return 0

    def _draw_cover(self, painter, pixmap, rect, static_poster=False):
        """Rounded artwork with a tiny bounded cache for stationary posters only.

        Live previews are painted by HoverPreviewSurface and are never cached here.
        """
        clip = QPainterPath()
        clip.addRoundedRect(rect, 12, 12)
        painter.save()
        painter.setClipPath(clip)
        if not pixmap or pixmap.isNull():
            gradient = QLinearGradient(rect.topLeft(), rect.bottomRight())
            gradient.setColorAt(0.0, QColor("#1e3452"))
            gradient.setColorAt(0.58, QColor("#14243a"))
            gradient.setColorAt(1.0, QColor("#101928"))
            painter.fillRect(rect, QBrush(gradient))
            cx, cy = rect.center().x(), rect.center().y()
            painter.setPen(QPen(QColor(155, 186, 224, 58), 1.4))
            painter.setBrush(QColor(130, 166, 221, 14))
            painter.drawEllipse(QPoint(cx, cy), 34, 34)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor("#d5e5ff"))
            tri = QPainterPath()
            tri.moveTo(cx - 7, cy - 12)
            tri.lineTo(cx + 13, cy)
            tri.lineTo(cx - 7, cy + 12)
            tri.closeSubpath()
            painter.drawPath(tri)
        else:
            key = None
            cropped = None
            if static_poster:
                key = (int(pixmap.cacheKey()), rect.width(), rect.height())
                cropped = self._poster_cache.get(key)
                if cropped is not None:
                    self._poster_cache.move_to_end(key)
            if cropped is None:
                scaled = pixmap.scaled(rect.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                sx = max(0, (scaled.width() - rect.width()) // 2)
                sy = max(0, (scaled.height() - rect.height()) // 2)
                cropped = scaled.copy(sx, sy, rect.width(), rect.height())
                if key is not None:
                    self._poster_cache[key] = cropped
                    while len(self._poster_cache) > 100:
                        self._poster_cache.popitem(last=False)
            painter.drawPixmap(rect.topLeft(), cropped)
            shading = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.bottom())
            shading.setColorAt(0.0, QColor(0, 0, 0, 16))
            shading.setColorAt(0.75, QColor(0, 0, 0, 0))
            shading.setColorAt(1.0, QColor(3, 8, 17, 92))
            painter.fillRect(rect, QBrush(shading))
        painter.restore()
        painter.setPen(QPen(QColor(255, 255, 255, 22), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(rect.adjusted(0, 0, -1, -1), 12, 12)

    def paint(self, painter: QPainter, option, index):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        rect = option.rect.adjusted(2, 2, -2, -2)
        selected = bool(option.state & QStyle.State_Selected)
        hovered = bool(option.state & QStyle.State_MouseOver)
        painter.setPen(QPen(
            QColor("#8ca6ff") if selected else QColor("#3b5070") if hovered else QColor("#25354b"),
            1.5 if selected else 1,
        ))
        painter.setBrush(QColor("#1c2940") if selected else QColor("#18263a") if hovered else QColor("#121d2d"))
        painter.drawRoundedRect(rect, 17, 17)

        # A restrained accent edge makes selection clear without expensive blur/shadows.
        if selected:
            painter.setPen(QPen(QColor("#a9b9ff"), 3))
            painter.drawLine(rect.left() + 18, rect.top() + 1, rect.right() - 18, rect.top() + 1)

        preview_rect = QRect(rect.x() + 10, rect.y() + 10, rect.width() - 20, int((rect.width() - 20) * 9 / 16))
        preview = index.data(PREVIEW_ROLE)
        poster = index.data(POSTER_ROLE)
        self._draw_cover(painter, preview or poster, preview_rect, static_poster=not bool(preview))

        if index.data(PREVIEW_ACTIVE_ROLE):
            badge = QRect(preview_rect.x() + 9, preview_rect.y() + 9, 68, 23)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(7, 14, 25, 208))
            painter.drawRoundedRect(badge, 8, 8)
            painter.setPen(QColor("#c2ffec"))
            bf = QFont("Segoe UI", 8, QFont.DemiBold)
            painter.setFont(bf)
            painter.drawText(badge, Qt.AlignCenter, "● LIVE")

        duration = index.data(DURATION_ROLE) or 0.0
        resolution = index.data(RESOLUTION_ROLE) or ""
        size = index.data(SIZE_ROLE) or 0
        meta_ready = bool(index.data(META_READY_ROLE))
        if meta_ready and duration:
            time_text = human_duration(duration)
            font = QFont("Segoe UI", 9, QFont.DemiBold)
            painter.setFont(font)
            tw = QFontMetrics(font).horizontalAdvance(time_text) + 18
            time_rect = QRect(preview_rect.right() - tw - 10, preview_rect.bottom() - 31, tw, 23)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(6, 12, 22, 210))
            painter.drawRoundedRect(time_rect, 7, 7)
            painter.setPen(QColor("#f4f7ff"))
            painter.drawText(time_rect, Qt.AlignCenter, time_text)

        if bool(index.data(FAVORITE_ROLE)):
            fav_rect = QRect(preview_rect.right() - 39, preview_rect.y() + 9, 28, 27)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(10, 18, 30, 220))
            painter.drawRoundedRect(fav_rect, 9, 9)
            painter.setPen(QColor('#ffcf79'))
            painter.setFont(QFont('Segoe UI Symbol', 14, QFont.Bold))
            painter.drawText(fav_rect, Qt.AlignCenter, '♥')

        if selected:
            mark = QRect(preview_rect.x() + 9, preview_rect.y() + 9, 25, 25)
            painter.setBrush(QColor("#8299ff"))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(mark)
            painter.setPen(QPen(QColor("#091427"), 2.1))
            px = mark.center().x()
            py = mark.center().y()
            painter.drawLine(px - 6, py, px - 1, py + 5)
            painter.drawLine(px - 1, py + 5, px + 7, py - 5)

        title_rect = QRect(rect.x() + 13, preview_rect.bottom() + 11, rect.width() - 26, 22)
        title = index.data(NAME_ROLE) or ""
        painter.setPen(QColor("#f5f8ff"))
        title_font = QFont("Segoe UI", 10, QFont.DemiBold)
        painter.setFont(title_font)
        fm = QFontMetrics(title_font)
        painter.drawText(title_rect, Qt.AlignLeft | Qt.AlignVCenter,
                         fm.elidedText(title, Qt.ElideMiddle, title_rect.width()))

        # Rating and trash use the exact same hit boxes as SmartVideoView.
        rating = int(index.data(RATING_ROLE) or 0)
        path_value = index.data(PATH_ROLE) or ""
        hover_value = 0
        if getattr(self.view, "_star_hover_path", None) == path_value:
            hover_value = int(getattr(self.view, "_star_hover_value", 0) or 0)
        shown = hover_value if hover_value else rating
        for n, star_rect in enumerate(self.star_rects(option.rect), start=1):
            active = n <= shown
            painter.save()
            painter.translate(star_rect.center())
            scale = min((star_rect.width() - 1.0) / 10.0, 1.15)
            painter.scale(scale, scale)
            painter.setPen(QPen(QColor("#ffc964") if active else QColor("#697b99"), 0.72))
            painter.setBrush(QColor("#ffca69") if active else Qt.NoBrush)
            painter.drawPath(self._star_path)
            painter.restore()

        delete_rect = self.delete_rect(option.rect)
        delete_hover = getattr(self.view, "_delete_hover_path", None) == path_value
        painter.setBrush(QColor("#50303b") if delete_hover else QColor("#292332"))
        painter.setPen(QPen(QColor("#db7189") if delete_hover else QColor("#514251"), 1))
        painter.drawRoundedRect(delete_rect, 8, 8)
        painter.setFont(QFont("Segoe UI Symbol", 11, QFont.DemiBold))
        painter.setPen(QColor("#ffbec8") if delete_hover else QColor("#dc8998"))
        painter.drawText(delete_rect, Qt.AlignCenter, "×")

        bits = []
        if meta_ready and resolution:
            bits.append(resolution)
        bits.append(human_size(size))
        meta = "   ·   ".join(bits)
        meta_rect = QRect(rect.x() + 13, title_rect.bottom() + 25, rect.width() - 26, 20)
        painter.setFont(QFont("Segoe UI", 9))
        painter.setPen(QColor("#98a9c4"))
        painter.drawText(meta_rect, Qt.AlignLeft | Qt.AlignVCenter, meta)
        painter.restore()


class SmartVideoView(QListView):
    hover_source_row_changed = Signal(int)
    visible_source_rows_changed = Signal(object)
    scroll_state_changed = Signal(bool)
    selection_paths_changed = Signal(object)
    rating_requested = Signal(str, int)
    delete_requested = Signal(str)
    play_requested = Signal(str)

    def __init__(self):
        super().__init__()
        self.setViewMode(QListView.IconMode)
        self.setFlow(QListView.LeftToRight)
        self.setWrapping(True)
        self.setResizeMode(QListView.Adjust)
        self.setMovement(QListView.Static)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMouseTracking(True)
        self.setUniformItemSizes(True)
        self.setLayoutMode(QListView.Batched)
        self.setBatchSize(60)
        self.setSpacing(12)
        self.setFrameShape(QFrame.NoFrame)
        # Pixel-based scrolling prevents Qt item-at-a-time jumps.
        self.verticalScrollBar().setSingleStep(20)

        self._wheel_target = None
        self._scroll_anim = QPropertyAnimation(self.verticalScrollBar(), b"value", self)
        self._scroll_anim.setDuration(105)
        self._scroll_anim.setEasingCurve(QEasingCurve.OutQuad)
        self._scroll_anim.finished.connect(self._sync_wheel_target)

        self._hover_source_row = -1
        self._star_hover_path = None
        self._star_hover_value = 0
        self._delete_hover_path = None
        self._visible_timer = QTimer(self)
        self._visible_timer.setSingleShot(True)
        self._visible_timer.timeout.connect(self.emit_visible_rows)
        self._scrolling = False
        self._scroll_settle_timer = QTimer(self)
        self._scroll_settle_timer.setSingleShot(True)
        self._scroll_settle_timer.setInterval(165)
        self._scroll_settle_timer.timeout.connect(self._scroll_settled)
        self.verticalScrollBar().valueChanged.connect(self._scroll_moved)
        self.selectionModelChanged = False
        self._suppress_click_release = False
        self._press_point = None
        self._press_path = None

    def _scroll_moved(self, _value):
        if self._scroll_anim.state() != QAbstractAnimation.State.Running:
            # Scrollbar drag, keyboard navigation and touch scroll must reset
            # the wheel target, otherwise the next notch jumps backwards.
            self._wheel_target = self.verticalScrollBar().value()
        # Stop obsolete live streams as soon as a wheel/scrollbar gesture starts.
        self._visible_timer.stop()
        if not self._scrolling:
            self._scrolling = True
            self.scroll_state_changed.emit(True)
        self._scroll_settle_timer.start()

    def _scroll_settled(self):
        self._scrolling = False
        self.scroll_state_changed.emit(False)
        self.emit_visible_rows()

    def refresh_hover_from_cursor(self):
        position = self.viewport().mapFromGlobal(QCursor.pos())
        if not self.viewport().rect().contains(position):
            row = -1
        else:
            idx = self.indexAt(position)
            row = self.model().mapToSource(idx).row() if idx.isValid() else -1
        if row != self._hover_source_row:
            self._hover_source_row = row
            self.hover_source_row_changed.emit(row)

    def setModel(self, model):
        old = self.selectionModel()
        super().setModel(model)
        if self.selectionModel():
            self.selectionModel().selectionChanged.connect(self._emit_selection_paths)

    def set_card_width(self, width: int):
        card_h = int((width - 20) * 9 / 16) + 98
        self.setGridSize(QSize(width + 12, card_h + 12))
        self.scheduleDelayedItemsLayout()
        self._visible_timer.start(120)

    def _sync_wheel_target(self):
        self._wheel_target = self.verticalScrollBar().value()

    def wheelEvent(self, event):
        bar = self.verticalScrollBar()
        pixel = event.pixelDelta().y()
        angle = event.angleDelta().y()
        if pixel:
            # Trackpads already provide fine grained pixel deltas; do not
            # scale or animate them again.  Cancel obsolete wheel animation.
            self._scroll_anim.stop()
            target = max(bar.minimum(), min(bar.maximum(), bar.value() - pixel))
            bar.setValue(target)
            self._wheel_target = target
            event.accept()
            return
        if not angle:
            super().wheelEvent(event)
            return
        if self._wheel_target is None or self._scroll_anim.state() != QAbstractAnimation.State.Running:
            self._wheel_target = bar.value()
        # About a third of a poster-row per notch, rather than 175 px and
        # repeated 3-row leaps. Keep fractional/high-resolution wheel input.
        notches = max(-2.0, min(2.0, angle / 120.0))
        self._wheel_target = int(max(bar.minimum(), min(bar.maximum(),
                                                   self._wheel_target - notches * 74)))
        self._scroll_anim.stop()
        self._scroll_anim.setStartValue(bar.value())
        self._scroll_anim.setEndValue(self._wheel_target)
        self._scroll_anim.start()
        event.accept()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._visible_timer.start(100)

    def mouseMoveEvent(self, event):
        point = event.position().toPoint()
        idx = self.indexAt(point)
        source_row = -1
        star_path = None
        star_value = 0
        delete_path = None
        if idx.isValid():
            proxy = self.model()
            src = proxy.mapToSource(idx)
            source_row = src.row()
            delegate = self.itemDelegate()
            if hasattr(delegate, "delete_hit_at") and delegate.delete_hit_at(idx, self.visualRect(idx), point):
                delete_path = idx.data(PATH_ROLE)
            elif hasattr(delegate, "star_value_at"):
                star_value = delegate.star_value_at(idx, self.visualRect(idx), point)
                if star_value:
                    star_path = idx.data(PATH_ROLE)

        if source_row != self._hover_source_row:
            self._hover_source_row = source_row
            self.hover_source_row_changed.emit(source_row)

        if (star_path != self._star_hover_path or star_value != self._star_hover_value
                or delete_path != self._delete_hover_path):
            self._star_hover_path = star_path
            self._star_hover_value = star_value
            self._delete_hover_path = delete_path
            self.viewport().update()
        self.setToolTip("حذف فایل (انتقال به Recycle Bin)" if delete_path else "")
        self.setCursor(Qt.PointingHandCursor if idx.isValid() else Qt.ArrowCursor)
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        self._press_path = None
        self._press_point = None
        self._suppress_click_release = False
        if event.button() == Qt.LeftButton:
            point = event.position().toPoint()
            idx = self.indexAt(point)
            if idx.isValid():
                delegate = self.itemDelegate()
                if hasattr(delegate, "delete_hit_at") and delegate.delete_hit_at(idx, self.visualRect(idx), point):
                    path = idx.data(PATH_ROLE)
                    if path:
                        self.delete_requested.emit(path)
                    event.accept()
                    return
                value = delegate.star_value_at(idx, self.visualRect(idx), point) if hasattr(delegate, "star_value_at") else 0
                if value:
                    path = idx.data(PATH_ROLE)
                    current = int(idx.data(RATING_ROLE) or 0)
                    self.rating_requested.emit(path, 0 if current == value else value)
                    event.accept()
                    return
                if not (event.modifiers() & (Qt.ControlModifier | Qt.ShiftModifier | Qt.AltModifier)):
                    # Activate only on mouse RELEASE if pointer is still over
                    # the same card; a drag or scroll never launches a movie.
                    self._press_point = point
                    self._press_path = idx.data(PATH_ROLE)
                    event.accept()
                    return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._press_path:
            path = self._press_path
            point = event.position().toPoint()
            start = self._press_point
            self._press_path = None
            self._press_point = None
            if (not self._suppress_click_release and not self._scrolling
                    and start is not None and (point - start).manhattanLength() <= 9
                    and self.indexAt(point).data(PATH_ROLE) == path):
                self.play_requested.emit(path)
            self._suppress_click_release = False
            event.accept()
            return
        self._suppress_click_release = False
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        # The first normal click already opens a player. A second click opens
        # another player; Qt double-click does not create an accidental third.
        if event.button() == Qt.LeftButton:
            point = event.position().toPoint()
            idx = self.indexAt(point)
            if idx.isValid():
                delegate = self.itemDelegate()
                is_delete = hasattr(delegate, "delete_hit_at") and delegate.delete_hit_at(idx, self.visualRect(idx), point)
                is_star = hasattr(delegate, "star_value_at") and delegate.star_value_at(idx, self.visualRect(idx), point)
                if not is_delete and not is_star:
                    self._press_path = None
                    self._press_point = None
                    self._suppress_click_release = True
                    if not self._scrolling:
                        self.play_requested.emit(idx.data(PATH_ROLE))
                    event.accept()
                    return
        super().mouseDoubleClickEvent(event)

    def leaveEvent(self, event):
        self._press_path = None
        self._press_point = None
        if self._hover_source_row != -1:
            self._hover_source_row = -1
            self.hover_source_row_changed.emit(-1)
        if self._star_hover_path is not None or self._star_hover_value or self._delete_hover_path is not None:
            self._star_hover_path = None
            self._star_hover_value = 0
            self._delete_hover_path = None
            self.viewport().update()
        self.setToolTip("")
        self.unsetCursor()
        super().leaveEvent(event)

    def emit_visible_rows(self):
        proxy = self.model()
        if proxy is None or proxy.rowCount() == 0:
            self.visible_source_rows_changed.emit([])
            return

        viewport_rect = self.viewport().rect().adjusted(0, -180, 0, 180)
        rows = []
        # virtualized grid: only inspect a bounded range around the viewport.
        # indexAt() may return invalid in the spacing between cards, so sample across
        # the width and nearby y positions rather than assuming the first pixel is a card.
        found = []
        for y in range(0, self.viewport().height() + 120, 72):
            for x in range(12, max(13, self.viewport().width()), max(100, self.gridSize().width())):
                idx = self.indexAt(QPoint(x, min(y, self.viewport().height() - 1)))
                if idx.isValid():
                    found.append(idx.row())
        if found:
            first = max(0, min(found) - 16)
            last = min(proxy.rowCount(), max(found) + 17)
        else:
            first, last = 0, min(proxy.rowCount(), 100)
        for r in range(first, last):
            idx = proxy.index(r, 0)
            rect = self.visualRect(idx)
            if rect.isValid() and rect.intersects(viewport_rect):
                rows.append(proxy.mapToSource(idx).row())
        self.visible_source_rows_changed.emit(rows)

    def _emit_selection_paths(self, *args):
        proxy = self.model()
        if proxy is None:
            return
        paths = []
        for idx in self.selectionModel().selectedIndexes():
            src = proxy.mapToSource(idx)
            p = src.data(PATH_ROLE)
            if p:
                paths.append(p)
        self.selection_paths_changed.emit(paths)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Delete:
            # Parent handles actual delete through shortcut-like signal by method call.
            p = self.parent()
            while p is not None:
                if hasattr(p, "trash_selected"):
                    p.trash_selected()
                    return
                p = p.parent()
        super().keyPressEvent(event)


class HoverPreviewSurface(QWidget):
    """A lightweight, rounded video surface painted directly over the hovered card."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._pixmap = None
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.hide()

        self._opacity = QGraphicsOpacityEffect(self)
        self._opacity.setOpacity(0.0)
        self.setGraphicsEffect(self._opacity)
        self._fade = QPropertyAnimation(self._opacity, b"opacity", self)
        self._fade.setDuration(75)
        self._fade.setEasingCurve(QEasingCurve.OutCubic)

    def clear_frame(self):
        self._pixmap = None
        self._fade.stop()
        self._opacity.setOpacity(0.0)
        self.hide()

    def set_frame(self, pixmap: QPixmap):
        if pixmap is None or pixmap.isNull():
            return
        first = not self.isVisible()
        self._pixmap = pixmap
        if first:
            self._opacity.setOpacity(0.0)
            self.show()
            self.raise_()
            self._fade.stop()
            self._fade.setStartValue(0.0)
            self._fade.setEndValue(1.0)
            self._fade.start()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

        rect = self.rect().adjusted(0, 0, -1, -1)
        clip = QPainterPath()
        clip.addRoundedRect(rect, 12, 12)
        painter.setClipPath(clip)
        painter.fillRect(rect, QColor("#080c12"))

        pm = self._pixmap
        if pm is not None and not pm.isNull():
            src_w = pm.width()
            src_h = pm.height()
            if src_w > 0 and src_h > 0:
                target_ratio = rect.width() / max(1, rect.height())
                src_ratio = src_w / max(1, src_h)
                if src_ratio > target_ratio:
                    crop_w = int(src_h * target_ratio)
                    sx = max(0, (src_w - crop_w) // 2)
                    src = QRect(sx, 0, crop_w, src_h)
                else:
                    crop_h = int(src_w / max(0.001, target_ratio))
                    sy = max(0, (src_h - crop_h) // 2)
                    src = QRect(0, sy, src_w, crop_h)
                painter.drawPixmap(rect, pm, src)

        painter.setClipping(False)
        painter.setPen(QPen(QColor(255, 255, 255, 42), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(rect, 12, 12)


class SmoothHoverPreview(QObject):
    """Smooth live hover preview powered by a Python worker + subprocess FFmpeg.

    QProcess is intentionally not used here. Rapid hover changes used to create a
    Qt lifetime race. Each hover generation now owns a normal subprocess in a
    worker thread; the worker is the only code that waits for and disposes it.
    """
    first_frame = Signal(str)
    FRAME_W = 512
    FRAME_H = 288
    SEGMENT_SECONDS = PREVIEW_SEGMENT_SECONDS
    ANCHORS = PREVIEW_ANCHORS

    def __init__(self, view: SmartVideoView, source_model: VideoModel, cfg: dict,
                 max_workers: int = 2, ffmpeg_threads: int = 0):
        super().__init__(view)
        self.view = view
        self.source_model = source_model
        self.cfg = cfg
        self.surface = HoverPreviewSurface(view.viewport())
        self._path = None
        self._duration = 0.0
        self._generation = 0
        self._frame_bytes = self.FRAME_W * self.FRAME_H * 3
        self._ffmpeg = ffmpeg_path()

        self._frames = deque(maxlen=10)
        self._frames_lock = threading.Lock()
        self._decode_pool = PreviewDecoderPool(max_workers=max_workers)
        self._ffmpeg_threads = max(0, int(ffmpeg_threads))
        self._failed_generation = -1
        self._workers_lock = self._decode_pool.lock
        self._worker_events = self._decode_pool.events
        self._worker_processes = self._decode_pool.processes
        self._last_error = ''
        self.presented_frames = 0
        self.preview_started = 0.0
        self._present_period = 1.0 / 60.0
        self._present_deadline = 0.0
        self._first_frame_presented = False
        self._buffer_primed = False

        self._present_timer = QTimer(self)
        self._present_timer.setTimerType(Qt.PreciseTimer)
        self._present_timer.setSingleShot(True)
        self._present_timer.timeout.connect(self._present_latest)
        self._sync_timer_rate()

        self.view.verticalScrollBar().valueChanged.connect(lambda _=0: self.reposition())

    def update_settings(self, cfg: dict):
        self.cfg = cfg
        self._sync_timer_rate()

    def _fps(self) -> int:
        try:
            return max(30, min(60, int(self.cfg.get("hover_video_fps", 60))))
        except Exception:
            return 60

    def _speed(self) -> float:
        try:
            return max(1.0, min(3.0, float(self.cfg.get("hover_video_speed", 2.0))))
        except Exception:
            return 2.0

    def _sync_timer_rate(self):
        self._present_period = 1.0 / max(1, self._fps())

    def _schedule_present(self, delay_s: float | None = None):
        if not self._path:
            return
        if delay_s is None:
            now = time.perf_counter()
            if self._present_deadline <= 0.0:
                self._present_deadline = now
            delay_s = max(0.001, self._present_deadline - now)
        self._present_timer.start(max(1, int(round(delay_s * 1000.0))))

    def is_active(self) -> bool:
        return bool(self._path)

    def start(self, path: str, duration: float = 0.0):
        if not path or not Path(path).is_file():
            self.stop()
            return
        if self._path == path:
            if duration and duration > 0:
                self._duration = float(duration)
            self.reposition()
            return

        self._cancel_workers(wait=False)
        self._generation += 1
        generation = self._generation
        self._path = path
        self._duration = max(0.0, float(duration or 0.0))
        self._last_error = ''
        self._failed_generation = -1
        self.presented_frames = 0
        self.preview_started = time.monotonic()
        self._present_deadline = 0.0
        self._first_frame_presented = False
        self._buffer_primed = False
        with self._frames_lock:
            self._frames.clear()
        self.surface.clear_frame()
        self.reposition()
        self._sync_timer_rate()
        self._schedule_present(0.001)

        current_duration = self._duration
        self._decode_pool.submit(
            generation,
            lambda stop_event: self._worker_loop(generation, path, current_duration, stop_event),
        )

    def stop(self):
        self._generation += 1
        self._path = None
        self._duration = 0.0
        self._present_timer.stop()
        self._present_deadline = 0.0
        self._first_frame_presented = False
        self._buffer_primed = False
        with self._frames_lock:
            self._frames.clear()
        self.surface.clear_frame()
        self._cancel_workers(wait=False)

    def shutdown(self):
        """Stop FFmpeg first, then wait briefly for worker ownership to unwind."""
        self._generation += 1
        self._path = None
        self._duration = 0.0
        self._present_timer.stop()
        self._present_deadline = 0.0
        self._first_frame_presented = False
        self._buffer_primed = False
        with self._frames_lock:
            self._frames.clear()
        self.surface.clear_frame()
        self._cancel_workers(wait=True)

    def _cancel_workers(self, wait: bool):
        if wait:
            self._decode_pool.shutdown()
        else:
            self._decode_pool.cancel_all(hard=False)

    _terminate_process = staticmethod(terminate)

    def reposition(self):
        if not self._path:
            return
        row = self.source_model.row_for_path(self._path)
        proxy = self.view.model()
        if row < 0 or proxy is None:
            self.surface.hide()
            return
        src_idx = self.source_model.index(row, 0)
        idx = proxy.mapFromSource(src_idx)
        if not idx.isValid():
            self.surface.hide()
            return
        card = self.view.visualRect(idx)
        viewport = self.view.viewport().rect()
        if not card.isValid() or not card.intersects(viewport):
            self.surface.hide()
            return
        w = max(1, card.width() - 20)
        h = max(1, int(w * 9 / 16))
        self.surface.setGeometry(QRect(card.x() + 10, card.y() + 10, w, h))
        if self.surface._pixmap is not None:
            self.surface.show()
            self.surface.raise_()

    def _segment_start(self, duration: float, segment_index: int) -> float | None:
        return preview_segment_start(duration, segment_index)

    def _worker_loop(self, generation: int, path: str, duration: float, stop_event: threading.Event):
        segment_index = 0
        try:
            # Metadata extraction can still be pending on the first hover.
            # Resolve duration in this worker instead of accidentally starting
            # the movie at 00:00 when it was passed as zero.
            if not duration or duration <= 0:
                duration = probe_video_duration(self._ffmpeg, path)
            if not duration or duration <= 0:
                self._last_error = 'Video duration unavailable; refusing to seek to 00:00.'
                return
            while not stop_event.is_set() and generation == self._generation:
                start = self._segment_start(duration, segment_index)
                if start is None:
                    break
                use_gpu = bool(self.cfg.get('gpu_decode', False))
                ok = self._run_segment(generation, path, start, stop_event, prefer_gpu=use_gpu)
                if not ok and use_gpu and not stop_event.is_set() and generation == self._generation:
                    # -hwaccel auto isn't reliable on every driver/codec; a clean CPU
                    # retry must happen without freezing or stopping the preview.
                    ok = self._run_segment(generation, path, start, stop_event, prefer_gpu=False)
                if stop_event.is_set() or generation != self._generation:
                    break
                if not ok:
                    break
                segment_index = (segment_index + 1) % len(self.ANCHORS)
        finally:
            # A corrupt/unsupported source must not keep a GUI timer spinning
            # at hundreds of Hz forever. Only the GUI thread calls stop().
            if not stop_event.is_set() and generation == self._generation:
                self._failed_generation = generation

    def _run_segment(self, generation: int, path: str, start: float, stop_event: threading.Event,
                     prefer_gpu: bool = False) -> bool:
        spec = PreviewSpec(
            fps=self._fps(), speed=self._speed(),
            interpolate=bool(self.cfg.get('hover_interpolation', False)),
            width=self.FRAME_W, height=self.FRAME_H,
            segment_seconds=self.SEGMENT_SECONDS,
        )
        args = ffmpeg_command(self._ffmpeg, path, start, spec, gpu=prefer_gpu)
        if self._ffmpeg_threads:
            # Input option controls decoder threading; setting only the
            # output-side -threads does not cap video decode threads.
            args[args.index('-i'):args.index('-i')] = ['-threads', str(self._ffmpeg_threads)]
        # A full stderr PIPE can block FFmpeg on malformed streams if nobody
        # drains it while rawvideo is read. Use a temporary native file handle.
        error_sink = tempfile.TemporaryFile(mode='w+b')
        try:
            proc = subprocess.Popen(
                args,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=error_sink,
                bufsize=0,
                creationflags=WIN_FLAGS,
            )
        except Exception as exc:
            error_sink.close()
            self._last_error = f"FFmpeg start failed: {exc}"
            return False

        if not self._decode_pool.attach(generation, proc):
            try:
                proc.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                self._terminate_process(proc, hard=True)
            error_sink.close()
            return False

        got_frame = False
        try:
            while not stop_event.is_set() and generation == self._generation:
                raw = self._read_exact(proc.stdout, self._frame_bytes, stop_event)
                if raw is None:
                    break
                got_frame = True
                with self._frames_lock:
                    if generation == self._generation and not stop_event.is_set():
                        self._frames.append((generation, raw))
            if stop_event.is_set() or generation != self._generation:
                self._terminate_process(proc, hard=False)
        finally:
            try:
                if proc.stdout:
                    proc.stdout.close()
            except Exception:
                pass
            try:
                proc.wait(timeout=0.20)
            except Exception:
                self._terminate_process(proc, hard=False)
                try:
                    proc.wait(timeout=0.20)
                except Exception:
                    self._terminate_process(proc, hard=True)
                    try:
                        proc.wait(timeout=0.20)
                    except Exception:
                        pass
            err = b''
            try:
                error_sink.seek(0)
                err = error_sink.read(65536) or b''
            except OSError:
                pass
            finally:
                error_sink.close()
            self._decode_pool.detach(generation, proc)
            if not got_frame and err and generation == self._generation:
                self._last_error = err.decode("utf-8", errors="replace").strip()[-1200:]
        return got_frame

    @staticmethod
    def _read_exact(stream, size: int, stop_event: threading.Event):
        if stream is None:
            return None
        chunks = bytearray()
        while len(chunks) < size:
            if stop_event.is_set():
                return None
            try:
                chunk = stream.read(size - len(chunks))
            except Exception:
                return None
            if not chunk:
                return None
            chunks.extend(chunk)
        return bytes(chunks)

    def _present_latest(self):
        if not self._path:
            return

        generation = self._generation
        if self._failed_generation == generation:
            self.stop()
            return
        raw = None
        queue_len = 0
        with self._frames_lock:
            while self._frames and self._frames[0][0] != generation:
                self._frames.popleft()
            queue_len = len(self._frames)

            # Show the first decoded frame immediately, then build a tiny jitter
            # buffer (about 1-2 frames) so small FFmpeg/Windows scheduling bursts
            # do not become visible stutter.
            if not self._first_frame_presented and self._frames:
                g, raw = self._frames.popleft()
                if g == generation:
                    self._first_frame_presented = True
                else:
                    raw = None
            elif not self._buffer_primed:
                if len(self._frames) >= 2:
                    self._buffer_primed = True
                    g, raw = self._frames.popleft()
                    if g != generation:
                        raw = None
            else:
                # Keep latency bounded. If decoding gets ahead, drop only the
                # oldest queued frames and stay roughly two frames behind live.
                while len(self._frames) > 3:
                    self._frames.popleft()
                if self._frames:
                    g, raw = self._frames.popleft()
                    if g != generation:
                        raw = None

        if raw is not None:
            image = QImage(
                raw, self.FRAME_W, self.FRAME_H, self.FRAME_W * 3,
                QImage.Format.Format_RGB888
            ).copy()
            if not image.isNull():
                first_presented = self.presented_frames == 0
                self.surface.set_frame(QPixmap.fromImage(image))
                self.presented_frames += 1
                self.reposition()
                if first_presented and self._path:
                    self.first_frame.emit(self._path)

        now = time.perf_counter()
        period = self._present_period

        # If FFmpeg is a few milliseconds late, wait briefly for the next frame
        # instead of deliberately holding the previous image for a whole tick.
        if self._buffer_primed and raw is None:
            self._schedule_present(min(0.003, period * 0.22))
            return

        # Before the small jitter buffer is ready, retry quickly instead of
        # waiting a whole video frame. This keeps initial hover latency low.
        if not self._buffer_primed:
            self._schedule_present(min(0.004, period * 0.35))
            return

        if self._present_deadline <= 0.0:
            self._present_deadline = now + period
        else:
            self._present_deadline += period

        # If the GUI thread was briefly busy, do not replay missed ticks. Jump
        # the clock forward and keep the next frame aligned to real time.
        if self._present_deadline < now - period:
            missed = int((now - self._present_deadline) / period) + 1
            self._present_deadline += missed * period

        self._schedule_present()


class VisibleCardPreview(SmoothHoverPreview):
    """Same live FFmpeg/playback clock as Hover, scaled for a small card."""
    FRAME_W = 384
    FRAME_H = 216

    def __init__(self, view, model, cfg):
        super().__init__(view, model, cfg, max_workers=1, ffmpeg_threads=2)


class VisibleLivePreviews(QObject):
    """Multiple truly live card previews using the *same* FFmpeg renderer as hover.

    The user may increase concurrency for a powerful machine. When the viewport
    contains more cards than the process budget, rotate the limited live slots
    periodically; the remaining cards keep their static poster (not fake JPEG
    slideshows). Each slot has one bounded worker and a generation-safe stream.
    """
    def __init__(self, view: SmartVideoView, model: VideoModel, cfg: dict):
        super().__init__(view)
        self.view = view
        self.model = model
        self.cfg = cfg
        self._slots = []
        self._active = {}  # file path -> SmoothHoverPreview slot
        self._visible_paths = []
        self._hover = None
        self._offset = 0
        self._rotation = QTimer(self)  # retained for older integrations
        self._rotation.setInterval(2500)
        self._rotation.timeout.connect(self._rotate)
        self._scrolling = False
        self._signature = self._make_signature(cfg)

    @staticmethod
    def _make_signature(cfg):
        return (cfg.get('hover_video_fps'), cfg.get('hover_video_speed'),
                cfg.get('hover_interpolation'), cfg.get('gpu_decode'),
                cfg.get('visible_live_limit'))

    def _limit(self):
        try:
            return max(1, min(24, int(self.cfg.get('visible_live_limit', 8))))
        except (TypeError, ValueError):
            return 8

    def update_settings(self, cfg):
        new_signature = self._make_signature(cfg)
        settings_changed = self._signature != new_signature
        self._signature = new_signature
        self.cfg = cfg
        for slot in self._slots:
            slot.update_settings(cfg)
        # Settings are changed on the existing shared dict; compare against a
        # saved signature instead of comparing the same object to itself.
        if settings_changed:
            self._stop_active()
        self._rotation.stop()  # stable, non-rotating preview priorities
        if self._visible_paths and not self._scrolling:
            self._sync()

    def set_visible(self, paths):
        if paths == self._visible_paths:
            self.reposition()
            return
        self._visible_paths = list(dict.fromkeys(paths))
        self._offset = 0
        self._rotation.stop()
        if not self._scrolling:
            self._sync()

    def set_scrolling(self, moving: bool):
        if self._scrolling == bool(moving):
            return
        self._scrolling = bool(moving)
        if self._scrolling:
            self._rotation.stop()
            self._stop_active()
        # On scroll settle, wait for the new viewport list rather than restarting
        # streams for items which just scrolled off-screen.

    def set_hover(self, path):
        if self._hover == path:
            return
        self._hover = path
        if self._visible_paths and not self._scrolling:
            self._sync()

    def _rotate(self):
        # Intentionally disabled: rotation causes repeated FFmpeg restarts,
        # unexpected poster changes and visible stutter every few seconds.
        return

    def _new_slot(self):
        slot = VisibleCardPreview(self.view, self.model, self.cfg)
        slot.first_frame.connect(self._mark_started)
        self._slots.append(slot)
        return slot

    def _mark_started(self, path):
        slot = self._active.get(path)
        if slot is not None and slot.is_active() and slot._path == path:
            self.model.set_preview_active(path, True)

    def _sync(self):
        if self._scrolling:
            return
        desired = select_visible_live_paths(
            self._visible_paths, self._limit(), self._offset, self._hover)
        desired_set = set(desired)
        # Cancel unused processes and hide their video surfaces immediately.
        for path, slot in list(self._active.items()):
            if path not in desired_set:
                slot.stop()
                self.model.set_preview_active(path, False)
                self._active.pop(path, None)
        free_slots = [slot for slot in self._slots if slot not in self._active.values()]
        for path in desired:
            if path in self._active:
                self._active[path].reposition()
                continue
            slot = free_slots.pop() if free_slots else self._new_slot()
            item = self.model.item_for_path(path)
            if item is None:
                continue
            self._active[path] = slot
            self.model.set_preview_active(path, False)
            slot.start(path, item.duration)

    def reposition(self):
        for slot in self._active.values():
            slot.reposition()

    def _stop_active(self):
        for path, slot in list(self._active.items()):
            slot.stop()
            self.model.set_preview_active(path, False)
        self._active.clear()

    def stop(self):
        self._rotation.stop()
        self._visible_paths = []
        self._hover = None
        self._offset = 0
        self._scrolling = False
        self._stop_active()

    def shutdown(self):
        self.stop()
        for slot in self._slots:
            slot.shutdown()
        self._slots.clear()

    def stats(self):
        count = len(self._active)
        processes = sum(len(slot._worker_processes) for slot in self._active.values())
        return count, processes, len(self._visible_paths)


class WorkerBus(QObject):
    scan_ready = Signal(object)
    scan_failed = Signal(str)
    metadata_ready = Signal(str, float, int, int)
    poster_ready = Signal(str, bytes)
    preview_ready = Signal(str, int, int, object)
    task_failed = Signal(str, str)


class CancellationToken:
    def __init__(self, token_id: int):
        self.id = token_id
        self.event = threading.Event()

    def cancel(self):
        self.event.set()

    def cancelled(self) -> bool:
        return self.event.is_set()


class ScanTask(QRunnable):
    def __init__(self, folders: list[str], recursive: bool, bus: WorkerBus,
                 catalog: LibraryCatalog):
        super().__init__()
        self.folders = folders
        self.recursive = recursive
        self.bus = bus
        self.catalog = catalog

    def run(self):
        try:
            # scandir avoids allocating Path objects for every directory entry;
            # do not follow directory links (prevents symlink junction loops).
            result, seen = [], set()
            for folder in self.folders:
                base = os.path.abspath(folder)
                if not os.path.isdir(base):
                    continue
                pending = [base]
                while pending:
                    location = pending.pop()
                    try:
                        with os.scandir(location) as iterator:
                            for entry in iterator:
                                try:
                                    if entry.is_dir(follow_symlinks=False):
                                        if self.recursive:
                                            pending.append(entry.path)
                                    elif (entry.is_file(follow_symlinks=False)
                                          and os.path.splitext(entry.name)[1].lower() in VIDEO_EXTS):
                                        p = os.path.abspath(entry.path)
                                        key = os.path.normcase(p)
                                        if key not in seen:
                                            st = entry.stat(follow_symlinks=False)
                                            seen.add(key)
                                            result.append((p, entry.name, st.st_size, st.st_mtime))
                                except (OSError, ValueError):
                                    continue
                    except (OSError, ValueError):
                        continue
            result.sort(key=lambda x: x[1].casefold())
            self.catalog.index_scan(result)
            self.bus.scan_ready.emit(result)
        except Exception as e:
            self.bus.scan_failed.emit(str(e))


class MetadataTask(QRunnable):
    def __init__(self, path: str, bus: WorkerBus):
        super().__init__()
        self.path = path
        self.bus = bus

    def run(self):
        try:
            proc = run_hidden(
                [ffmpeg_path(), "-hide_banner", "-i", self.path],
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                text=True, encoding="utf-8", errors="ignore"
            )
            err = proc.stderr or ""
            duration = 0.0
            m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", err)
            if m:
                duration = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            width = height = 0
            m2 = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})(?:[,\s])", err)
            if m2:
                width, height = int(m2.group(1)), int(m2.group(2))
            self.bus.metadata_ready.emit(self.path, duration, width, height)
        except Exception as e:
            self.bus.task_failed.emit(self.path, str(e))


class PosterTask(QRunnable):
    def __init__(self, path: str, bus: WorkerBus, disk_cache: bool):
        super().__init__()
        self.path = path
        self.bus = bus
        self.disk_cache = disk_cache

    def run(self):
        try:
            key = cache_key(self.path)
            cache_file = CACHE_DIR / key / "poster.jpg"
            if self.disk_cache and cache_file.exists():
                self.bus.poster_ready.emit(self.path, cache_file.read_bytes())
                return

            cmd = [
                ffmpeg_path(), "-hide_banner", "-loglevel", "error",
                "-ss", "2.0", "-i", self.path,
                "-frames:v", "1", "-vf", "scale=320:-2",
                "-q:v", "5", "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1"
            ]
            proc = run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if proc.returncode != 0 or not proc.stdout:
                # Short-video fallback.
                cmd[5] = "0.1"
                proc = run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            if proc.returncode == 0 and proc.stdout:
                if self.disk_cache:
                    cache_file.parent.mkdir(parents=True, exist_ok=True)
                    cache_file.write_bytes(proc.stdout)
                self.bus.poster_ready.emit(self.path, proc.stdout)
        except Exception as e:
            self.bus.task_failed.emit(self.path, str(e))


class PreviewTask(QRunnable):
    def __init__(
        self, path: str, duration: float, quality: int, fps: int,
        token: CancellationToken, bus: WorkerBus, disk_cache: bool
    ):
        super().__init__()
        self.path = path
        self.duration = duration
        self.quality = quality
        self.fps = max(1, int(fps))
        self.token = token
        self.bus = bus
        self.disk_cache = disk_cache

    def _segment(self, start: float, fps: int, seconds: float) -> list[bytes]:
        cmd = [
            ffmpeg_path(), "-hide_banner", "-loglevel", "error",
            "-ss", f"{max(0.0, start):.3f}", "-i", self.path,
            "-t", f"{seconds:.2f}",
            "-vf", f"fps={fps},scale=360:-2",
            "-q:v", "7",
            "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1"
        ]
        proc = run_hidden(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.returncode != 0:
            return []
        return parse_jpeg_stream(proc.stdout)

    def run(self):
        try:
            key = cache_key(self.path)
            qname = "full" if self.quality >= 2 else "lite"
            cache_dir = CACHE_DIR / key / qname

            if self.disk_cache and cache_dir.exists():
                cached = sorted(cache_dir.glob("*.jpg"))
                if cached:
                    frames = [p.read_bytes() for p in cached]
                    if not self.token.cancelled():
                        self.bus.preview_ready.emit(self.path, self.token.id, self.quality, frames)
                    return

            if self.duration <= 0:
                # Probe only when necessary.
                proc = run_hidden(
                    [ffmpeg_path(), "-hide_banner", "-i", self.path],
                    stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                    text=True, encoding="utf-8", errors="ignore"
                )
                m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", proc.stderr or "")
                if m:
                    self.duration = int(m.group(1))*3600 + int(m.group(2))*60 + float(m.group(3))

            duration = self.duration if self.duration > 0 else 30.0
            anchors = (0.05, 0.27, 0.50, 0.73, 0.95)
            frames = []

            if self.quality >= 2:
                # True hover preview: 5 segments × 2 sec. Default 4fps => 40 frames / 10 sec.
                for ratio in anchors:
                    if self.token.cancelled():
                        return
                    start = min(max(0.0, duration * ratio), max(0.0, duration - 2.05))
                    frames.extend(self._segment(start, self.fps, 2.0))
            else:
                # Visible mode is deliberately lightweight so many cards can animate together.
                # One second from each anchor at 1-2fps.
                lite_fps = min(2, self.fps)
                for ratio in anchors:
                    if self.token.cancelled():
                        return
                    start = min(max(0.0, duration * ratio), max(0.0, duration - 1.05))
                    seg = self._segment(start, lite_fps, 1.0)
                    frames.extend(seg[:max(1, lite_fps)])

            if self.token.cancelled() or not frames:
                return

            if self.disk_cache:
                cache_dir.mkdir(parents=True, exist_ok=True)
                for old in cache_dir.glob("*.jpg"):
                    try:
                        old.unlink()
                    except OSError:
                        pass
                for i, data in enumerate(frames):
                    (cache_dir / f"{i:03d}.jpg").write_bytes(data)

            self.bus.preview_ready.emit(self.path, self.token.id, self.quality, frames)
        except Exception as e:
            self.bus.task_failed.emit(self.path, str(e))


class TechnicalBus(QObject):
    ready = Signal(int, str)


class TechnicalTask(QRunnable):
    def __init__(self, request_id, path, bus):
        super().__init__()
        self.request_id, self.path, self.bus = request_id, path, bus

    def run(self):
        try:
            result = run_hidden([ffmpeg_path(), '-hide_banner', '-i', self.path],
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                text=True, encoding='utf-8', errors='replace', timeout=12)
            text = result.stderr or ''
            video = re.search(r'Stream #.*?: Video:\s*([^\n]+)', text)
            audio = re.search(r'Stream #.*?: Audio:\s*([^\n]+)', text)
            bitrate = re.search(r'Duration:.*?bitrate:\s*([^,\n]+)', text)
            video_line = video.group(1) if video else 'نامشخص'
            fps = re.search(r'([\d.]+)\s*fps', video_line)
            codec = video_line.split(',')[0]
            info = '\n'.join([
                'کدک تصویر: ' + codec,
                'فریم‌ریت فایل: ' + (fps.group(1) + ' FPS' if fps else 'نامشخص'),
                'بیت‌ریت کل: ' + (bitrate.group(1).strip() if bitrate else 'نامشخص'),
                'صدا: ' + (audio.group(1).strip() if audio else 'ندارد یا نامشخص'),
            ])
            self.bus.ready.emit(self.request_id, info)
        except Exception as exc:
            self.bus.ready.emit(self.request_id, f'خواندن اطلاعات پیشرفته ممکن نبود: {exc}')


class TimelineBus(QObject):
    frame_ready = Signal(int, bytes)


class TimelineFrameTask(QRunnable):
    """Asynchronous one-frame seek; only the newest request is displayed."""
    def __init__(self, request_id, path, seconds, bus):
        super().__init__()
        self.request_id = request_id
        self.path = path
        self.seconds = seconds
        self.bus = bus

    def run(self):
        try:
            result = run_hidden([
                ffmpeg_path(), '-hide_banner', '-loglevel', 'error', '-nostdin',
                '-ss', f'{self.seconds:.3f}', '-i', self.path,
                '-frames:v', '1', '-vf', 'scale=520:-2', '-q:v', '4',
                '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1'
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=12)
            if result.returncode == 0 and result.stdout:
                self.bus.frame_ready.emit(self.request_id, result.stdout)
        except (OSError, subprocess.TimeoutExpired):
            pass


class DuplicateBus(QObject):
    completed = Signal(object)
    failed = Signal(str)


class DuplicateTask(QRunnable):
    def __init__(self, paths, bus):
        super().__init__()
        self.paths = list(paths)
        self.bus = bus

    def run(self):
        try:
            self.bus.completed.emit(duplicate_groups(self.paths))
        except Exception as exc:
            self.bus.failed.emit(str(exc))


class MoveBus(QObject):
    finished = Signal(object, object)


class MoveTask(QRunnable):
    def __init__(self, paths: list[str], destination: str, bus: MoveBus):
        super().__init__()
        self.paths = list(paths)
        self.destination = destination
        self.bus = bus

    def run(self):
        moved, failed = [], []
        for path in self.paths:
            try:
                new_path = move_video(path, self.destination)
                if os.path.normcase(new_path) != os.path.normcase(os.path.abspath(path)):
                    moved.append((path, new_path))
            except Exception as exc:
                failed.append(f'{Path(path).name}: {exc}')
        self.bus.finished.emit(moved, failed)


class MediaLoader(QObject):
    def __init__(self, model: VideoModel, cfg: dict):
        super().__init__()
        self.model = model
        self.cfg = cfg
        self.bus = WorkerBus()
        self.bus.metadata_ready.connect(self._metadata_ready)
        self.bus.poster_ready.connect(self._poster_ready)
        self.bus.preview_ready.connect(self._preview_ready)
        self.bus.task_failed.connect(self._task_failed)

        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(int(cfg["workers"]))

        self.pending_meta = set()
        self.pending_poster = set()
        self.preview_tokens: dict[str, CancellationToken] = {}
        self.token_counter = 0
        self.preview_lru = OrderedDict()
        self.preview_memory = 0

    def update_settings(self, cfg):
        self.cfg = cfg
        self.pool.setMaxThreadCount(int(cfg["workers"]))

    def request_metadata(self, path: str, priority=0):
        item = self.model.item_for_path(path)
        if not item or item.meta_ready or path in self.pending_meta:
            return
        self.pending_meta.add(path)
        self.pool.start(MetadataTask(path, self.bus), priority)

    def request_poster(self, path: str, priority=0):
        item = self.model.item_for_path(path)
        if not item or item.poster is not None or path in self.pending_poster:
            return
        self.pending_poster.add(path)
        self.pool.start(PosterTask(path, self.bus, bool(self.cfg.get("cache_enabled"))), priority)

    def cancel_preview(self, path: str):
        token = self.preview_tokens.get(path)
        if token:
            token.cancel()

    def request_preview(self, path: str, quality: int, priority=10):
        item = self.model.item_for_path(path)
        if not item:
            return
        if item.preview_quality >= quality and item.preview_frames:
            self._touch_lru(path)
            return

        old = self.preview_tokens.get(path)
        if old:
            old.cancel()

        self.token_counter += 1
        token = CancellationToken(self.token_counter)
        self.preview_tokens[path] = token

        fps = int(self.cfg.get("hover_fps", 4) if quality >= 2 else self.cfg.get("visible_fps", 1))
        task = PreviewTask(
            path, item.duration, quality, fps, token, self.bus,
            bool(self.cfg.get("cache_enabled"))
        )
        self.pool.start(task, priority)

    def _metadata_ready(self, path, duration, w, h):
        self.pending_meta.discard(path)
        self.model.set_metadata(path, duration, w, h)

    def _poster_ready(self, path, data):
        self.pending_poster.discard(path)
        pm = QPixmap()
        if pm.loadFromData(data):
            self.model.set_poster(path, pm)

    def _preview_ready(self, path, token_id, quality, frames_bytes):
        token = self.preview_tokens.get(path)
        if token is None or token.id != token_id or token.cancelled():
            return

        pixmaps = []
        for data in frames_bytes:
            pm = QPixmap()
            if pm.loadFromData(data):
                pixmaps.append(pm)
        if not pixmaps:
            return

        old_item = self.model.item_for_path(path)
        if old_item and old_item.preview_frames:
            self.preview_memory -= self._estimate_pixmaps(old_item.preview_frames)

        self.model.set_preview(path, pixmaps, quality)
        self.preview_memory += self._estimate_pixmaps(pixmaps)
        self._touch_lru(path)
        self._enforce_ram_limit(active_paths={path})

    def _task_failed(self, path, err):
        self.pending_meta.discard(path)
        self.pending_poster.discard(path)

    def _estimate_pixmaps(self, frames: list[QPixmap]) -> int:
        total = 0
        for pm in frames:
            total += max(1, pm.width()) * max(1, pm.height()) * 4
        return total

    def _touch_lru(self, path):
        self.preview_lru.pop(path, None)
        self.preview_lru[path] = time.monotonic()

    def _enforce_ram_limit(self, active_paths: set[str]):
        limit = int(self.cfg.get("ram_limit_mb", 384)) * 1024 * 1024
        while self.preview_memory > limit and self.preview_lru:
            victim, _ = self.preview_lru.popitem(last=False)
            if victim in active_paths:
                self.preview_lru[victim] = time.monotonic()
                if len(self.preview_lru) <= len(active_paths):
                    break
                continue
            item = self.model.item_for_path(victim)
            if item and item.preview_frames:
                self.preview_memory -= self._estimate_pixmaps(item.preview_frames)
                self.model.clear_preview(victim)

    def trim_for_active(self, active_paths: set[str]):
        self._enforce_ram_limit(active_paths)

    def cancel_all_previews_except(self, paths: set[str]):
        for path, token in list(self.preview_tokens.items()):
            if path not in paths:
                token.cancel()



class NoWheelComboBox(QComboBox):
    """Mouse wheel scrolls the parent page instead of changing the selected option."""
    def wheelEvent(self, event):
        event.ignore()


class NoWheelSpinBox(QSpinBox):
    """Prevents accidental numeric changes while scrolling the settings page."""
    def wheelEvent(self, event):
        event.ignore()


class NoWheelSlider(QSlider):
    """Slider changes only by deliberate drag/click/keyboard, never by page wheel."""
    def wheelEvent(self, event):
        event.ignore()


class SmoothScrollArea(QScrollArea):
    """Short eased wheel animation for desktop mouse wheels without jumpy page movement."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._wheel_target = None
        self._scroll_anim = QPropertyAnimation(self.verticalScrollBar(), b"value", self)
        self._scroll_anim.setDuration(135)
        self._scroll_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._scroll_anim.finished.connect(self._sync_scroll_target)

    def _sync_scroll_target(self):
        self._wheel_target = self.verticalScrollBar().value()

    def wheelEvent(self, event):
        bar = self.verticalScrollBar()
        pixel = event.pixelDelta().y()
        angle = event.angleDelta().y()
        if pixel:
            # Precision touchpad: keep native-feeling direct movement.
            target = bar.value() - pixel
            bar.setValue(max(bar.minimum(), min(bar.maximum(), target)))
            self._wheel_target = bar.value()
            event.accept()
            return
        if not angle:
            super().wheelEvent(event)
            return
        if self._wheel_target is None:
            self._wheel_target = bar.value()
        steps = angle / 120.0
        self._wheel_target = int(self._wheel_target - steps * 150)
        self._wheel_target = max(bar.minimum(), min(bar.maximum(), self._wheel_target))
        self._scroll_anim.stop()
        self._scroll_anim.setStartValue(bar.value())
        self._scroll_anim.setEndValue(self._wheel_target)
        self._scroll_anim.start()
        event.accept()


class ToggleButton(QPushButton):
    def __init__(self, text):
        super().__init__(text)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(38)


class ManagementTab(QWidget):
    folder_changed = Signal(str)
    settings_changed = Signal()
    cloud_start_requested = Signal()
    cloud_stop_requested = Signal()
    cloud_update_requested = Signal()
    cloud_diag_requested = Signal()
    cloud_firewall_requested = Signal()
    cloud_warp_requested = Signal()

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.cloud_running = False

        root = QHBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(16)

        # Compact navigation keeps management settings understandable and avoids one giant scroll page.
        sidebar = QFrame(objectName="managementSidebar")
        sidebar.setFixedWidth(236)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(15, 20, 15, 16)
        side.setSpacing(8)

        brand = QLabel("مرکز مدیریت")
        brand.setObjectName("sideTitle")
        side.addWidget(brand)
        side_hint = QLabel("کتابخانه، عملکرد و اشتراک‌گذاری")
        side_hint.setWordWrap(True)
        side_hint.setObjectName("muted")
        side.addWidget(side_hint)
        side.addSpacing(8)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons = []
        for i, (title, subtitle) in enumerate((
            ("کتابخانه و Preview", "مسیر، زیرپوشه و رفتار پیش‌نمایش"),
            ("عملکرد و حافظه", "RAM، کش، اندازه کارت و Worker"),
            ("Cloudflare و لاگ", "Tunnel، لینک عمومی و عیب‌یابی"),
        )):
            btn = QPushButton(title)
            btn.setToolTip(subtitle)
            btn.setObjectName("sideNavButton")
            btn.setCheckable(True)
            btn.setMinimumHeight(50)
            btn.clicked.connect(lambda checked=False, idx=i: self.set_management_page(idx))
            self.nav_group.addButton(btn)
            self.nav_buttons.append(btn)
            side.addWidget(btn)
        side.addStretch(1)
        version = QLabel("VideoShelf  •  v" + APP_VERSION.split()[0])
        version.setObjectName("muted")
        version.setWordWrap(True)
        side.addWidget(version)
        root.addWidget(sidebar)

        self.pages = QStackedWidget()
        root.addWidget(self.pages, 1)

        # --- Page 1: Library + preview ---
        page1, outer = self._make_page(
            "کتابخانه و پیش‌نمایش",
            "مسیر فیلم‌ها و نحوه Preview را تنظیم کنید. تغییرات حساس با Wheel موس انجام نمی‌شوند."
        )

        folder_panel = QFrame(objectName="panel")
        fl = QVBoxLayout(folder_panel)
        fl.setContentsMargins(20, 20, 20, 20)
        fl.setSpacing(12)
        fl.addWidget(QLabel("فولدر اصلی", objectName="sectionLabel"))
        row = QHBoxLayout()
        self.folder_edit = QLineEdit(cfg.get("folder", ""))
        self.folder_edit.setReadOnly(True)
        self.folder_edit.setPlaceholderText("فولدر فیلم‌ها را انتخاب کنید…")
        browse = QPushButton("انتخاب فولدر")
        browse.setObjectName("primaryButton")
        browse.clicked.connect(self.pick_folder)
        row.addWidget(self.folder_edit, 1)
        row.addWidget(browse)
        fl.addLayout(row)
        fl.addWidget(QLabel('فولدرهای موجود در کتابخانه (چند هارد یا مسیر هم‌زمان)'))
        self.folder_list = QListWidget()
        self.folder_list.setMaximumHeight(120)
        self._refresh_folder_list()
        fl.addWidget(self.folder_list)
        library_buttons = QHBoxLayout()
        add_folder_button = QPushButton('＋ افزودن فولدر')
        add_folder_button.clicked.connect(self.add_folder)
        remove_folder_button = QPushButton('− حذف مسیر انتخاب‌شده از کتابخانه')
        remove_folder_button.clicked.connect(self.remove_folder)
        library_buttons.addWidget(add_folder_button)
        library_buttons.addWidget(remove_folder_button)
        fl.addLayout(library_buttons)
        self.watch_folders = ToggleButton('شناسایی خودکار فیلم‌های جدید (هر ۹۰ ثانیه)')
        self.watch_folders.setChecked(bool(cfg.get('watch_folders', True)))
        self.watch_folders.toggled.connect(self.changed)
        fl.addWidget(self.watch_folders)
        self.recursive = ToggleButton("جستجو در زیرپوشه‌ها")
        self.recursive.setChecked(bool(cfg.get("recursive", True)))
        self.recursive.toggled.connect(self.changed)
        fl.addWidget(self.recursive)
        outer.addWidget(folder_panel)

        preview_panel = QFrame(objectName="panel")
        pl = QVBoxLayout(preview_panel)
        pl.setContentsMargins(20, 20, 20, 20)
        pl.setSpacing(12)
        pl.addWidget(QLabel("حالت پیش‌نمایش", objectName="sectionLabel"))
        self.preview_group = QButtonGroup(self)
        self.preview_group.setExclusive(True)
        prow = QHBoxLayout()
        self.preview_buttons = {}
        for key, text in (
            ("off", "خاموش"),
            ("hover", "فقط با موس — پیشنهادشده"),
            ("visible", "کارت‌های روی صفحه"),
        ):
            b = ToggleButton(text)
            b.setProperty("segment", True)
            self.preview_group.addButton(b)
            self.preview_buttons[key] = b
            b.clicked.connect(lambda checked=False, k=key: self.set_preview_mode(k))
            prow.addWidget(b)
        pl.addLayout(prow)
        info = QLabel("حالت روی صفحه اکنون از همان Preview زنده Hover با سرعت و FPS یکسان استفاده می‌کند. تعداد پخش‌های هم‌زمان از بخش عملکرد قابل تنظیم است؛ کارت‌های اضافی به‌نوبت پخش می‌شوند تا سیستم کند نشود.")
        info.setObjectName("muted")
        info.setWordWrap(True)
        pl.addWidget(info)
        outer.addWidget(preview_panel)
        outer.addStretch(1)
        self.pages.addWidget(page1)

        # --- Page 2: Performance ---
        page2, outer2 = self._make_page(
            "عملکرد و حافظه",
            "مصرف RAM و تعداد Worker را کنترل کنید. Wheel موس روی اعداد و Sliderها دیگر مقدار را عوض نمی‌کند."
        )

        resource_panel = QFrame(objectName="panel")
        rl = QVBoxLayout(resource_panel)
        rl.setContentsMargins(20, 20, 20, 20)
        rl.setSpacing(13)
        rl.addWidget(QLabel("حافظه Preview و کش", objectName="sectionLabel"))
        cache_row = QHBoxLayout()
        self.cache_off = ToggleButton("فقط RAM — بدون کش روی هارد")
        self.cache_on = ToggleButton("ذخیره Preview کنار برنامه")
        cache_row.addWidget(self.cache_off)
        cache_row.addWidget(self.cache_on)
        self.cache_off.clicked.connect(lambda: self.set_cache(False))
        self.cache_on.clicked.connect(lambda: self.set_cache(True))
        rl.addLayout(cache_row)

        self.clear_on_exit = ToggleButton("اگر کش روشن است، هنگام خروج پاک شود")
        self.clear_on_exit.setChecked(bool(cfg.get("clear_cache_on_exit", False)))
        self.clear_on_exit.toggled.connect(self.changed)
        rl.addWidget(self.clear_on_exit)

        ramrow = QHBoxLayout()
        ram_label = QLabel("حداکثر RAM برای Preview")
        ramrow.addWidget(ram_label)
        self.ram_slider = NoWheelSlider(Qt.Horizontal)
        self.ram_slider.setRange(128, 1024)
        self.ram_slider.setSingleStep(64)
        self.ram_slider.setPageStep(128)
        self.ram_slider.setValue(int(cfg.get("ram_limit_mb", 384)))
        self.ram_value = QLabel(f"{self.ram_slider.value()} MB")
        self.ram_value.setObjectName("valueBadge")
        self.ram_slider.valueChanged.connect(lambda v: self.ram_value.setText(f"{v} MB"))
        self.ram_slider.valueChanged.connect(self.changed)
        ramrow.addWidget(self.ram_slider, 1)
        ramrow.addWidget(self.ram_value)
        rl.addLayout(ramrow)

        cache_actions = QHBoxLayout()
        self.cache_size = QLabel()
        self.cache_size.setObjectName("muted")
        clear_cache = QPushButton("پاک کردن کش فعلی")
        clear_cache.clicked.connect(self.clear_cache)
        cache_actions.addWidget(self.cache_size)
        cache_actions.addStretch(1)
        cache_actions.addWidget(clear_cache)
        rl.addLayout(cache_actions)
        outer2.addWidget(resource_panel)

        display_panel = QFrame(objectName="panel")
        dl = QVBoxLayout(display_panel)
        dl.setContentsMargins(20, 20, 20, 20)
        dl.setSpacing(14)
        dl.addWidget(QLabel("نمایش و پردازش", objectName="sectionLabel"))
        self.gpu_decode = ToggleButton('GPU Decoder خودکار — آزمایشی، با fallback به CPU')
        self.gpu_decode.setChecked(bool(cfg.get('gpu_decode', False)))
        self.gpu_decode.setToolTip('با FFmpeg -hwaccel auto امتحان می‌کند؛ اگر اولین بخش شکست بخورد از CPU استفاده می‌کند.')
        self.gpu_decode.toggled.connect(self.changed)
        dl.addWidget(self.gpu_decode)
        self.hover_interpolation = ToggleButton('Motion Interpolation — ساخت فریم میانی واقعی (مصرف CPU بیشتر)')
        self.hover_interpolation.setChecked(bool(cfg.get('hover_interpolation', False)))
        self.hover_interpolation.setToolTip('از فیلتر FFmpeg minterpolate استفاده می‌کند؛ در ویدئوهای سنگین ممکن است Preview کند شود. پیش‌فرض خاموش است.')
        self.hover_interpolation.toggled.connect(self.changed)
        dl.addWidget(self.hover_interpolation)

        cardrow = QHBoxLayout()
        cardrow.addWidget(QLabel("اندازه کارت‌ها"))
        self.card_slider = NoWheelSlider(Qt.Horizontal)
        self.card_slider.setRange(220, 390)
        self.card_slider.setSingleStep(5)
        self.card_slider.setValue(int(cfg.get("card_width", 286)))
        self.card_value = QLabel(str(self.card_slider.value()))
        self.card_value.setObjectName("valueBadge")
        self.card_slider.valueChanged.connect(lambda v: self.card_value.setText(str(v)))
        self.card_slider.valueChanged.connect(self.changed)
        cardrow.addWidget(self.card_slider, 1)
        cardrow.addWidget(self.card_value)
        dl.addLayout(cardrow)

        fpsrow = QHBoxLayout()
        fps_text = QVBoxLayout()
        fps_text.addWidget(QLabel("نرمی Hover زنده"))
        fps_hint = QLabel("پیش‌فرض ۶۰ FPS؛ Frame pacing تطبیقی برای حرکت نرم‌تر و بدون پرش ریز.")
        fps_hint.setObjectName("muted")
        fps_text.addWidget(fps_hint)
        fpsrow.addLayout(fps_text, 1)
        self.hover_fps_slider = NoWheelSlider(Qt.Horizontal)
        self.hover_fps_slider.setRange(30, 60)
        self.hover_fps_slider.setSingleStep(1)
        self.hover_fps_slider.setValue(int(cfg.get("hover_video_fps", 60)))
        self.hover_fps_slider.setFixedWidth(180)
        self.hover_fps_value = QLabel(f"{self.hover_fps_slider.value()} FPS")
        self.hover_fps_value.setObjectName("valueBadge")
        self.hover_fps_slider.valueChanged.connect(lambda v: self.hover_fps_value.setText(f"{v} FPS"))
        self.hover_fps_slider.valueChanged.connect(self.changed)
        fpsrow.addWidget(self.hover_fps_slider)
        fpsrow.addWidget(self.hover_fps_value)
        dl.addLayout(fpsrow)

        visible_row = QHBoxLayout()
        visible_description = QVBoxLayout()
        visible_description.addWidget(QLabel("تعداد Preview زنده هم‌زمان روی صفحه"))
        visible_hint = QLabel("پیش‌فرض ۸ کارت؛ برای سیستم‌های ضعیف کمتر انتخاب کن. اگر تعداد فیلم‌های روی صفحه بیشتر باشد، به نوبت پخش می‌شوند.")
        visible_hint.setObjectName("muted")
        visible_hint.setWordWrap(True)
        visible_description.addWidget(visible_hint)
        visible_row.addLayout(visible_description, 1)
        self.visible_limit_spin = NoWheelSpinBox()
        self.visible_limit_spin.setRange(1, 24)
        self.visible_limit_spin.setValue(max(1, min(24, int(cfg.get('visible_live_limit', 8)))))
        self.visible_limit_spin.setFixedWidth(90)
        self.visible_limit_spin.valueChanged.connect(self.changed)
        visible_row.addWidget(self.visible_limit_spin)
        dl.addLayout(visible_row)

        speedrow = QHBoxLayout()
        speed_text = QVBoxLayout()
        speed_text.addWidget(QLabel("سرعت حرکت Hover"))
        speed_hint = QLabel("پیش‌فرض 2.0×؛ سرعت ویدئو را بالا می‌برد بدون اینکه FPS نمایش نصف شود.")
        speed_hint.setObjectName("muted")
        speed_text.addWidget(speed_hint)
        speedrow.addLayout(speed_text, 1)
        self.hover_speed_slider = NoWheelSlider(Qt.Horizontal)
        self.hover_speed_slider.setRange(10, 30)
        self.hover_speed_slider.setSingleStep(1)
        self.hover_speed_slider.setValue(int(round(float(cfg.get("hover_video_speed", 2.0)) * 10)))
        self.hover_speed_slider.setFixedWidth(180)
        self.hover_speed_value = QLabel(f"{self.hover_speed_slider.value() / 10:.1f}×")
        self.hover_speed_value.setObjectName("valueBadge")
        self.hover_speed_slider.valueChanged.connect(
            lambda v: self.hover_speed_value.setText(f"{v / 10:.1f}×")
        )
        self.hover_speed_slider.valueChanged.connect(self.changed)
        speedrow.addWidget(self.hover_speed_slider)
        speedrow.addWidget(self.hover_speed_value)
        dl.addLayout(speedrow)

        workerrow = QHBoxLayout()
        worker_text = QVBoxLayout()
        worker_text.addWidget(QLabel("Worker پردازش ویدئو"))
        worker_hint = QLabel("عدد بالاتر همیشه سریع‌تر نیست؛ Previewهای FFmpeg همزمان CPU را مصرف می‌کنند.")
        worker_hint.setObjectName("muted")
        worker_text.addWidget(worker_hint)
        workerrow.addLayout(worker_text, 1)
        self.worker_spin = NoWheelSpinBox()
        self.worker_spin.setRange(1, 24)
        self.worker_spin.setValue(int(cfg.get("workers", 4)))
        self.worker_spin.setFixedWidth(90)
        self.worker_spin.valueChanged.connect(self.changed)
        workerrow.addWidget(self.worker_spin)
        dl.addLayout(workerrow)
        outer2.addWidget(display_panel)
        outer2.addStretch(1)
        self.pages.addWidget(page2)

        # --- Page 3: Cloudflare ---
        page3, outer3 = self._make_page(
            "اشتراک اینترنتی",
            "فقط Cloudflare استفاده می‌شود. بخش تست جدید Ruleهای Windows Firewall را از ارتباط واقعی TCP/UDP 7844 جدا می‌کند تا دقیقاً معلوم شود انسداد روی سیستم است یا بعد از سیستم."
        )

        cloud_panel = QFrame(objectName="panel")
        cl = QVBoxLayout(cloud_panel)
        cl.setContentsMargins(20, 20, 20, 20)
        cl.setSpacing(13)
        cloud_head = QHBoxLayout()
        cloud_head.addWidget(QLabel("اشتراک وب", objectName="sectionLabel"))
        cloud_head.addStretch(1)
        self.cloud_version = QLabel("cloudflared: هنوز بررسی نشده")
        self.cloud_version.setObjectName("muted")
        cloud_head.addWidget(self.cloud_version)
        cl.addLayout(cloud_head)

        provider_row = QHBoxLayout()
        provider_row.addWidget(QLabel("مسیر فعال"))
        self.tunnel_provider = QLabel("Cloudflare Quick Tunnel — Direct / WARP Rescue")
        self.tunnel_provider.setObjectName("valueBadge")
        provider_row.addWidget(self.tunnel_provider)
        provider_row.addStretch(1)
        cl.addLayout(provider_row)

        status_box = QFrame(objectName="statusBox")
        sl = QHBoxLayout(status_box)
        sl.setContentsMargins(14, 11, 14, 11)
        sl.addWidget(QLabel("وضعیت"))
        self.cloud_status = QLabel("اشتراک‌گذاری خاموش است")
        self.cloud_status.setObjectName("cloudStatus")
        sl.addWidget(self.cloud_status, 1)
        cl.addWidget(status_box)

        self.cloud_progress = QProgressBar()
        self.cloud_progress.setRange(0, 100)
        self.cloud_progress.setValue(0)
        self.cloud_progress.setTextVisible(True)
        self.cloud_progress.setVisible(False)
        cl.addWidget(self.cloud_progress)

        url_row = QHBoxLayout()
        self.cloud_url = QLineEdit()
        self.cloud_url.setReadOnly(True)
        self.cloud_url.setPlaceholderText("بعد از اتصال سالم، لینک عمومی اینجا ظاهر می‌شود")
        self.cloud_url.setLayoutDirection(Qt.LeftToRight)
        self.cloud_url.setAlignment(Qt.AlignLeft)
        self.copy_url_btn = QPushButton("کپی لینک")
        self.copy_url_btn.setEnabled(False)
        self.copy_url_btn.clicked.connect(self.copy_cloud_url)
        self.open_url_btn = QPushButton("باز کردن سایت")
        self.open_url_btn.setEnabled(False)
        self.open_url_btn.clicked.connect(self.open_cloud_url)
        url_row.addWidget(self.cloud_url, 1)
        url_row.addWidget(self.copy_url_btn)
        url_row.addWidget(self.open_url_btn)
        cl.addLayout(url_row)

        action_row = QHBoxLayout()
        protection_row = QHBoxLayout()
        protection_row.addWidget(QLabel('اعتبار لینک اینترنتی (دقیقه)'))
        self.share_expire_spin = NoWheelSpinBox()
        self.share_expire_spin.setRange(5, 1440)
        self.share_expire_spin.setValue(int(cfg.get('share_expire_minutes', 240)))
        self.share_expire_spin.valueChanged.connect(self.changed)
        protection_row.addWidget(self.share_expire_spin)
        protection_row.addWidget(QLabel('رمز اختیاری (فقط برای نشست فعلی)'))
        self.share_password = QLineEdit()
        self.share_password.setEchoMode(QLineEdit.Password)
        self.share_password.setPlaceholderText('بدون رمز')
        self.share_password.setToolTip('رمز در فایل تنظیمات ذخیره نمی‌شود. کاربران باید آن را در مرورگر وارد کنند.')
        protection_row.addWidget(self.share_password, 1)
        cl.addLayout(protection_row)
        self.cloud_start_btn = QPushButton("شروع Cloudflare Tunnel")
        self.cloud_start_btn.setObjectName("primaryButton")
        self.cloud_start_btn.clicked.connect(self.cloud_start_requested.emit)
        self.cloud_stop_btn = QPushButton("توقف Tunnel")
        self.cloud_stop_btn.setEnabled(False)
        self.cloud_stop_btn.clicked.connect(self.cloud_stop_requested.emit)
        self.cloud_update_btn = QPushButton("بررسی cloudflared داخلی")
        self.cloud_update_btn.clicked.connect(self.cloud_update_requested.emit)
        self.cloud_diag_btn = QPushButton("تست کامل شبکه و پورت‌ها")
        self.cloud_diag_btn.clicked.connect(self.cloud_diag_requested.emit)
        self.cloud_warp_btn = QPushButton("نجات با Cloudflare WARP (443)")
        self.cloud_warp_btn.setToolTip("فقط با کلیک خودت فعال می‌شود. اگر WARP رسمی Cloudflare نصب باشد، مسیر WARP/MASQUE را فعال و سپس Tunnel را دوباره امتحان می‌کند.")
        self.cloud_warp_btn.clicked.connect(self.cloud_warp_requested.emit)
        self.cloud_firewall_btn = QPushButton("اصلاح Firewall ویندوز (Admin)")
        self.cloud_firewall_btn.setToolTip("فقط Ruleهای خروجی لازم برای cloudflared را با تأیید UAC می‌سازد؛ هیچ پورت ورودی باز نمی‌شود.")
        self.cloud_firewall_btn.clicked.connect(self.cloud_firewall_requested.emit)
        action_row.addWidget(self.cloud_start_btn)
        action_row.addWidget(self.cloud_stop_btn)
        action_row.addWidget(self.cloud_diag_btn)
        action_row.addWidget(self.cloud_warp_btn)
        action_row.addStretch(1)
        action_row.addWidget(self.cloud_update_btn)
        cl.addLayout(action_row)

        firewall_row = QHBoxLayout()
        firewall_text = QVBoxLayout()
        firewall_text.addWidget(QLabel("Windows Firewall"))
        firewall_hint = QLabel("اختیاری: اگر Policy خروجی ویندوز Block باشد، با UAC Ruleهای TCP/UDP 7844 و TCP 443 را می‌سازد. در حالت معمول Windows Outbound Allow است و Rule اختصاصی لازم نیست.")
        firewall_hint.setObjectName("muted")
        firewall_hint.setWordWrap(True)
        firewall_text.addWidget(firewall_hint)
        firewall_row.addLayout(firewall_text, 1)
        firewall_row.addWidget(self.cloud_firewall_btn)
        cl.addLayout(firewall_row)
        outer3.addWidget(cloud_panel)

        test_panel = QFrame(objectName="panel")
        tl = QVBoxLayout(test_panel)
        tl.setContentsMargins(20, 20, 20, 20)
        tl.setSpacing(10)
        test_head = QHBoxLayout()
        test_head.addWidget(QLabel("مرکز تست واقعی شبکه Cloudflare", objectName="sectionLabel"))
        test_head.addStretch(1)
        self.copy_test_btn = QPushButton("کپی نتیجه تست")
        self.copy_test_btn.setEnabled(False)
        self.copy_test_btn.clicked.connect(self.copy_cloud_test_result)
        test_head.addWidget(self.copy_test_btn)
        tl.addLayout(test_head)
        test_hint = QLabel("Policy واقعی Windows Firewall، TCP خام و Transport واقعی Cloudflare جدا تست می‌شوند. نبود Rule اختصاصی به‌تنهایی خطا نیست؛ ملاک نهایی Pre-check واقعی cloudflared برای QUIC/HTTP2 است.")
        test_hint.setObjectName("muted")
        test_hint.setWordWrap(True)
        tl.addWidget(test_hint)

        self.network_test_labels = {}
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(8)
        test_rows = (
            ("binary", "cloudflared داخلی"),
            ("firewall", "Windows Firewall Rules"),
            ("dns", "DNS Edgeهای Cloudflare"),
            ("dns_srv", "DNS SRV مخصوص Cloudflare Edge"),
            ("tcp7844", "TCP 7844 — اتصال خام"),
            ("http2", "HTTP/2 روی TCP 7844"),
            ("udp7844", "QUIC روی UDP 7844"),
            ("api443", "Cloudflare API روی 443"),
            ("quick443", "Quick Tunnel API روی 443"),
            ("warp", "Cloudflare WARP"),
        )
        for row, (key, title) in enumerate(test_rows):
            name = QLabel(title)
            value = QLabel("— هنوز تست نشده")
            value.setWordWrap(True)
            value.setObjectName("muted")
            grid.addWidget(name, row, 0)
            grid.addWidget(value, row, 1)
            self.network_test_labels[key] = value
        grid.setColumnStretch(1, 1)
        tl.addLayout(grid)

        verdict_box = QFrame(objectName="statusBox")
        vl = QHBoxLayout(verdict_box)
        vl.setContentsMargins(14, 11, 14, 11)
        vl.addWidget(QLabel("نتیجه"))
        self.network_test_verdict = QLabel("تست کامل را بزن تا مشخص شود مشکل دقیقاً کجاست.")
        self.network_test_verdict.setWordWrap(True)
        self.network_test_verdict.setObjectName("cloudStatus")
        vl.addWidget(self.network_test_verdict, 1)
        tl.addWidget(verdict_box)
        self._last_network_test_report = {}
        outer3.addWidget(test_panel)

        log_panel = QFrame(objectName="panel")
        ll = QVBoxLayout(log_panel)
        ll.setContentsMargins(20, 20, 20, 20)
        ll.setSpacing(11)
        log_head = QHBoxLayout()
        log_head.addWidget(QLabel("لاگ و عیب‌یابی", objectName="sectionLabel"))
        log_head.addStretch(1)
        self.copy_log_btn = QPushButton("کپی لاگ")
        self.copy_log_btn.clicked.connect(self.copy_cloud_log)
        self.clear_log_btn = QPushButton("پاک کردن")
        self.clear_log_btn.clicked.connect(self.clear_cloud_log)
        log_head.addWidget(self.copy_log_btn)
        log_head.addWidget(self.clear_log_btn)
        ll.addLayout(log_head)

        self.cloud_log = QPlainTextEdit()
        self.cloud_log.setReadOnly(True)
        self.cloud_log.setMaximumBlockCount(1500)
        self.cloud_log.setMinimumHeight(270)
        self.cloud_log.setPlaceholderText("وضعیت Connector، /ready، /quicktunnel، QUIC/HTTP2، PID، خروجی cloudflared و Health Check اینجا ثبت می‌شود…")
        self.cloud_log.setLayoutDirection(Qt.LeftToRight)
        ll.addWidget(self.cloud_log)
        note = QLabel("این نسخه فقط Cloudflare است. اگر 7844 مستقیم بسته باشد، دکمه WARP Rescue فقط با انتخاب خودت از Cloudflare WARP/MASQUE استفاده می‌کند و سپس cloudflared را دوباره تست می‌کند. هیچ سرویس ثالثی استفاده نمی‌شود.")
        note.setObjectName("muted")
        ll.addWidget(note)
        outer3.addWidget(log_panel, 1)
        self.pages.addWidget(page3)

        self.set_preview_mode(cfg.get("preview_mode", "hover"), emit=False)
        self.set_cache(bool(cfg.get("cache_enabled", False)), emit=False)
        self.update_cache_size()
        self.set_management_page(0)

    def _make_page(self, title_text, subtitle_text):
        scroll = SmoothScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        content = QWidget()
        scroll.setWidget(content)
        outer = QVBoxLayout(content)
        outer.setContentsMargins(24, 18, 24, 26)
        outer.setSpacing(16)
        title = QLabel(title_text)
        title.setObjectName("pageTitle")
        subtitle = QLabel(subtitle_text)
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        outer.addWidget(title)
        outer.addWidget(subtitle)
        return scroll, outer

    def set_management_page(self, index):
        index = max(0, min(int(index), self.pages.count() - 1))
        self.pages.setCurrentIndex(index)
        for i, btn in enumerate(self.nav_buttons):
            btn.blockSignals(True)
            btn.setChecked(i == index)
            btn.blockSignals(False)

    def _refresh_folder_list(self):
        if not hasattr(self, 'folder_list'):
            return
        self.folder_list.clear()
        for folder in library_folders(self.cfg):
            self.folder_list.addItem(folder)

    def add_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self, 'افزودن فولدر به کتابخانه', self.folder_edit.text() or str(Path.home()))
        if not folder:
            return
        paths = library_folders(self.cfg)
        if os.path.normcase(folder) not in {os.path.normcase(p) for p in paths}:
            paths.append(folder)
        if not paths:
            return
        self.cfg['folders'] = paths
        self.cfg['folder'] = paths[0]
        self.folder_edit.setText(paths[0])
        self._refresh_folder_list()
        self.folder_changed.emit(paths[0])
        self.changed()

    def remove_folder(self):
        selected = self.folder_list.currentItem()
        if not selected:
            return
        removed = selected.text()
        paths = [p for p in library_folders(self.cfg) if os.path.normcase(p) != os.path.normcase(removed)]
        self.cfg['folders'] = paths
        self.cfg['folder'] = paths[0] if paths else ''
        self.folder_edit.setText(self.cfg['folder'])
        self._refresh_folder_list()
        self.folder_changed.emit(self.cfg['folder'])
        self.changed()

    def pick_folder(self):
        # Existing "Choose folder" changes the primary library root, preserving
        # the additional folders already configured.
        folder = QFileDialog.getExistingDirectory(
            self, 'انتخاب فولدر اصلی', self.folder_edit.text() or str(Path.home()))
        if folder:
            other = [p for p in library_folders(self.cfg)
                     if os.path.normcase(p) != os.path.normcase(folder)]
            self.cfg['folder'] = folder
            self.cfg['folders'] = [folder] + other
            self.folder_edit.setText(folder)
            self._refresh_folder_list()
            self.folder_changed.emit(folder)
            self.changed()

    def set_preview_mode(self, key, emit=True):
        for k, b in self.preview_buttons.items():
            b.blockSignals(True)
            b.setChecked(k == key)
            b.blockSignals(False)
        self.cfg["preview_mode"] = key
        if emit:
            self.changed()

    def set_cache(self, enabled, emit=True):
        self.cache_off.blockSignals(True)
        self.cache_on.blockSignals(True)
        self.cache_off.setChecked(not enabled)
        self.cache_on.setChecked(enabled)
        self.cache_off.blockSignals(False)
        self.cache_on.blockSignals(False)
        self.cfg["cache_enabled"] = bool(enabled)
        if emit:
            self.changed()

    def clear_cache(self):
        clear_cache_dir()
        self.update_cache_size()
        QMessageBox.information(self, "کش", "کش روی هارد پاک شد.")

    def update_cache_size(self):
        total = 0
        if CACHE_DIR.exists():
            for p in CACHE_DIR.rglob("*"):
                if p.is_file():
                    try:
                        total += p.stat().st_size
                    except OSError:
                        pass
        self.cache_size.setText(f"کش روی هارد: {human_size(total)}")

    def changed(self, *args):
        self.cfg.update({
            "folder": self.folder_edit.text(),
            "folders": list(library_folders(self.cfg)),
            "watch_folders": self.watch_folders.isChecked(),
            "gpu_decode": self.gpu_decode.isChecked(),
            "share_expire_minutes": self.share_expire_spin.value(),
            "recursive": self.recursive.isChecked(),
            "clear_cache_on_exit": self.clear_on_exit.isChecked(),
            "ram_limit_mb": self.ram_slider.value(),
            "card_width": self.card_slider.value(),
            "hover_video_fps": self.hover_fps_slider.value(),
            "hover_video_speed": self.hover_speed_slider.value() / 10.0,
            "visible_live_limit": self.visible_limit_spin.value(),
            "hover_interpolation": self.hover_interpolation.isChecked(),
            "workers": self.worker_spin.value(),
        })
        save_config(self.cfg)
        self.settings_changed.emit()

    def set_cloud_status(self, text):
        self.cloud_status.setText(text)

    def set_cloud_url(self, url):
        self.cloud_url.setText(url or "")
        enabled = bool(url)
        self.copy_url_btn.setEnabled(enabled)
        self.open_url_btn.setEnabled(enabled)

    def set_cloud_progress(self, value):
        value = int(value)
        self.cloud_progress.setVisible(value < 100)
        self.cloud_progress.setValue(value)
        if value >= 100:
            QTimer.singleShot(900, lambda: self.cloud_progress.setVisible(False))

    def set_cloud_running(self, running):
        self.cloud_running = bool(running)
        self.cloud_start_btn.setEnabled(not self.cloud_running)
        self.cloud_stop_btn.setEnabled(self.cloud_running)
        self.cloud_update_btn.setEnabled(not self.cloud_running)
        if hasattr(self, "cloud_diag_btn"):
            self.cloud_diag_btn.setEnabled(not self.cloud_running)

    def set_cloud_version(self, text):
        self.cloud_version.setText(text or "cloudflared")

    def set_tunnel_provider(self, text):
        self.tunnel_provider.setText(text or "Cloudflare Quick Tunnel — فقط Cloudflare")

    def set_network_diagnostics(self, report):
        report = report or {}
        if report.get("phase") == "running":
            self.copy_test_btn.setEnabled(False)
            self.network_test_verdict.setText("⏳ در حال تست DNS، Firewall، TCP/UDP 7844 و Cloudflare API…")
            for label in self.network_test_labels.values():
                label.setText("⏳ در حال بررسی…")
                label.setToolTip("")
            return

        self._last_network_test_report = report
        icons = {"pass": "✅", "fail": "❌", "warn": "⚠️", "unknown": "❔", "info": "ℹ️"}
        items = report.get("items", {})
        for key, label in self.network_test_labels.items():
            item = items.get(key, {})
            state = item.get("state", "unknown")
            summary = item.get("summary", "نتیجه موجود نیست")
            detail = item.get("detail", "")
            label.setText(f"{icons.get(state, '•')} {summary}")
            label.setToolTip(detail)
        verdict = report.get("verdict") or "تست تمام شد."
        vstate = report.get("verdict_state", "unknown")
        self.network_test_verdict.setText(f"{icons.get(vstate, '•')} {verdict}")
        self.copy_test_btn.setEnabled(bool(items))

    def copy_cloud_test_result(self):
        report = self._last_network_test_report or {}
        if not report:
            return
        lines = [f"VideoShelf {APP_VERSION}", f"Network test: {report.get('timestamp','')}"]
        order = ("binary","firewall","dns","dns_srv","tcp7844","http2","udp7844","api443","quick443","warp")
        titles = {
            "binary":"cloudflared", "firewall":"Windows Firewall", "dns":"DNS",
            "dns_srv":"Cloudflare Edge SRV DNS",
            "tcp7844":"TCP 7844 raw", "http2":"HTTP2/TCP 7844", "udp7844":"QUIC/UDP 7844",
            "api443":"Cloudflare API 443", "quick443":"Quick Tunnel API 443", "warp":"WARP"
        }
        items = report.get("items", {})
        for key in order:
            item = items.get(key, {})
            lines.append(f"{titles[key]}: {item.get('state','?').upper()} — {item.get('summary','')}")
            if item.get("detail"):
                lines.append(f"  {item['detail']}")
        lines.append("VERDICT: " + (report.get("verdict") or ""))
        QApplication.clipboard().setText("\n".join(lines))
        self.cloud_status.setText("نتیجه کامل تست شبکه در Clipboard کپی شد")

    def reset_cloud_log(self):
        self.cloud_log.clear()

    def append_cloud_log(self, line):
        if not line:
            return
        self.cloud_log.appendPlainText(str(line))
        bar = self.cloud_log.verticalScrollBar()
        bar.setValue(bar.maximum())

    def clear_cloud_log(self):
        self.cloud_log.clear()

    def copy_cloud_log(self):
        text = self.cloud_log.toPlainText().strip()
        if text:
            QApplication.clipboard().setText(text)
            self.cloud_status.setText("لاگ کامل در Clipboard کپی شد")

    def copy_cloud_url(self):
        url = self.cloud_url.text().strip()
        if url:
            QApplication.clipboard().setText(url)
            self.cloud_status.setText("لینک در Clipboard کپی شد")

    def open_cloud_url(self):
        url = self.cloud_url.text().strip()
        if url:
            webbrowser.open(url)


class PreciseSeekSlider(QSlider):
    """Seek anywhere on the track; press/drag/release is one atomic gesture.

    QSlider's default page-step handling on empty track regions can skip
    sliderReleased, leaving an application in permanent 'scrubbing' mode.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._manual_drag = False

    def _pointer_to_value(self, x):
        return QStyle.sliderValueFromPosition(
            self.minimum(), self.maximum(), round(x), max(1, self.width()), False)

    def _seek_pointer(self, x):
        value = self._pointer_to_value(x)
        # setSliderPosition on a pressed slider emits sliderMoved; it is wired
        # to the throttled decoder and the immediate timestamp preview.
        self.setSliderPosition(value)

    def wheelEvent(self, event):
        # Mouse wheel over timeline must never unexpectedly seek several minutes.
        event.ignore()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.maximum() > self.minimum():
            self._manual_drag = True
            self.setSliderDown(True)   # always emits sliderPressed
            self._seek_pointer(event.position().x())
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._manual_drag and (event.buttons() & Qt.LeftButton):
            self._seek_pointer(event.position().x())
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._manual_drag and event.button() == Qt.LeftButton:
            self._seek_pointer(event.position().x())
            self._manual_drag = False
            self.setSliderDown(False)  # always emits sliderReleased
            event.accept()
            return
        super().mouseReleaseEvent(event)


class ZoomVideoSurface(QWidget):
    """Clips a scaled QVideoWidget, keeping its video aspect ratio unchanged."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('zoomVideoSurface')
        self.setMinimumHeight(158)
        self.zoom_percent = 100
        self.video_widget = QVideoWidget(self) if QVideoWidget else QLabel('Qt Multimedia موجود نیست', self)
        if QVideoWidget:
            self.video_widget.setAspectRatioMode(Qt.KeepAspectRatio)
        self.video_widget.show()

    def set_zoom(self, percent: int):
        self.zoom_percent = max(100, min(220, int(percent)))
        self._fit_video_widget()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit_video_widget()

    def _fit_video_widget(self):
        scale = self.zoom_percent / 100.0
        w = max(1, round(self.width() * scale))
        h = max(1, round(self.height() * scale))
        self.video_widget.setGeometry((self.width() - w) // 2, (self.height() - h) // 2, w, h)


class InternalVideoPlayer(QWidget):
    """Reusable independent player window with debounced live scrubbing.

    Native title bar supports dragging to any screen corner and normal Windows
    snap/resize. Geometry is persisted only outside fullscreen mode.
    """
    back_requested = Signal()

    def __init__(self, cfg, parent=None):
        super().__init__(parent, Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self.cfg = cfg
        self.path = None
        self._ready = QMediaPlayer is not None
        self._dragging = False
        self._pending_seek = None
        self._seek_ui_guard_until = 0.0
        self._restored = False
        self._suppress_close_signal = False
        self.setAttribute(Qt.WA_DeleteOnClose, False)
        self.setWindowTitle('VideoShelf  •  پلیر داخلی')
        self.setObjectName('internalPlayer')
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMinimumSize(470, 335)
        self.resize(850, 600)

        self._geom_timer = QTimer(self)
        self._geom_timer.setSingleShot(True)
        self._geom_timer.setInterval(650)
        self._geom_timer.timeout.connect(self._persist_geometry)
        self._seek_timer = QTimer(self)
        self._seek_timer.setSingleShot(True)
        self._seek_timer.setInterval(175)
        self._seek_timer.timeout.connect(self._apply_pending_seek)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 13)
        layout.setSpacing(8)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        back = QPushButton('←  کتابخانه')
        back.setToolTip('بستن پلیر شناور و بازگشت به کتابخانه (Esc)')
        back.clicked.connect(self.close)
        bar.addWidget(back)
        self.title_label = QLabel('پلیر شناور VideoShelf')
        self.title_label.setObjectName('playerTitle')
        self.title_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        bar.addWidget(self.title_label, 1)
        self.pin_button = QPushButton('📌')
        self.pin_button.setCheckable(True)
        self.pin_button.setToolTip('همیشه روی پنجره‌های دیگر بماند')
        self.pin_button.toggled.connect(self.set_always_on_top)
        bar.addWidget(self.pin_button)
        self.fit_button = QPushButton('اندازه صفحه')
        self.fit_button.setToolTip('پرکردن فضای قابل‌استفاده مانیتور بدون تغییر نسبت فیلم')
        self.fit_button.clicked.connect(self.fit_to_screen)
        bar.addWidget(self.fit_button)
        self.mini_button = QPushButton('کوچک')
        self.mini_button.setToolTip('کوچک کردن پلیر برای قرار دادن در گوشه صفحه')
        self.mini_button.clicked.connect(lambda: self.set_window_size_percent(28))
        bar.addWidget(self.mini_button)
        self.fullscreen_button = QPushButton('⛶  تمام‌صفحه')
        self.fullscreen_button.clicked.connect(self.toggle_fullscreen)
        bar.addWidget(self.fullscreen_button)
        layout.addLayout(bar)

        self.surface = ZoomVideoSurface(self)
        layout.addWidget(self.surface, 1)
        self.video_widget = self.surface.video_widget
        self._surface_click = QTimer(self)
        self._surface_click.setSingleShot(True)
        self._surface_click.setInterval(235)
        self._suppress_surface_release = False
        self._surface_click.timeout.connect(self.toggle_play)
        self.surface.installEventFilter(self)
        self.video_widget.installEventFilter(self)
        if self._ready:
            self.audio = QAudioOutput(self)
            self.audio.setVolume(0.8)
            self.media = QMediaPlayer(self)
            self.media.setAudioOutput(self.audio)
            self.media.setVideoOutput(self.video_widget)
            self.media.positionChanged.connect(self._position_changed)
            self.media.durationChanged.connect(self._duration_changed)
            self.media.errorOccurred.connect(self._playback_error)
            self.media.playbackStateChanged.connect(self._state_changed)
        else:
            self.audio = self.media = None

        self.status = QLabel('پنجره را از نوار عنوان بکش؛ محل و اندازه‌اش برای فیلم بعدی حفظ می‌شود.')
        self.status.setObjectName('playerStatus')
        layout.addWidget(self.status)

        seek_row = QHBoxLayout()
        seek_row.setSpacing(7)
        self.play_button = QPushButton('⏸  مکث')
        self.play_button.setEnabled(self._ready)
        self.play_button.clicked.connect(self.toggle_play)
        seek_row.addWidget(self.play_button)
        rewind = QPushButton('↶ ۱۰')
        rewind.setToolTip('۱۰ ثانیه به عقب')
        rewind.clicked.connect(lambda: self.seek_relative(-10000))
        seek_row.addWidget(rewind)
        self.seek_slider = PreciseSeekSlider(Qt.Horizontal)
        self.seek_slider.setLayoutDirection(Qt.LeftToRight)
        self.seek_slider.setRange(0, 0)
        self.seek_slider.setToolTip('کلیک یا درگ برای جابه‌جایی؛ Seekهای پشت سر هم کنترل می‌شوند')
        self.seek_slider.sliderPressed.connect(self._begin_scrub)
        self.seek_slider.sliderMoved.connect(self._scrub_to)
        self.seek_slider.sliderReleased.connect(self._finish_scrub)
        seek_row.addWidget(self.seek_slider, 1)
        forward = QPushButton('۱۰ ↷')
        forward.setToolTip('۱۰ ثانیه به جلو')
        forward.clicked.connect(lambda: self.seek_relative(10000))
        seek_row.addWidget(forward)
        self.time_label = QLabel('00:00 / 00:00')
        self.time_label.setMinimumWidth(112)
        seek_row.addWidget(self.time_label)
        layout.addLayout(seek_row)

        option_row = QHBoxLayout()
        option_row.setSpacing(7)
        option_row.addWidget(QLabel('اندازه پنجره'))
        self.window_size = QSlider(Qt.Horizontal)
        self.window_size.setLayoutDirection(Qt.LeftToRight)
        self.window_size.setRange(25, 100)
        self.window_size.setValue(65)
        self.window_size.setFixedWidth(115)
        self.window_size.valueChanged.connect(self.set_window_size_percent)
        option_row.addWidget(self.window_size)
        self.window_percent = QLabel('65%')
        option_row.addWidget(self.window_percent)
        option_row.addSpacing(11)
        option_row.addWidget(QLabel('زوم تصویر'))
        self.video_zoom = QSlider(Qt.Horizontal)
        self.video_zoom.setLayoutDirection(Qt.LeftToRight)
        self.video_zoom.setRange(100, 220)
        self.video_zoom.setValue(100)
        self.video_zoom.setFixedWidth(105)
        self.video_zoom.valueChanged.connect(self._change_video_zoom)
        option_row.addWidget(self.video_zoom)
        self.video_zoom_label = QLabel('100%')
        option_row.addWidget(self.video_zoom_label)
        reset_zoom = QPushButton('۱:۱')
        reset_zoom.setToolTip('بازگشت تصویر به اندازه عادی بدون کشیدگی')
        reset_zoom.clicked.connect(lambda: self.video_zoom.setValue(100))
        option_row.addWidget(reset_zoom)
        option_row.addStretch(1)
        self.volume_label = QLabel('صدا')
        option_row.addWidget(self.volume_label)
        self.volume = QSlider(Qt.Horizontal)
        self.volume.setLayoutDirection(Qt.LeftToRight)
        self.volume.setRange(0, 100)
        self.volume.setValue(80)
        self.volume.setFixedWidth(80)
        self.volume.valueChanged.connect(self._set_volume)
        option_row.addWidget(self.volume)
        self.external_button = QPushButton('پلیر ویندوز')
        self.external_button.clicked.connect(self.open_external)
        option_row.addWidget(self.external_button)
        layout.addLayout(option_row)

        # Keep player styling independent of the rest of the application UI.
        self.setStyleSheet("""
            QWidget#internalPlayer { background: #090f1c; color: #edf4ff; }
            QWidget#zoomVideoSurface { background: #030711; border: 1px solid #293850; border-radius: 9px; }
            QLabel#playerTitle { color: #edf4ff; font-weight: 700; font-size: 14px; }
            QLabel#playerStatus { color: #91a8c4; font-size: 11px; }
            QPushButton { padding: 7px 9px; border-radius: 8px; border: 1px solid #344764;
                          background: #1c2a42; color: #f2f6ff; }
            QPushButton:hover { background: #2a4062; border-color: #5974a1; }
            QPushButton:checked { background: #4459a2; }
            QSlider::groove:horizontal { height: 5px; background: #293b55; border-radius: 2px; }
            QSlider::sub-page:horizontal { background: #7f99fb; border-radius: 2px; }
            QSlider::handle:horizontal { width: 14px; margin: -5px 0; border-radius: 7px;
                                         background: #dbe5ff; }
        """)
        for seq, func in (('Space', self.toggle_play),
                          ('Left', lambda: self.seek_relative(-5000)),
                          ('Right', lambda: self.seek_relative(5000)),
                          ('F', self.toggle_fullscreen),
                          ('Esc', self.escape_action)):
            shortcut = QShortcut(QKeySequence(seq), self)
            shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            shortcut.activated.connect(func)

    def eventFilter(self, obj, event):
        if obj in (self.surface, self.video_widget):
            typ = event.type()
            if typ == QEvent.Type.Wheel:
                delta = event.angleDelta().y()
                if delta:
                    steps = 1 if delta > 0 else -1
                    if event.modifiers() & Qt.ControlModifier:
                        self.video_zoom.setValue(self.video_zoom.value() + 10 * steps)
                    else:
                        self.volume.setValue(self.volume.value() + 5 * steps)
                    event.accept()
                    return True
            elif typ == QEvent.Type.MouseButtonDblClick and event.button() == Qt.LeftButton:
                self._surface_click.stop()
                self._suppress_surface_release = True
                self.toggle_fullscreen()
                event.accept()
                return True
            elif typ == QEvent.Type.MouseButtonRelease and event.button() == Qt.LeftButton:
                if self._suppress_surface_release:
                    self._suppress_surface_release = False
                    event.accept()
                    return True
                # A single click pauses/plays. Wait briefly to distinguish the
                # double-click gesture for fullscreen (no spurious pause).
                if not self._surface_click.isActive():
                    self._surface_click.start()
                event.accept()
                return True
        return super().eventFilter(obj, event)

    def _screen_rect(self):
        # If a monitor has been unplugged, always restore somewhere visible.
        screen = self.screen() or QApplication.primaryScreen()
        return screen.availableGeometry()

    def _restore_geometry(self):
        saved = self.cfg.get('player_window_geometry')
        rect = self._screen_rect()
        if isinstance(saved, list) and len(saved) == 4:
            try:
                x, y, w, h = [int(v) for v in saved]
                w = max(470, min(w, rect.width()))
                h = max(335, min(h, rect.height()))
                x = max(rect.x(), min(x, rect.right() - w + 1))
                y = max(rect.y(), min(y, rect.bottom() - h + 1))
                self.setGeometry(x, y, w, h)
            except (ValueError, TypeError):
                self._default_geometry(rect)
        else:
            self._default_geometry(rect)
        self.pin_button.setChecked(bool(self.cfg.get('player_always_on_top', False)))
        self._restored = True
        self._sync_window_size_label()

    def _default_geometry(self, rect):
        w = max(470, min(850, round(rect.width() * 0.65)))
        h = max(335, min(rect.height(), round(w * 0.5625) + 170))
        self.setGeometry(rect.right() - w - 18, rect.y() + 45, w, h)

    def _persist_geometry(self):
        if not self._restored or self.isFullScreen() or self.isMaximized():
            return
        g = self.geometry()
        self.cfg['player_window_geometry'] = [g.x(), g.y(), g.width(), g.height()]
        save_config(self.cfg)

    def _sync_window_size_label(self):
        rect = self._screen_rect()
        percent = max(25, min(100, round(self.width() * 100 / max(1, rect.width()))))
        self.window_size.blockSignals(True)
        self.window_size.setValue(percent)
        self.window_size.blockSignals(False)
        self.window_percent.setText(f'{percent}%')

    def moveEvent(self, event):
        super().moveEvent(event)
        if self._restored and not self.isFullScreen():
            self._geom_timer.start()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._restored and not self.isFullScreen():
            self._sync_window_size_label()
            compact = self.width() < 740
            self.fit_button.setVisible(not compact)
            self.mini_button.setVisible(not compact)
            self.external_button.setVisible(not compact)
            self.volume_label.setVisible(not compact)
            self.volume.setVisible(not compact)
            self._geom_timer.start()

    def set_window_size_percent(self, percent):
        if self.isFullScreen() or self.isMaximized():
            self.showNormal()
        rect = self._screen_rect()
        width = max(470, min(rect.width(), round(rect.width() * percent / 100)))
        height = max(335, min(rect.height(), round(width * 9 / 16) + 172))
        self.resize(width, height)
        x = max(rect.x(), min(self.x(), rect.right() - width + 1))
        y = max(rect.y(), min(self.y(), rect.bottom() - height + 1))
        self.move(x, y)

    def fit_to_screen(self):
        if self.isFullScreen() or self.isMaximized():
            self.showNormal()
        rect = self._screen_rect()
        self.setGeometry(rect.adjusted(2, 2, -2, -2))
        self._geom_timer.start()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.fullscreen_button.setText('⛶  تمام‌صفحه')
        else:
            self._persist_geometry()
            self.showFullScreen()
            self.fullscreen_button.setText('⤢  پنجره')

    def set_always_on_top(self, enabled):
        self.cfg['player_always_on_top'] = bool(enabled)
        current = self.geometry()
        is_visible = self.isVisible()
        self.setWindowFlag(Qt.WindowStaysOnTopHint, bool(enabled))
        if is_visible:
            self.show()
            self.setGeometry(current)
        save_config(self.cfg)

    def _change_video_zoom(self, percent):
        self.surface.set_zoom(percent)
        self.video_zoom_label.setText(f'{percent}%')

    def show_player(self):
        if not self._restored:
            self._restore_geometry()
        else:
            # Recover gracefully if the window was left on a disconnected monitor.
            rect = self._screen_rect()
            if not self.geometry().intersects(rect):
                self._default_geometry(rect)
        self.show()
        self.raise_()
        self.activateWindow()

    def open_file(self, path: str):
        self.path = path
        self.title_label.setText(Path(path).name)
        self.setWindowTitle('VideoShelf  •  ' + Path(path).name)
        self.status.setText('در حال باز کردن فیلم…')
        self._seek_timer.stop()
        self._pending_seek = None
        self._dragging = False
        self._seek_ui_guard_until = 0
        self.seek_slider.setRange(0, 0)
        self.time_label.setText('00:00 / 00:00')
        self.show_player()
        if self.media is None:
            self.status.setText('Qt Multimedia موجود نیست؛ از دکمه پلیر ویندوز استفاده کنید.')
            return
        self.media.stop()
        self.media.setSource(QUrl.fromLocalFile(str(Path(path).resolve())))
        self.media.play()
        self.setFocus(Qt.OtherFocusReason)

    def stop(self):
        self._surface_click.stop()
        self._seek_timer.stop()
        self._pending_seek = None
        self._dragging = False
        if self.media:
            self.media.stop()
            self.media.setSource(QUrl())
        self.path = None

    def shutdown(self):
        self._persist_geometry()
        self._geom_timer.stop()
        self._suppress_close_signal = True
        self.stop()
        self.hide()

    def closeEvent(self, event):
        self._persist_geometry()
        self.stop()
        if not self._suppress_close_signal:
            self.back_requested.emit()
        super().closeEvent(event)

    def escape_action(self):
        if self.isFullScreen():
            self.toggle_fullscreen()
        else:
            self.close()

    def toggle_play(self):
        if not self.media:
            return
        if self.media.playbackState() == QMediaPlayer.PlayingState:
            self.media.pause()
        elif self.path:
            self.media.play()

    def _state_changed(self, state):
        self.play_button.setText('⏸  مکث' if state == QMediaPlayer.PlayingState else '▶  پخش')
        if state == QMediaPlayer.PlayingState:
            self.status.setText('')

    def _position_changed(self, pos):
        if not self._dragging and time.monotonic() > self._seek_ui_guard_until:
            self.seek_slider.setValue(int(pos))
        protected = self._dragging or time.monotonic() <= self._seek_ui_guard_until
        self._set_time_text(self.seek_slider.value() if protected else pos)

    def _set_time_text(self, pos):
        duration = self.media.duration() if self.media else 0
        self.time_label.setText(f'{human_duration(pos / 1000)} / {human_duration(duration / 1000)}')

    def _duration_changed(self, duration):
        self.seek_slider.setRange(0, max(0, int(duration)))
        self._position_changed(self.media.position())

    def _begin_scrub(self):
        self._dragging = True
        self._pending_seek = None

    def _scrub_to(self, value):
        self._dragging = True
        self._pending_seek = int(value)
        self._set_time_text(value)  # UI updates immediately; no decoder wait.
        if not self._seek_timer.isActive():
            self._seek_timer.start()

    def _apply_pending_seek(self):
        if self._pending_seek is None or self.media is None:
            return
        pos = self._pending_seek
        self._pending_seek = None
        if self.media.isSeekable():
            self.media.setPosition(max(0, min(self.media.duration(), pos)))
        if self._pending_seek is not None:
            self._seek_timer.start()

    def _finish_scrub(self):
        self._seek_timer.stop()
        if self.media:
            pos = self._pending_seek if self._pending_seek is not None else self.seek_slider.value()
            self._pending_seek = None
            self._seek_ui_guard_until = time.monotonic() + 0.32
            if self.media.isSeekable():
                self.media.setPosition(max(0, min(self.media.duration(), int(pos))))
        self._dragging = False

    def seek_relative(self, millis: int):
        if self.media and self.media.duration() > 0 and self.media.isSeekable():
            old_pos = self.seek_slider.value() if self._dragging else self.media.position()
            target = max(0, min(self.media.duration(), old_pos + millis))
            self._seek_ui_guard_until = time.monotonic() + 0.32
            self.seek_slider.setValue(target)
            self._set_time_text(target)
            self.media.setPosition(target)

    def _set_volume(self, volume: int):
        if self.audio:
            self.audio.setVolume(volume / 100.0)

    def _playback_error(self, error, message):
        if error != QMediaPlayer.Error.NoError:
            self.status.setText('خطای پخش داخلی: ' + str(message) + ' — پلیر ویندوز را امتحان کنید.')

    def open_external(self):
        if self.path and Path(self.path).is_file():
            if os.name == 'nt':
                os.startfile(self.path)
            else:
                subprocess.Popen(['xdg-open', self.path])


class LibraryTab(QWidget):
    library_changed = Signal(object)
    manage_requested = Signal()

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.catalog = LibraryCatalog()
        self._scan_inflight = False
        self._scan_repeat = False
        self._last_scan_fingerprint = None
        self._scan_started_at = 0.0
        self._last_scan_files_fingerprint = None
        self.model = VideoModel()
        self.proxy = SortFilterProxy()
        self.proxy.setSourceModel(self.model)

        self.loader = MediaLoader(self.model, cfg)
        self.loader.bus.metadata_ready.connect(self._cache_metadata)
        self.scan_bus = WorkerBus()
        self.scan_bus.scan_ready.connect(self.on_scan_ready)
        self.scan_bus.scan_failed.connect(self.on_scan_failed)
        self.scan_pool = QThreadPool()
        self.scan_pool.setMaxThreadCount(1)
        self.move_bus = MoveBus()
        self.move_bus.finished.connect(self._move_finished)
        self.move_pool = QThreadPool()
        self.move_pool.setMaxThreadCount(1)
        self.move_busy = False
        self.duplicate_bus = DuplicateBus()
        self.duplicate_bus.completed.connect(self._duplicates_ready)
        self.duplicate_bus.failed.connect(self._duplicates_failed)
        self.duplicates_running = False
        self.timeline_pool = QThreadPool()
        self.timeline_pool.setMaxThreadCount(1)
        self.timeline_bus = TimelineBus(self)
        self.timeline_bus.frame_ready.connect(self._display_timeline_frame)
        self.technical_bus = TechnicalBus(self)
        self.technical_bus.ready.connect(self._display_technical_info)
        self._technical_target = None
        self._technical_request_id = 0
        self._timeline_target = None
        self._timeline_request_id = 0
        self.watch_timer = QTimer(self)
        self.watch_timer.setInterval(90000)
        self.watch_timer.timeout.connect(self._watch_scan)
        self.watch_timer.start()
        self.perf_timer = QTimer(self)
        self.perf_timer.setInterval(1200)
        self.perf_timer.timeout.connect(self._update_performance)
        self.perf_timer.start()
        self._ps_process = psutil.Process(os.getpid()) if psutil else None
        self._ps_children = {}
        if self._ps_process:
            self._ps_process.cpu_percent(None)

        self.hover_path = None
        self.visible_paths = set()
        self.selected_paths = []
        self._pending_rating_renames = {}
        self._rating_rename_attempts = {}
        self._rename_errors = []
        self._rating_rename_timer = QTimer(self)
        self._rating_rename_timer.setSingleShot(True)
        self._rating_rename_timer.timeout.connect(self._flush_rating_renames)

        self.web_sync_timer = QTimer(self)
        self.web_sync_timer.setSingleShot(True)
        self.web_sync_timer.setInterval(700)
        self.web_sync_timer.timeout.connect(self.emit_library_changed)
        self.model.dataChanged.connect(self.on_model_data_changed)

        self.animation_timer = QTimer(self)
        self.animation_timer.setInterval(1000)
        self.animation_timer.timeout.connect(self.advance_animations)
        self.animation_timer.start()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 19)
        outer.setSpacing(15)

        intro = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(3)
        library_title = QLabel("کتابخانه ویدئوها")
        library_title.setObjectName("libraryTitle")
        library_subtitle = QLabel("مرور، پیش‌نمایش سریع و مدیریت مجموعه شما")
        library_subtitle.setObjectName("muted")
        titles.addWidget(library_title)
        titles.addWidget(library_subtitle)
        intro.addLayout(titles)
        intro.addStretch(1)
        self.folder_chip = QLabel()
        self.folder_chip.setObjectName("folderChip")
        self._update_folder_chip()
        intro.addWidget(self.folder_chip)
        outer.addLayout(intro)

        toolbar_panel = QFrame(objectName="toolbarPanel")
        toolbar = QHBoxLayout(toolbar_panel)
        toolbar.setContentsMargins(14, 13, 14, 13)
        toolbar.setSpacing(10)
        self.search = QLineEdit()
        self.search.setPlaceholderText("⌕   نام فیلم را جست‌وجو کنید…")
        self.search.setClearButtonEnabled(True)
        self.search.setObjectName("searchField")
        self.search.textChanged.connect(self.on_search)

        self.sort = NoWheelComboBox()
        self.sort.addItems(["نام", "امتیاز ★", "حجم", "مدت", "تاریخ"])
        sort_map = {"name": 0, "rating": 1, "size": 2, "duration": 3, "date": 4}
        self.sort.setCurrentIndex(sort_map.get(cfg.get("sort", "name"), 0))
        self.sort.currentIndexChanged.connect(self.on_sort)
        self.apply_sort_button = QPushButton('↻  اعمال ترتیب جدید ★')
        self.apply_sort_button.setToolTip('ستاره‌ها بلافاصله ذخیره می‌شوند، ولی جای کارت‌ها تنها با این دکمه عوض می‌شود.')
        self.apply_sort_button.clicked.connect(self.apply_rating_sort)
        self.apply_sort_button.setVisible(False)
        self._rating_sort_dirty = False

        self.preview_mode_combo = NoWheelComboBox()
        self.preview_mode_combo.addItem("Preview: موس — زنده", "hover")
        self.preview_mode_combo.addItem("Preview: روی صفحه", "visible")
        self.preview_mode_combo.addItem("Preview: خاموش", "off")
        mode_idx = {"hover": 0, "visible": 1, "off": 2}.get(cfg.get("preview_mode", "hover"), 0)
        self.preview_mode_combo.setCurrentIndex(mode_idx)
        self.preview_mode_combo.currentIndexChanged.connect(self.on_preview_mode_combo)

        refresh = QPushButton("↻  تازه‌سازی")
        refresh.setObjectName("primaryButton")
        refresh.setToolTip("اسکن دوباره فولدر برای یافتن فیلم‌های جدید")
        refresh.clicked.connect(self.scan)

        toolbar.addWidget(self.search, 1)
        toolbar.addWidget(self.sort)
        toolbar.addWidget(self.apply_sort_button)
        toolbar.addWidget(self.preview_mode_combo)
        toolbar.addWidget(refresh)
        outer.addWidget(toolbar_panel)

        filterbar = QHBoxLayout()
        filterbar.setSpacing(8)
        self.rating_filter = NoWheelComboBox()
        self.rating_filter.addItems(['همه امتیازها', '★ ۵ به بالا', '★ ۱۰ به بالا', '★ ۱۵ به بالا', '★ ۲۰'])
        self.rating_filter.currentIndexChanged.connect(self.update_filters)
        self.quality_filter = NoWheelComboBox()
        self.quality_filter.addItems(['همه کیفیت‌ها', '1080p+', '4K+', 'زیر ۱ گیگابایت'])
        self.quality_filter.currentIndexChanged.connect(self.update_filters)
        self.extension_filter = NoWheelComboBox()
        self.extension_filter.addItems(['همه فرمت‌ها', 'MP4', 'MKV', 'AVI', 'MOV', 'WEBM'])
        self.extension_filter.currentIndexChanged.connect(self.update_filters)
        self.favorite_filter = QPushButton('♡  علاقه‌مندی‌ها')
        self.favorite_filter.setCheckable(True)
        self.favorite_filter.toggled.connect(self.update_filters)
        self.collection_filter = NoWheelComboBox()
        self.collection_filter.addItem('همه مجموعه‌ها', '')
        self.collection_filter.currentIndexChanged.connect(self.update_filters)
        for control in (self.rating_filter, self.quality_filter, self.extension_filter,
                        self.favorite_filter, self.collection_filter):
            filterbar.addWidget(control)
        filterbar.addStretch(1)
        outer.addLayout(filterbar)

        statrow = QHBoxLayout()
        self.library_info = QLabel("کتابخانه خالی است")
        self.library_info.setObjectName("statPill")
        self.selection_info = QLabel("")
        self.selection_info.setObjectName("selectionInfo")
        self.selection_info.hide()
        self.ram_info = QLabel("RAM Preview: 0 MB")
        self.ram_info.setObjectName("statPill")
        self.performance_info = QLabel('CPU/RAM —')
        self.performance_info.setObjectName('statPill')
        statrow.setSpacing(10)
        statrow.addWidget(self.library_info)
        statrow.addWidget(self.ram_info)
        statrow.addWidget(self.performance_info)
        statrow.addStretch(1)
        statrow.addWidget(self.selection_info)
        outer.addLayout(statrow)

        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setMaximumHeight(4)
        self.progress.setVisible(False)
        outer.addWidget(self.progress)

        self.view = SmartVideoView()
        self.delegate = VideoCardDelegate(self.view)
        self.view.setItemDelegate(self.delegate)
        self.view.setModel(self.proxy)
        self.view.set_card_width(int(cfg.get("card_width", 286)))
        self.delegate.set_card_width(int(cfg.get("card_width", 286)))
        self.view.hover_source_row_changed.connect(self.on_hover_row)
        self.view.visible_source_rows_changed.connect(self.on_visible_rows)
        self.view.scroll_state_changed.connect(self.on_scroll_state)
        self.view.selection_paths_changed.connect(self.on_selection_paths)
        self.view.rating_requested.connect(self.on_rating_requested)
        self.view.delete_requested.connect(self.delete_one_from_card)
        self.view.play_requested.connect(self.play_internal)
        self.view.setToolTip('کلیک روی کارت: پخش در پلیر تازه | Ctrl/Shift+Click: انتخاب')
        self.view.setContextMenuPolicy(Qt.CustomContextMenu)
        self.view.customContextMenuRequested.connect(self.show_context_menu)
        self.live_preview = SmoothHoverPreview(self.view, self.model, self.cfg)
        self.visible_live = VisibleLivePreviews(self.view, self.model, self.cfg)
        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("libraryContent")
        self.content_stack.addWidget(self.view)
        # Every activated movie receives its own native player window.
        # Keep explicit Python references until Qt close has completed.
        self._players = []
        self._max_players = 10
        empty = QFrame(objectName="emptyState")
        empty_layout = QVBoxLayout(empty)
        empty_layout.setContentsMargins(26, 28, 26, 28)
        empty_layout.setSpacing(11)
        empty_layout.addStretch(1)
        empty_symbol = QLabel("▣")
        empty_symbol.setObjectName("emptySymbol")
        empty_symbol.setAlignment(Qt.AlignCenter)
        self.empty_title = QLabel("کتابخانه شما آماده است")
        self.empty_title.setObjectName("emptyTitle")
        self.empty_title.setAlignment(Qt.AlignCenter)
        self.empty_description = QLabel("یک پوشه شامل فیلم انتخاب کنید تا پوسترها و پیش‌نمایش‌ها اینجا نمایش داده شوند.")
        self.empty_description.setObjectName("muted")
        self.empty_description.setAlignment(Qt.AlignCenter)
        self.empty_description.setWordWrap(True)
        choose_folder = QPushButton("انتخاب پوشه ویدئوها")
        choose_folder.setObjectName("primaryButton")
        choose_folder.clicked.connect(lambda _checked=False: self.manage_requested.emit())
        empty_layout.addWidget(empty_symbol)
        empty_layout.addWidget(self.empty_title)
        empty_layout.addWidget(self.empty_description)
        center_button_row = QHBoxLayout()
        center_button_row.addStretch(1)
        center_button_row.addWidget(choose_folder)
        center_button_row.addStretch(1)
        empty_layout.addLayout(center_button_row)
        empty_layout.addStretch(2)
        self.content_stack.addWidget(empty)
        self.content_stack.setCurrentIndex(1 if not cfg.get("folder") else 0)
        outer.addWidget(self.content_stack, 1)

        actions = QFrame(objectName="actionBar")
        al = QHBoxLayout(actions)
        al.setContentsMargins(14, 11, 14, 11)
        al.setSpacing(10)
        open_btn = QPushButton("▶  پخش داخل برنامه")
        open_btn.clicked.connect(self.open_selected)
        folder_btn = QPushButton("نمایش در پوشه")
        folder_btn.clicked.connect(self.show_in_explorer)
        trash_btn = QPushButton("انتقال به سطل بازیافت")
        trash_btn.setObjectName("softDangerButton")
        trash_btn.clicked.connect(self.trash_selected)
        delete_btn = QPushButton("حذف دائمی")
        delete_btn.setObjectName("dangerButton")
        delete_btn.clicked.connect(self.delete_selected_permanently)
        al.addWidget(open_btn)
        al.addWidget(folder_btn)
        details_btn = QPushButton('ⓘ  جزئیات')
        details_btn.clicked.connect(self.show_details)
        favorite_btn = QPushButton('♥  علاقه‌مندی')
        favorite_btn.clicked.connect(self.toggle_selected_favorites)
        collection_btn = QPushButton('⊞  مجموعه')
        collection_btn.clicked.connect(self.assign_collection)
        al.addWidget(details_btn)
        al.addWidget(favorite_btn)
        al.addWidget(collection_btn)
        batch_rating_btn = QPushButton('★  امتیاز گروهی')
        batch_rating_btn.clicked.connect(self.rate_selected)
        al.addWidget(batch_rating_btn)
        move_btn = QPushButton('↗  انتقال فیلم‌ها')
        move_btn.setToolTip('فیلم‌های انتخاب‌شده را همراه با ستاره، علاقه‌مندی و مجموعه‌ها منتقل می‌کند؛ نام تکراری بازنویسی نمی‌شود.')
        move_btn.clicked.connect(self.move_selected)
        al.addWidget(move_btn)
        self.move_button = move_btn
        self.batch_rating_button = batch_rating_btn
        self.details_button = details_btn
        self.favorite_button = favorite_btn
        self.collection_button = collection_btn
        self.open_button = open_btn
        self.explorer_button = folder_btn
        self.trash_button = trash_btn
        self.delete_button = delete_btn
        al.addStretch(1)
        al.addWidget(trash_btn)
        al.addWidget(delete_btn)
        outer.addWidget(actions)
        duplicates_btn = QPushButton('بررسی فایل‌های تکراری (SHA-256)')
        duplicates_btn.setToolTip('ابتدا حجم و نمونه فایل، سپس هش کامل مقایسه می‌شود؛ هیچ فایلی خودکار حذف نمی‌شود.')
        duplicates_btn.clicked.connect(self.find_duplicates)
        self.duplicates_button = duplicates_btn
        al.insertWidget(al.count() - 3, duplicates_btn)
        self._update_selection_actions()

    def _update_folder_chip(self):
        folders = library_folders(self.cfg)
        if not hasattr(self, 'folder_chip'):
            return
        title = Path(folders[0]).name if folders else 'پوشه‌ای انتخاب نشده'
        label = title if len(title) <= 28 else title[:25] + '…'
        if len(folders) > 1:
            label += f'   +{len(folders)-1}'
        self.folder_chip.setText('◉   ' + label)
        self.folder_chip.setToolTip('\n'.join(folders) if folders else 'از بخش مدیریت فولدرها را انتخاب کنید')

    def _update_selection_actions(self):
        number = len(self.selected_paths)
        self.open_button.setEnabled(number == 1)
        self.explorer_button.setEnabled(number == 1)
        self.trash_button.setEnabled(number > 0)
        self.delete_button.setEnabled(number > 0)
        self.favorite_button.setEnabled(number > 0)
        self.collection_button.setEnabled(number > 0)
        self.batch_rating_button.setEnabled(number > 0)
        self.details_button.setEnabled(number == 1)
        self.move_button.setEnabled(number > 0 and not self.move_busy)

    def _restore_path_selection(self, saved_paths):
        selection = self.view.selectionModel()
        if selection is None:
            return
        for path in saved_paths:
            row = self.model.row_for_path(path)
            if row < 0:
                continue
            idx = self.proxy.mapFromSource(self.model.index(row, 0))
            if idx.isValid():
                selection.select(idx, QItemSelectionModel.Select)

    def recount_without_web_sync(self):
        self.library_info.setText(f'{len(self.model.items)} فیلم  •  {human_size(sum(x.size for x in self.model.items))}')

    def _update_performance(self):
        if not self._ps_process:
            self.performance_info.setText('CPU/RAM: برای نمایش psutil نصب شود')
            return
        try:
            proc = self._ps_process
            children = proc.children(recursive=True)
            cpu = proc.cpu_percent(None)
            memory = proc.memory_info().rss
            current = set()
            for child in children:
                current.add(child.pid)
                try:
                    if child.pid not in self._ps_children:
                        self._ps_children[child.pid] = child
                        child.cpu_percent(None)
                    else:
                        child = self._ps_children[child.pid]
                        cpu += child.cpu_percent(None)
                    memory += child.memory_info().rss
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    self._ps_children.pop(child.pid, None)
            for pid in set(self._ps_children) - current:
                self._ps_children.pop(pid, None)
            # % of total machine capacity; can be >100% on multiple cores before normalization.
            cpu = cpu / max(1, os.cpu_count() or 1)
            self.performance_info.setText(f'CPU: {cpu:.0f}%  •  RAM: {human_size(memory)}')
        except Exception:
            self.performance_info.setText('CPU/RAM: در دسترس نیست')

    def _watch_scan(self):
        if self.cfg.get('watch_folders', True) and library_folders(self.cfg):
            self.scan(silent=True)

    def scan(self, silent=False):
        self._update_folder_chip()
        folders = [f for f in library_folders(self.cfg) if Path(f).is_dir()]
        if not folders:
            if not silent:
                QMessageBox.information(self, 'فولدر', 'ابتدا در مدیریت حداقل یک فولدر فیلم اضافه کنید.')
            return
        if self._scan_inflight:
            self._scan_repeat = True
            return
        self._scan_inflight = True
        self._scan_started_at = time.monotonic()
        if not silent:
            self.progress.setVisible(True)
            self.progress.setRange(0, 0)
            self.library_info.setText('در حال به‌روزرسانی کتابخانه…')
        self.scan_pool.start(ScanTask(folders, bool(self.cfg.get('recursive', True)),
                                      self.scan_bus, self.catalog))

    def on_scan_ready(self, rows):
        self._scan_inflight = False
        folders_in_scan = {str(Path(p).parent) for p, _, _, _ in rows}
        sidecar_stamps = []
        for folder in sorted(folders_in_scan):
            try:
                st = (Path(folder) / FOLDER_META_FILENAME).stat()
                sidecar_stamps.append((folder, st.st_mtime_ns, st.st_size))
            except OSError:
                sidecar_stamps.append((folder, 0, 0))
        files_fingerprint = tuple(sorted(((p, size, mtime) for p, _, size, mtime in rows),
                                         key=lambda part: os.path.normcase(part[0])))
        fingerprint = (files_fingerprint, tuple(sidecar_stamps))
        if fingerprint == self._last_scan_fingerprint:
            self.progress.setVisible(False)
            self.recount_without_web_sync()
            if self._scan_repeat:
                self._scan_repeat = False
                QTimer.singleShot(0, lambda: self.scan(silent=True))
            return
        # Rating/favorite/collection sidecars may change while the file listing
        # stays identical. Update those fields in-place; never reset the entire
        # model, disturb scroll, or restart every decoder for a metadata edit.
        if files_fingerprint == self._last_scan_files_fingerprint and self.model.items:
            folder_meta = {}
            for folder in folders_in_scan:
                data = _load_folder_metadata(Path(folder))
                folder_meta[folder] = {
                    key: {str(name).casefold(): value for name, value in data.get(key, {}).items()}
                    for key in ('ratings', 'favorites', 'collections')
                    if isinstance(data.get(key), dict)
                }
            fallback = self.cfg.get('ratings', {})
            for item in self.model.items:
                data = folder_meta.get(str(Path(item.path).parent), {})
                key = Path(item.path).name.casefold()
                rating = data.get('ratings', {}).get(key)
                if rating is None:
                    rating = fallback.get(rating_key(item.path), item.rating) if isinstance(fallback, dict) else item.rating
                    if not rating:
                        rating = rating_from_filename(item.name)
                try:
                    rating = max(0, min(MAX_RATING, int(rating)))
                except (TypeError, ValueError):
                    rating = item.rating
                self.model.set_rating(item.path, rating)
                self.model.set_favorite(item.path, bool(data.get('favorites', {}).get(key, False)))
                groups = data.get('collections', {}).get(key, [])
                groups = groups if isinstance(groups, list) else []
                if item.collections != groups:
                    self.model.set_collections(item.path, groups)
            self._last_scan_fingerprint = fingerprint
            self.progress.setVisible(False)
            self.recount_without_web_sync()
            self.web_sync_timer.start()
            if self._scan_repeat:
                self._scan_repeat = False
                QTimer.singleShot(0, lambda: self.scan(silent=True))
            return
        self._last_scan_fingerprint = fingerprint
        self._last_scan_files_fingerprint = files_fingerprint
        self.visible_live.stop()
        self.live_preview.stop()
        self.hover_path = None
        previously_selected = set(self.selected_paths)
        old_items = {x.path: x for x in self.model.items}
        cached = self.catalog.cached_metadata(rows)
        sidecars = {}
        for folder in folders_in_scan:
            metadata = _load_folder_metadata(Path(folder))
            sidecars[folder] = {
                field_name: {str(name).casefold(): value for name, value in metadata.get(field_name, {}).items()}
                for field_name in ('ratings', 'favorites', 'collections')
                if isinstance(metadata.get(field_name, {}), dict)
            }

        # v4.8+: ratings live beside the videos in each folder. The old absolute-path
        # config map is only used as a migration/fallback for pre-4.8 installations.
        ratings = self.cfg.get("ratings", {})
        if not isinstance(ratings, dict):
            ratings = {}
            self.cfg["ratings"] = ratings
        legacy_changed = False
        items = []
        for row in rows:
            item = VideoItem(*row)
            old = old_items.get(item.path)
            if old and old.size == item.size and old.mtime == item.mtime:
                item.poster = old.poster
                item.preview_frames = old.preview_frames
                item.preview_quality = old.preview_quality
                item.meta_ready = old.meta_ready
                item.duration, item.width, item.height = old.duration, old.width, old.height
            if item.path in cached:
                item.duration, item.width, item.height = cached[item.path]
                item.meta_ready = True
            folder_meta = sidecars.get(str(Path(item.path).parent), {})
            filename_key = Path(item.path).name.casefold()
            item.favorite = bool(folder_meta.get('favorites', {}).get(filename_key, False))
            collection_value = folder_meta.get('collections', {}).get(filename_key, [])
            item.collections = [c for c in collection_value if isinstance(c, str)] if isinstance(collection_value, list) else []
            local_value = folder_meta.get('ratings', {}).get(filename_key, None)
            if local_value is not None:
                try:
                    local_value = max(0, min(MAX_RATING, int(local_value)))
                except (TypeError, ValueError):
                    local_value = 0
            if local_value is not None:
                item.rating = local_value
            else:
                try:
                    key = rating_key(item.path)
                    legacy_value = max(0, min(MAX_RATING, int(ratings.get(key, 0))))
                except Exception:
                    key = rating_key(item.path)
                    legacy_value = 0
                if not legacy_value:
                    legacy_value = rating_from_filename(item.name)
                item.rating = legacy_value
                if legacy_value and write_local_rating(item.path, legacy_value):
                    ratings.pop(key, None)
                    legacy_changed = True
            items.append(item)
        if legacy_changed:
            save_config(self.cfg)
        # A background folder scan must not move the viewport unexpectedly.
        previous_scroll_anchor = self._capture_delete_anchor(set()) if self.model.items else None
        self.model.set_items(items)
        valid_paths = {x.path for x in items}
        self.loader.pending_meta.intersection_update(valid_paths)
        self.loader.pending_poster.intersection_update(valid_paths)
        self.loader.preview_lru = OrderedDict((p, stamp) for p, stamp in self.loader.preview_lru.items()
                                              if p in valid_paths and self.model.item_for_path(p)
                                              and self.model.item_for_path(p).preview_frames)
        self.loader.preview_memory = sum(self.loader._estimate_pixmaps(item.preview_frames)
                                         for item in self.model.items if item.preview_frames)
        for old_path in list(self.loader.preview_tokens):
            if old_path not in valid_paths:
                self.loader.cancel_preview(old_path)
                self.loader.preview_tokens.pop(old_path, None)
        self.selected_paths = [p for p in previously_selected if self.model.item_for_path(p)]
        self._update_selection_actions()
        self.refresh_collections()
        self.content_stack.setCurrentIndex(0 if items else 1)
        if not items:
            self.empty_title.setText("هنوز فیلمی پیدا نشده")
            self.empty_description.setText("این پوشه فایل ویدئویی ندارد. پوشه دیگری انتخاب کنید یا بعد از اضافه‌کردن فیلم تازه‌سازی بزنید.")
        total = sum(x.size for x in items)
        self.library_info.setText(f"{len(items)} فیلم  •  {human_size(total)}")
        self.progress.setVisible(False)
        self.proxy.set_sort_key(self.cfg.get("sort", "name"))
        # QAbstractItemModel reset drops Qt's selection state. Restore selected
        # files by stable path after sorting, not by their old visual row.
        if self.selected_paths:
            QTimer.singleShot(0, lambda saved=tuple(self.selected_paths): self._restore_path_selection(saved))
        if previous_scroll_anchor is not None:
            QTimer.singleShot(0, lambda anchor=previous_scroll_anchor: self._restore_delete_anchor(anchor))
        self.emit_library_changed()
        QTimer.singleShot(100, self.view.emit_visible_rows)
        if self._scan_repeat:
            self._scan_repeat = False
            QTimer.singleShot(0, lambda: self.scan(silent=True))

    def export_web_library(self):
        return [
            {
                "path": item.path,
                "name": item.name,
                "size": item.size,
                "mtime": item.mtime,
                "duration": item.duration,
                "width": item.width,
                "height": item.height,
                "rating": item.rating,
                "favorite": item.favorite,
            }
            for item in self.model.items
        ]

    def emit_library_changed(self):
        self.library_changed.emit(self.export_web_library())

    def _cache_metadata(self, path, duration, w, h):
        try:
            self.catalog.store_metadata(path, duration, w, h)
        except Exception:
            pass

    def on_model_data_changed(self, top_left, bottom_right, roles):
        if not roles or DURATION_ROLE in roles or RESOLUTION_ROLE in roles or META_READY_ROLE in roles or RATING_ROLE in roles:
            self.web_sync_timer.start()

    def on_scan_failed(self, err):
        self._scan_inflight = False
        self.progress.setVisible(False)
        self.library_info.setText("اسکن ناموفق بود")
        self.empty_title.setText("اسکن کتابخانه ناموفق بود")
        self.empty_description.setText("پوشه انتخابی را بررسی کرده و دوباره تلاش کنید.")
        if not self.model.items:
            self.content_stack.setCurrentIndex(1)
        QMessageBox.warning(self, 'خطای اسکن', err)

    def apply_settings(self, cfg):
        self.cfg = cfg
        self.loader.update_settings(cfg)
        if hasattr(self, "live_preview"):
            self.live_preview.update_settings(cfg)
        if hasattr(self, "visible_live"):
            self.visible_live.update_settings(cfg)
        width = int(cfg.get("card_width", 286))
        self.delegate.set_card_width(width)
        self.view.set_card_width(width)

        mode = cfg.get("preview_mode", "hover")
        combo_index = {"hover": 0, "visible": 1, "off": 2}.get(mode, 0)
        self.preview_mode_combo.blockSignals(True)
        self.preview_mode_combo.setCurrentIndex(combo_index)
        self.preview_mode_combo.blockSignals(False)

        if self.has_open_players():
            self.stop_all_previews()
            return
        if mode == "off":
            self.stop_all_previews()
        elif mode == "hover":
            self.visible_live.stop()
            if self.hover_path:
                self.activate_hover(self.hover_path)
        elif mode == "visible":
            self.live_preview.stop()
            self.on_visible_rows([
                self.model.row_for_path(p) for p in self.visible_paths
                if self.model.row_for_path(p) >= 0
            ])

    def update_filters(self, *args):
        self.proxy.filter_rating = [0, 5, 10, 15, 20][self.rating_filter.currentIndex()]
        self.proxy.filter_quality = ['all', 'fhd', '4k', 'small'][self.quality_filter.currentIndex()]
        self.proxy.filter_extension = ['all', '.mp4', '.mkv', '.avi', '.mov', '.webm'][self.extension_filter.currentIndex()]
        self.proxy.filter_favorites = self.favorite_filter.isChecked()
        self.proxy.filter_collection = self.collection_filter.currentData() or ''
        self.proxy.invalidateFilter()
        QTimer.singleShot(70, self.view.emit_visible_rows)

    def refresh_collections(self):
        current = self.collection_filter.currentData()
        names = sorted({tag for item in self.model.items for tag in item.collections}, key=str.casefold)
        self.collection_filter.blockSignals(True)
        self.collection_filter.clear()
        self.collection_filter.addItem('همه مجموعه‌ها', '')
        for name in names:
            self.collection_filter.addItem(name, name)
        for i in range(self.collection_filter.count()):
            if self.collection_filter.itemData(i) == current:
                self.collection_filter.setCurrentIndex(i)
                break
        self.collection_filter.blockSignals(False)

    def rate_selected(self):
        if not self.selected_paths:
            return
        from PySide6.QtWidgets import QInputDialog
        value, ok = QInputDialog.getInt(self, 'امتیاز گروهی',
            f'امتیاز {len(self.selected_paths)} فیلم از ۰ تا ۲۰:', 10, 0, MAX_RATING)
        if not ok:
            return
        fallback = self.cfg.setdefault('ratings', {})
        if not isinstance(fallback, dict):
            fallback = {}
            self.cfg['ratings'] = fallback
        errors = []
        self.stop_all_previews()
        for path in self.selected_paths:
            if write_local_rating(path, value):
                fallback.pop(rating_key(path), None)
                self.model.set_rating(path, value)
                self._pending_rating_renames[path] = value
            else:
                fallback[rating_key(path)] = value
                self.model.set_rating(path, value)
                errors.append(Path(path).name)
        save_config(self.cfg)
        if self._pending_rating_renames:
            self._rating_rename_timer.start(450)
        self._mark_rating_sort_dirty()
        if errors:
            QMessageBox.information(self, 'ذخیره امتیاز',
                f'برای {len(errors)} فایل، فقط نسخه پشتیبان امتیاز در تنظیمات برنامه ذخیره شد.')

    def toggle_selected_favorites(self):
        items = [self.model.item_for_path(p) for p in self.selected_paths]
        items = [x for x in items if x]
        if not items:
            return
        desired = not all(x.favorite for x in items)
        failed = []
        for item in items:
            if _write_portable_field(item.path, 'favorites', bool(desired)):
                self.model.set_favorite(item.path, desired)
            else:
                failed.append(item.name)
        self.proxy.invalidateFilter()
        self._last_scan_fingerprint = None
        if failed:
            QMessageBox.warning(self, 'ذخیره نشد', 'نوشتن در این فولدرها مجاز نیست:\n' + '\n'.join(failed[:8]))

    def assign_collection(self):
        if not self.selected_paths:
            return
        from PySide6.QtWidgets import QInputDialog
        name, accepted = QInputDialog.getText(self, 'مجموعه', 'نام مجموعه را وارد کنید (خالی = حذف از همه مجموعه‌ها):')
        if not accepted:
            return
        name = name.strip()[:70]
        failures = []
        for path in self.selected_paths:
            item = self.model.item_for_path(path)
            if item is None:
                continue
            values = list(item.collections)
            if name and name not in values:
                values.append(name)
            if not name:
                values = []
            if _write_portable_field(path, 'collections', values):
                self.model.set_collections(path, values)
            else:
                failures.append(item.name)
        self.refresh_collections()
        self.update_filters()
        self._last_scan_fingerprint = None
        if failures:
            QMessageBox.warning(self, 'مجموعه', 'ذخیره اطلاعات بعضی فایل‌ها ممکن نبود.')

    def show_details(self):
        if len(self.selected_paths) != 1:
            return
        item = self.model.item_for_path(self.selected_paths[0])
        if not item:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('جزئیات و Timeline فیلم')
        dialog.resize(680, 660)
        layout = QVBoxLayout(dialog)
        title = QLabel(item.name)
        title.setWordWrap(True)
        title.setObjectName('sectionLabel')
        layout.addWidget(title)
        lines = [
            ('مسیر', item.path), ('حجم', human_size(item.size)),
            ('مدت', human_duration(item.duration) if item.meta_ready else 'در حال استخراج'),
            ('رزولوشن', item.resolution or 'نامشخص'),
            ('فرمت', Path(item.path).suffix.upper()), ('امتیاز', f'{item.rating} / {MAX_RATING}'),
            ('علاقه‌مندی', 'بله' if item.favorite else 'خیر'),
            ('مجموعه‌ها', ', '.join(item.collections) or '—'),
        ]
        for key, value in lines:
            label = QLabel(f'{key}:  {value}')
            label.setWordWrap(True)
            label.setTextInteractionFlags(Qt.TextSelectableByMouse)
            layout.addWidget(label)
        technical_label = QLabel('در حال خواندن Codec، FPS و Bitrate…')
        technical_label.setObjectName('muted')
        technical_label.setWordWrap(True)
        technical_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(technical_label)
        self._technical_request_id += 1
        technical_id = self._technical_request_id
        self._technical_target = (dialog, technical_label, technical_id)
        self.timeline_pool.start(TechnicalTask(technical_id, item.path, self.technical_bus))
        layout.addWidget(QLabel('Timeline — نقطه دلخواه را انتخاب و لغزنده را رها کنید:'))
        thumbnail = QLabel('در حال دریافت فریم…')
        thumbnail.setMinimumHeight(200)
        thumbnail.setAlignment(Qt.AlignCenter)
        thumbnail.setObjectName('timelineThumb')
        layout.addWidget(thumbnail)
        slider = NoWheelSlider(Qt.Horizontal)
        slider.setRange(0, max(1, int(item.duration or 1) * 10))
        slider.setEnabled(item.duration > 0)
        layout.addWidget(slider)
        position_text = QLabel('00:00')
        layout.addWidget(position_text)
        def seek_frame():
            self._timeline_request_id += 1
            request_id = self._timeline_request_id
            self._timeline_target = (dialog, thumbnail, request_id)
            position = slider.value() / 10.0
            position_text.setText(human_duration(position))
            thumbnail.setText('در حال دریافت فریم…')
            self.timeline_pool.start(TimelineFrameTask(request_id, item.path, position, self.timeline_bus))

        slider.valueChanged.connect(lambda v: position_text.setText(human_duration(v / 10.0)))
        slider.sliderReleased.connect(seek_frame)
        close = QPushButton('بستن')
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        QTimer.singleShot(0, seek_frame)
        dialog.exec()
        self._timeline_target = None
        self._technical_target = None

    def _display_technical_info(self, request_id, info):
        target = self._technical_target
        if target and target[2] == request_id and target[0].isVisible():
            target[1].setText(info)

    def _display_timeline_frame(self, request_id, jpeg):
        target = self._timeline_target
        if not target or request_id != target[2]:
            return
        dialog, thumbnail, _ = target
        if not dialog.isVisible():
            return
        pm = QPixmap()
        if pm.loadFromData(jpeg):
            thumbnail.setPixmap(pm.scaled(520, 292, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def find_duplicates(self):
        if self.duplicates_running:
            return
        paths = [item.path for item in self.model.items]
        if len(paths) < 2:
            return
        self.duplicates_running = True
        self.duplicates_button.setEnabled(False)
        self.duplicates_button.setText('در حال بررسی SHA-256…')
        self.scan_pool.start(DuplicateTask(paths, self.duplicate_bus))

    def _duplicates_failed(self, message):
        self.duplicates_running = False
        self.duplicates_button.setEnabled(True)
        self.duplicates_button.setText('بررسی فایل‌های تکراری (SHA-256)')
        QMessageBox.warning(self, 'بررسی فایل‌ها', message)

    def _duplicates_ready(self, groups):
        self.duplicates_running = False
        self.duplicates_button.setEnabled(True)
        self.duplicates_button.setText('بررسی فایل‌های تکراری (SHA-256)')
        if not groups:
            QMessageBox.information(self, 'فایل‌های تکراری', 'هیچ فایل کاملاً یکسانی پیدا نشد.')
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('فایل‌های واقعاً یکسان — SHA-256 کامل')
        dialog.resize(790, 460)
        layout = QVBoxLayout(dialog)
        label = QLabel(f'{len(groups)} گروه فایل تکراری پیدا شد. حذف خودکار انجام نمی‌شود.')
        layout.addWidget(label)
        listing = QListWidget()
        for n, group in enumerate(groups, 1):
            listing.addItem(f'گروه {n} — {len(group)} فایل')
            for path in group:
                listing.addItem('   ' + path)
        layout.addWidget(listing)
        close = QPushButton('بستن')
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.exec()

    def on_search(self, text):
        self.proxy.set_filter_text(text)
        QTimer.singleShot(80, self.view.emit_visible_rows)

    def on_sort(self, idx):
        key = ["name", "rating", "size", "duration", "date"][idx]
        self.cfg["sort"] = key
        save_config(self.cfg)
        self.proxy.set_sort_key(key, refresh_rating=True)
        self._rating_sort_dirty = False
        self.apply_sort_button.setVisible(False)
        QTimer.singleShot(80, self.view.emit_visible_rows)

    def _mark_rating_sort_dirty(self):
        if self.cfg.get('sort') == 'rating':
            self._rating_sort_dirty = True
            self.apply_sort_button.setVisible(True)

    def apply_rating_sort(self):
        if self.cfg.get('sort') != 'rating':
            return
        self.proxy.apply_rating_order()
        self._rating_sort_dirty = False
        self.apply_sort_button.setVisible(False)
        QTimer.singleShot(60, self.view.emit_visible_rows)

    def on_rating_requested(self, path: str, rating: int):
        value = max(0, min(MAX_RATING, int(rating)))
        self.model.set_rating(path, value)

        # Portable source of truth: save inside the video's own folder. If that
        # folder is read-only, keep the legacy config entry as a safe fallback.
        ratings = self.cfg.setdefault("ratings", {})
        if not isinstance(ratings, dict):
            ratings = {}
            self.cfg["ratings"] = ratings
        key = rating_key(path)
        if write_local_rating(path, value):
            ratings.pop(key, None)
            # A slight debounce permits FFmpeg to release its Windows file
            # handle before we rename; rapid clicks keep only the last rating.
            self.stop_all_previews()
            self._pending_rating_renames[path] = value
            self._rating_rename_timer.start(450)
        elif value:
            ratings[key] = value
        else:
            ratings.pop(key, None)
        save_config(self.cfg)
        self._mark_rating_sort_dirty()
        # Sorting waits for an explicit click, even when the selected key is ★.
        # Sidecar changes are merged in place on the next scan.
        # Filter changes are deferred too; never hide or move a card mid-click.
        self.web_sync_timer.start()

    def _flush_rating_renames(self):
        """Apply a bounded number of real filesystem renames per UI tick.

        We never reset the model when a video is renamed. A stale/locked file
        remains rated in the portable JSON, with an explicit rename error.
        """
        if self._scan_inflight:
            self._rating_rename_timer.start(350)
            return
        batch = list(self._pending_rating_renames.items())[:8]
        needs_retry_wait = False
        for path, value in batch:
            self._pending_rating_renames.pop(path, None)
            item = self.model.item_for_path(path)
            if item is None:
                continue
            if Path(path).name == rated_filename(Path(path).name, value):
                continue
            if self.is_file_playing(path):
                self._pending_rating_renames[path] = value
                needs_retry_wait = True
                continue
            try:
                new_path = rename_video_for_rating(path, value)
            except PermissionError as exc:
                # On Windows, FFmpeg may briefly retain a sharing lock even
                # after its cancel signal. Retry, do not lose the rating.
                attempts = self._rating_rename_attempts.get(path, 0) + 1
                if attempts <= 3:
                    self._rating_rename_attempts[path] = attempts
                    self._pending_rating_renames[path] = value
                    needs_retry_wait = True
                else:
                    self._rename_errors.append(f'{Path(path).name}: {exc}')
                    self._rating_rename_attempts.pop(path, None)
                continue
            except (OSError, ValueError, RuntimeError) as exc:
                self._rename_errors.append(f'{Path(path).name}: {exc}')
                self._rating_rename_attempts.pop(path, None)
                continue
            self._rating_rename_attempts.pop(path, None)

            self.proxy.remap_path(path, new_path)
            self.model.rename_item_path(path, new_path)
            self.selected_paths = [new_path if p == path else p for p in self.selected_paths]
            if self.hover_path == path:
                self.hover_path = new_path
            if path in self.visible_paths:
                self.visible_paths.discard(path)
                self.visible_paths.add(new_path)
            for attr in ('_star_hover_path', '_delete_hover_path'):
                if getattr(self.view, attr, None) == path:
                    setattr(self.view, attr, new_path)
            try:
                self.catalog.remove([path])
                if item.meta_ready:
                    self.catalog.store_metadata(new_path, item.duration, item.width, item.height)
            except Exception:
                pass
            fallback = self.cfg.get('ratings', {})
            if isinstance(fallback, dict):
                fallback.pop(rating_key(path), None)

            # Prevent the next passive folder scan from treating our own
            # filename change as unrelated items requiring a full rebuild.
            if self._last_scan_files_fingerprint:
                self._last_scan_files_fingerprint = tuple(sorted(
                    ((new_path if p == path else p, size, mtime)
                     for p, size, mtime in self._last_scan_files_fingerprint),
                    key=lambda part: os.path.normcase(part[0])))
            self._last_scan_fingerprint = None

        if self._pending_rating_renames:
            self._rating_rename_timer.start(550 if needs_retry_wait else 20)
            return
        save_config(self.cfg)
        self.web_sync_timer.start()
        QTimer.singleShot(90, self.view.emit_visible_rows)
        QTimer.singleShot(110, self.view.refresh_hover_from_cursor)
        if self._rename_errors:
            errors = self._rename_errors[:6]
            count = len(self._rename_errors)
            self._rename_errors = []
            QMessageBox.warning(self, 'تغییر نام برخی فیلم‌ها انجام نشد',
                f'{count} فایل تغییر نام پیدا نکرد؛ امتیازهایشان ذخیره شده است.\n\n' + '\n'.join(errors))

    def on_preview_mode_combo(self, idx):
        mode = self.preview_mode_combo.itemData(idx)
        self.cfg["preview_mode"] = mode
        save_config(self.cfg)
        if self.has_open_players():
            self.stop_all_previews()
            return
        if mode == "off":
            self.stop_all_previews()
        elif mode == "hover":
            self.visible_live.stop()
            if self.hover_path:
                self.activate_hover(self.hover_path)
        elif mode == "visible":
            self.live_preview.stop()
            self.loader.cancel_all_previews_except(set())
            self.view.emit_visible_rows()

    def on_scroll_state(self, moving: bool):
        if self.has_open_players():
            self.stop_all_previews()
            return
        if moving:
            self.visible_live.set_scrolling(True)
            self.live_preview.stop()
        else:
            self.visible_live.set_scrolling(False)
            self.view.emit_visible_rows()  # replace stale paths BEFORE starting decoders
            self.view.refresh_hover_from_cursor()
            if (self.cfg.get('preview_mode') == 'hover' and self.hover_path
                    and not self.live_preview.is_active()
                    and not self.has_open_players()):
                self.activate_hover(self.hover_path)

    def on_visible_rows(self, source_rows):
        if self.view._scrolling or self.has_open_players():
            return
        # Debounced viewport callbacks may arrive *after* the tab is hidden.
        # Never relaunch background FFmpeg decoders for an invisible library.
        if not self.isVisible():
            self.visible_live.stop()
            return
        paths = []
        visible_now = []
        viewport_rect = self.view.viewport().rect()
        proxy = self.view.model()
        for row in source_rows:
            if not (0 <= row < len(self.model.items)):
                continue
            item = self.model.items[row]
            paths.append(item.path)
            self.loader.request_poster(item.path, priority=1)
            self.loader.request_metadata(item.path, priority=0)
            # Prefetch margins are for posters, not continuously decoding
            # videos whose cards are not currently in the viewport.
            if proxy is not None:
                ix = proxy.mapFromSource(self.model.index(row, 0))
                if ix.isValid() and self.view.visualRect(ix).intersects(viewport_rect):
                    visible_now.append(item.path)

        self.visible_paths = set(paths)
        mode = self.cfg.get('preview_mode', 'hover')
        if mode == 'visible':
            self.live_preview.stop()
            self.loader.cancel_all_previews_except(set())
            self.visible_live.set_visible(visible_now)
            self.visible_live.set_hover(self.hover_path)
        else:
            self.visible_live.stop()
            self.live_preview.reposition()
            self.loader.trim_for_active(({self.hover_path} if self.hover_path else set()))

    def on_hover_row(self, row):
        old = self.hover_path
        item = self.model.items[row] if 0 <= row < len(self.model.items) else None
        new = item.path if item else None
        if old and old != new:
            self.loader.cancel_preview(old)
        self.hover_path = new
        if self.has_open_players():
            self.stop_all_previews()
            return
        mode = self.cfg.get('preview_mode', 'hover')
        if mode == 'hover' and new and not self.view._scrolling and not self.has_open_players():
            self.activate_hover(new)
        elif mode == 'visible':
            # Prioritize the pointed-to card without launching a second
            # decoder over the same card; it already has a live stream.
            self.live_preview.stop()
            self.visible_live.set_hover(new)
        else:
            self.live_preview.stop()

    def activate_hover(self, path):
        self.loader.request_poster(path, priority=20)
        self.loader.request_metadata(path, priority=20)
        item = self.model.item_for_path(path)
        duration = item.duration if item else 0.0
        self.live_preview.start(path, duration)

    def stop_all_previews(self):
        self.visible_live.stop()
        self.live_preview.stop()
        self.loader.cancel_all_previews_except(set())
        # Only currently visible cards can still be marked as playing.
        for path in self.visible_paths:
            self.model.set_preview_active(path, False)

    def advance_animations(self):
        mode = self.cfg.get('preview_mode', 'hover')
        if mode == 'visible':
            count, processes, candidates = self.visible_live.stats()
            self.ram_info.setText(
                f'Live: {count}/{candidates}  •  FFmpeg: {processes}  •  '
                f'RAM: {human_size(self.loader.preview_memory)}')
        elif mode == 'hover' and self.live_preview.is_active():
            elapsed = max(0.1, time.monotonic() - self.live_preview.preview_started)
            fps = self.live_preview.presented_frames / elapsed
            self.ram_info.setText(
                f'Hover: {fps:.0f}/{self.live_preview._fps()} FPS  •  '
                f'FFmpeg: {len(self.live_preview._worker_processes)}  •  '
                f'RAM: {human_size(self.loader.preview_memory)}')
        else:
            self.ram_info.setText(f'RAM Preview: {human_size(self.loader.preview_memory)}')

    def hideEvent(self, event):
        # Do not decode an invisible tab in the background.
        if hasattr(self, 'visible_live'):
            self.visible_live.stop()
            self.live_preview.stop()
        super().hideEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        if hasattr(self, 'view'):
            QTimer.singleShot(120, self.view.emit_visible_rows)

    def on_selection_paths(self, paths):
        self.selected_paths = paths
        total = 0
        for p in paths:
            item = self.model.item_for_path(p)
            if item:
                total += item.size
        self.selection_info.setText(f"{len(paths)} انتخاب  •  {human_size(total)}" if paths else "")
        self.selection_info.setVisible(bool(paths))
        self._update_selection_actions()

    def has_open_players(self):
        return bool(self._players)

    def is_file_playing(self, path):
        return any(player.path == path for player in self._players)

    def play_internal(self, path: str):
        if not path or not Path(path).is_file():
            QMessageBox.warning(self, 'فایل پیدا نشد', 'ویدئو در این مسیر موجود نیست.')
            return
        if len(self._players) >= self._max_players:
            QMessageBox.information(self, 'محدودیت پلیرها',
                f'حداکثر {self._max_players} پلیر هم‌زمان مجاز است. یکی را ببند و دوباره امتحان کن.')
            return
        # All player windows get priority over automatic card decoding.
        self.stop_all_previews()
        player = InternalVideoPlayer(self.cfg, self)
        player.back_requested.connect(lambda p=player: self.close_internal_player(p))
        self._players.append(player)
        player.open_file(path)
        # Stagger newly opened windows so another player isn't hidden beneath it.
        if len(self._players) > 1:
            bounds = player._screen_rect()
            offset = (len(self._players) - 1) * 32
            player.move(max(bounds.x(), min(bounds.right() - player.width() + 1, player.x() + offset)),
                        max(bounds.y(), min(bounds.bottom() - player.height() + 1, player.y() + offset)))

    def close_internal_player(self, player=None):
        if player is None:
            return
        if player in self._players:
            self._players.remove(player)
        # closeEvent already stopped multimedia before this callback; schedule
        # destruction after closeEvent unwinds to avoid a deleted C++ QWidget.
        QTimer.singleShot(0, player.deleteLater)
        if self._pending_rating_renames:
            self._rating_rename_timer.start(80)
        if self._players:
            return  # still decoding other windows: never resume card previews
        self.content_stack.setCurrentIndex(0 if self.model.items else 1)
        self.view.refresh_hover_from_cursor()
        if (self.cfg.get('preview_mode') == 'hover' and self.hover_path
                and not self.live_preview.is_active() and not self.view._scrolling):
            self.activate_hover(self.hover_path)
        QTimer.singleShot(120, self.view.emit_visible_rows)

    def shutdown_players(self):
        for player in list(self._players):
            player.shutdown()
            player.deleteLater()
        self._players.clear()

    def open_index(self, proxy_index):
        if not proxy_index.isValid():
            return
        src = self.proxy.mapToSource(proxy_index)
        self.play_internal(src.data(PATH_ROLE))

    def open_selected(self):
        if len(self.selected_paths) != 1:
            QMessageBox.information(self, "پخش", "برای پخش دقیقاً یک فیلم را انتخاب کنید.")
            return
        self.play_internal(self.selected_paths[0])

    def show_in_explorer(self):
        if len(self.selected_paths) != 1:
            QMessageBox.information(self, "Explorer", "برای نمایش در Explorer دقیقاً یک فیلم را انتخاب کنید.")
            return
        path = self.selected_paths[0]
        if os.name == "nt" and Path(path).exists():
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])

    def show_context_menu(self, pos):
        idx = self.view.indexAt(pos)
        if not idx.isValid():
            return
        if idx not in self.view.selectionModel().selectedIndexes():
            self.view.selectionModel().clearSelection()
            self.view.selectionModel().select(idx, QItemSelectionModel.Select)
            self.view.setCurrentIndex(idx)

        menu = QMenu(self)
        a_open = menu.addAction("▶ پخش داخل VideoShelf")
        a_external = menu.addAction("باز کردن با پلیر ویندوز")
        a_folder = menu.addAction("نمایش در Explorer")
        a_details = menu.addAction('جزئیات و اطلاعات فنی')
        a_favorite = menu.addAction('حذف از علاقه‌مندی' if idx.data(FAVORITE_ROLE) else 'افزودن به علاقه‌مندی')
        a_collection = menu.addAction('افزودن به مجموعه…')
        menu.addSeparator()
        a_trash = menu.addAction("انتقال به Recycle Bin")
        a_delete = menu.addAction("حذف دائمی")
        action = menu.exec(self.view.viewport().mapToGlobal(pos))
        if action == a_open:
            self.open_selected()
        elif action == a_external:
            path = idx.data(PATH_ROLE)
            if path and Path(path).is_file():
                if os.name == 'nt':
                    os.startfile(path)
                else:
                    subprocess.Popen(['xdg-open', path])
        elif action == a_folder:
            self.show_in_explorer()
        elif action == a_details:
            self.show_details()
        elif action == a_favorite:
            self.toggle_selected_favorites()
        elif action == a_collection:
            self.assign_collection()
        elif action == a_trash:
            self.trash_selected()
        elif action == a_delete:
            self.delete_selected_permanently()

    def _capture_delete_anchor(self, deleting_paths):
        """Preserve scroll position without scanning every library item.

        QListView can manage tens of thousands of indices, so only sample
        actual viewport cells; visualRect() across the full model is costly.
        """
        deleting = set(deleting_paths or [])
        viewport = self.view.viewport().rect()
        grid = self.view.gridSize()
        dx = max(32, int(grid.width()) or 280)
        dy = max(32, int(grid.height()) or 260)
        best = None
        for y in range(min(dy // 2, max(1, viewport.height() - 1)), max(2, viewport.height()), dy):
            for x in range(min(dx // 2, max(1, viewport.width() - 1)), max(2, viewport.width()), dx):
                idx = self.view.indexAt(QPoint(x, y))
                if not idx.isValid():
                    continue
                rect = self.view.visualRect(idx)
                if not rect.isValid() or not rect.intersects(viewport):
                    continue
                path = idx.data(PATH_ROLE)
                if path in deleting:
                    continue
                score = abs(rect.top())
                if best is None or score < best[0]:
                    best = (score, path, rect.top())
        scroll = self.view.verticalScrollBar().value()
        return (best[1], best[2], scroll) if best else (None, 0, scroll)

    def _restore_delete_anchor(self, anchor):
        path, old_top, old_scroll = anchor
        if path:
            row = self.model.row_for_path(path)
            if row >= 0:
                src = self.model.index(row, 0)
                idx = self.proxy.mapFromSource(src)
                if idx.isValid():
                    self.view.scrollTo(idx, QAbstractItemView.PositionAtTop)
                    def fine_tune():
                        rect = self.view.visualRect(idx)
                        if rect.isValid():
                            bar = self.view.verticalScrollBar()
                            bar.setValue(bar.value() + rect.top() - old_top)
                    QTimer.singleShot(0, fine_tune)
                    return
        QTimer.singleShot(0, lambda: self.view.verticalScrollBar().setValue(old_scroll))

    def _forget_rating_for_path(self, path: str):
        clear_portable_video_metadata(path)
        try:
            self.catalog.remove([path])
        except Exception:
            pass
        ratings = self.cfg.get("ratings", {})
        if isinstance(ratings, dict):
            ratings.pop(rating_key(path), None)
            save_config(self.cfg)

    def move_selected(self):
        if self.move_busy or not self.selected_paths:
            return
        directory = QFileDialog.getExistingDirectory(self, 'انتقال فیلم‌ها به پوشه', str(Path.home()))
        if not directory:
            return
        files = list(self.selected_paths)
        ans = QMessageBox.question(
            self, 'تأیید انتقال',
            f'{len(files)} فیلم به پوشه انتخاب‌شده منتقل شود؟\n'
            'امتیازها، علاقه‌مندی‌ها و مجموعه‌ها نیز منتقل می‌شوند.\n'
            'اگر نامی تکراری باشد، فایل مقصد بازنویسی نمی‌شود.',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if ans != QMessageBox.Yes:
            return
        self.move_busy = True
        self.stop_all_previews()
        self.view.setEnabled(False)
        self._update_selection_actions()
        self.library_info.setText(f'در حال انتقال {len(files)} فیلم…')
        self.move_pool.start(MoveTask(files, directory, self.move_bus))

    def _move_finished(self, moved, failed):
        self.move_busy = False
        self.view.setEnabled(True)
        if moved:
            originals = [old for old, new in moved]
            self.catalog.remove(originals)
            self.model.remove_paths(originals)
            self.selected_paths = []
            self._last_scan_fingerprint = None
        self._update_selection_actions()
        self.recount()
        self.scan(silent=True)
        if failed:
            QMessageBox.warning(self, 'بخشی از انتقال ناموفق بود', '\n'.join(failed[:15]))
        elif moved:
            QMessageBox.information(self, 'انتقال تکمیل شد', f'{len(moved)} فیلم با متادیتا منتقل شد.')

    def delete_one_from_card(self, path: str):
        item = self.model.item_for_path(path)
        if not item or not Path(path).exists():
            return
        ans = QMessageBox.question(
            self, "حذف فایل",
            f"«{Path(path).name}» به Recycle Bin منتقل شود؟\n\nدر صورت نیاز می‌توانید آن را از Recycle Bin برگردانید.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if ans != QMessageBox.Yes:
            return

        anchor = self._capture_delete_anchor([path])
        try:
            send2trash(path)
            self._forget_rating_for_path(path)
            self.model.remove_paths([path])
            self.selected_paths = [p for p in self.selected_paths if p != path]
            self.on_selection_paths(self.selected_paths)
            self.recount()
            self._restore_delete_anchor(anchor)
        except Exception as e:
            QMessageBox.warning(self, "حذف انجام نشد", f"{Path(path).name}: {e}")

    def trash_selected(self):
        paths = list(self.selected_paths)
        if not paths:
            return
        total = sum((self.model.item_for_path(p).size if self.model.item_for_path(p) else 0) for p in paths)
        ans = QMessageBox.question(
            self, "انتقال به Recycle Bin",
            f"{len(paths)} فیلم با حجم {human_size(total)} به Recycle Bin منتقل شود؟",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if ans != QMessageBox.Yes:
            return

        anchor = self._capture_delete_anchor(paths)
        success, failed = [], []
        for path in paths:
            try:
                send2trash(path)
                self._forget_rating_for_path(path)
                success.append(path)
            except Exception as e:
                failed.append(f"{Path(path).name}: {e}")
        if success:
            self.model.remove_paths(success)
            self.selected_paths = []
            self.selection_info.clear()
            self.selection_info.hide()
            self._update_selection_actions()
            self.recount()
            self._restore_delete_anchor(anchor)
        if failed:
            QMessageBox.warning(self, "بعضی فایل‌ها حذف نشدند", "\n".join(failed[:10]))

    def delete_selected_permanently(self):
        paths = list(self.selected_paths)
        if not paths:
            return
        total = sum((self.model.item_for_path(p).size if self.model.item_for_path(p) else 0) for p in paths)
        ans = QMessageBox.warning(
            self, "حذف دائمی",
            f"{len(paths)} فیلم با حجم {human_size(total)} برای همیشه حذف شوند؟\nاین عملیات قابل برگشت نیست.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if ans != QMessageBox.Yes:
            return

        anchor = self._capture_delete_anchor(paths)
        success, failed = [], []
        for path in paths:
            try:
                Path(path).unlink()
                self._forget_rating_for_path(path)
                success.append(path)
            except Exception as e:
                failed.append(f"{Path(path).name}: {e}")
        if success:
            self.model.remove_paths(success)
            self.selected_paths = []
            self.selection_info.clear()
            self.selection_info.hide()
            self._update_selection_actions()
            self.recount()
            self._restore_delete_anchor(anchor)
        if failed:
            QMessageBox.warning(self, "بعضی فایل‌ها حذف نشدند", "\n".join(failed[:10]))

    def recount(self):
        total = sum(x.size for x in self.model.items)
        self.library_info.setText(f"{len(self.model.items)} فیلم  •  {human_size(total)}")
        self.emit_library_changed()
        QTimer.singleShot(80, self.view.emit_visible_rows)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.setWindowTitle("VideoShelf  •  Video Library")
        self.resize(1400, 900)
        self.setMinimumSize(1000, 680)

        self.cloud_share = CloudShareManager(ROOT, ffmpeg_path(), self)

        self.tabs = QTabWidget()
        self.management = ManagementTab(self.cfg)
        self.library = LibraryTab(self.cfg)
        self.tabs.addTab(self.management, "تنظیمات و مدیریت")
        self.tabs.addTab(self.library, "کتابخانه")
        self.tabs.setDocumentMode(True)
        self.tabs.setCurrentIndex(1)
        self.library.manage_requested.connect(self.management.pick_folder)

        shell = QWidget(objectName="appShell")
        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)
        header = QFrame(objectName="appHeader")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(27, 13, 27, 13)
        header_layout.setSpacing(13)
        brand_mark = QLabel("V")
        brand_mark.setObjectName("brandMark")
        brand_mark.setAlignment(Qt.AlignCenter)
        brand_mark.setFixedSize(44, 44)
        brand_stack = QVBoxLayout()
        brand_stack.setSpacing(1)
        brand_name = QLabel("VideoShelf")
        brand_name.setObjectName("brandName")
        brand_description = QLabel("فضای شخصی فیلم‌های شما")
        brand_description.setObjectName("brandDescription")
        brand_stack.addWidget(brand_name)
        brand_stack.addWidget(brand_description)
        header_layout.addWidget(brand_mark)
        header_layout.addLayout(brand_stack)
        header_layout.addStretch(1)
        local_badge = QLabel("●   LOCAL LIBRARY")
        local_badge.setObjectName("headerBadge")
        header_layout.addWidget(local_badge)
        version_badge = QLabel('v6.1.3')
        version_badge.setObjectName("headerVersion")
        header_layout.addWidget(version_badge)
        shell_layout.addWidget(header)
        shell_layout.addWidget(self.tabs, 1)
        self.setCentralWidget(shell)

        self.management.folder_changed.connect(self.on_folder_changed)
        self.management.settings_changed.connect(self.on_settings_changed)
        self.management.cloud_start_requested.connect(self.start_cloud_share)
        self.management.cloud_stop_requested.connect(self.cloud_share.stop_share)
        self.management.cloud_update_requested.connect(self.cloud_share.redownload_cloudflared)
        self.management.cloud_diag_requested.connect(self.cloud_share.run_network_diagnostics)
        self.management.cloud_firewall_requested.connect(self.cloud_share.repair_windows_firewall)
        self.management.cloud_warp_requested.connect(lambda: self.start_cloud_share(warp_assist=True))

        self.library.library_changed.connect(self.cloud_share.update_library)
        self.cloud_share.status_changed.connect(self.management.set_cloud_status)
        self.cloud_share.url_changed.connect(self.management.set_cloud_url)
        self.cloud_share.download_progress.connect(self.management.set_cloud_progress)
        self.cloud_share.running_changed.connect(self.management.set_cloud_running)
        self.cloud_share.cloudflared_version.connect(self.management.set_cloud_version)
        self.cloud_share.provider_changed.connect(self.management.set_tunnel_provider)
        self.cloud_share.diagnostics_result.connect(self.management.set_network_diagnostics)
        self.cloud_share.log_reset.connect(self.management.reset_cloud_log)
        self.cloud_share.log_line.connect(self.management.append_cloud_log)
        self.cloud_share.error.connect(self.on_cloud_error)

        self.apply_theme()

        if any(Path(f).is_dir() for f in library_folders(self.cfg)):
            QTimer.singleShot(220, self.library.scan)

    def start_cloud_share(self, warp_assist=False):
        videos = self.library.export_web_library()
        if not videos:
            QMessageBox.information(
                self, "اشتراک اینترنتی",
                "Library هنوز فیلمی ندارد. ابتدا فولدر را انتخاب و اسکن کنید."
            )
            return
        self.cloud_share.update_library(videos)
        self.cloud_share.web.state.expire_minutes = self.management.share_expire_spin.value()
        self.cloud_share.web.state.set_password(self.management.share_password.text())
        if warp_assist:
            self.cloud_share.start_share_with_warp()
        else:
            self.cloud_share.start_share()

    def on_cloud_error(self, message):
        QMessageBox.warning(
            self, "اشتراک اینترنتی",
            str(message) + "\n\nلاگ کامل در تب مدیریت ثبت شده است؛ دکمه «کپی لاگ» را بزن و برای بررسی بفرست."
        )

    def on_folder_changed(self, folder):
        self.cfg['folder'] = folder
        self.cfg['folders'] = list(library_folders(self.management.cfg))
        self.library._last_scan_fingerprint = None
        save_config(self.cfg)
        if library_folders(self.cfg):
            self.library.scan()
        else:
            self.library.stop_all_previews()
            self.library.model.clear()
            self.library._last_scan_fingerprint = None
            self.library.content_stack.setCurrentIndex(1)
            self.library.recount()

    def on_settings_changed(self):
        self.cfg.update({
            "folder": self.management.folder_edit.text(),
            "folders": list(library_folders(self.management.cfg)),
            "watch_folders": self.management.watch_folders.isChecked(),
            "gpu_decode": self.management.gpu_decode.isChecked(),
            "hover_interpolation": self.management.hover_interpolation.isChecked(),
            "share_expire_minutes": self.management.share_expire_spin.value(),
            "recursive": self.management.recursive.isChecked(),
            "preview_mode": self.management.cfg.get("preview_mode", "hover"),
            "cache_enabled": self.management.cfg.get("cache_enabled", False),
            "clear_cache_on_exit": self.management.clear_on_exit.isChecked(),
            "ram_limit_mb": self.management.ram_slider.value(),
            "card_width": self.management.card_slider.value(),
            "hover_video_fps": self.management.hover_fps_slider.value(),
            "hover_video_speed": self.management.hover_speed_slider.value() / 10.0,
            "workers": self.management.worker_spin.value(),
        })
        save_config(self.cfg)
        self.library.apply_settings(self.cfg)
        self.management.update_cache_size()

    def closeEvent(self, event):
        if self.library.move_busy:
            QMessageBox.information(self, 'انتقال در جریان است',
                                    'انتقال فایل‌ها هنوز تمام نشده است؛ پیش از بستن برنامه آن را تکمیل کنید.')
            event.ignore()
            return
        self.cloud_share.stop_share()
        try:
            self.library.shutdown_players()
            self.library.watch_timer.stop()
            self.library.perf_timer.stop()
            self.library.timeline_pool.clear()
            self.library.timeline_pool.waitForDone(4500)
            self.library.move_pool.waitForDone(4500)
            self.library.visible_live.shutdown()
            self.library.live_preview.shutdown()
        except Exception:
            pass
        save_config(self.cfg)
        if self.cfg.get("clear_cache_on_exit", False):
            clear_cache_dir()
        super().closeEvent(event)

    def apply_theme(self):
        self.setStyleSheet("""
        * { font-family: "Segoe UI Variable", "Segoe UI", sans-serif; font-size: 13px; }
        QMainWindow, QWidget#appShell { background-color: #0b1220; color: #edf2ff; }
        QWidget { color: #edf2ff; }
        QFrame#appHeader {
            background-color: #0e1828;
            border-bottom: 1px solid #26374d;
        }
        QLabel#brandMark {
            color: #f8faff;
            background-color: #526be8;
            border: 1px solid #8696ff;
            border-radius: 13px;
            font-size: 27px;
            font-weight: 800;
        }
        QLabel#brandName { color: #f9fbff; font-size: 22px; font-weight: 800; }
        QLabel#brandDescription { color: #90a2bd; font-size: 11px; }
        QLabel#headerBadge {
            color: #a9e8d6;
            background-color: #142c33;
            border: 1px solid #275049;
            border-radius: 11px;
            padding: 7px 12px;
            font-size: 10px;
            font-weight: 700;
        }
        QLabel#headerVersion {
            color: #b6c2e5;
            background-color: #182438;
            border: 1px solid #2c3c56;
            border-radius: 10px;
            padding: 7px 11px;
            font-size: 11px;
        }
        QTabWidget::pane { border: 0px; background-color: #0b1220; }
        QTabBar { background-color: #0e1828; }
        QTabBar::tab {
            background-color: #0e1828;
            color: #96a7c2;
            padding: 13px 30px;
            border-bottom: 3px solid transparent;
            min-width: 100px;
            font-weight: 600;
        }
        QTabBar::tab:hover { color: #e6edff; background-color: #162239; }
        QTabBar::tab:selected { color: #f8faff; border-bottom: 3px solid #8ea3ff; }
        QLabel#libraryTitle { color: #f5f8ff; font-size: 27px; font-weight: 800; }
        QLabel#pageTitle { color: #f5f8ff; font-size: 24px; font-weight: 750; }
        QLabel#subtitle, QLabel#muted { color: #92a5bf; }
        QLabel#sectionLabel { color: #edf3ff; font-size: 16px; font-weight: 700; }
        QLabel#sideTitle { color: #fafbff; font-size: 21px; font-weight: 750; }
        QLabel#folderChip, QLabel#statPill {
            color: #b8c9e3;
            background-color: #172438;
            border: 1px solid #2c3c55;
            border-radius: 12px;
            padding: 8px 13px;
            font-size: 12px;
        }
        QLabel#folderChip { color: #bfcbff; }
        QLabel#selectionInfo {
            color: #e6ecff;
            background-color: #233457;
            border: 1px solid #4b6096;
            border-radius: 11px;
            padding: 8px 12px;
            font-weight: 700;
        }
        QFrame#toolbarPanel, QFrame#actionBar, QFrame#panel {
            background-color: #121e30;
            border: 1px solid #293a51;
            border-radius: 17px;
        }
        QFrame#actionBar { background-color: #101c2d; }
        QFrame#managementSidebar {
            background-color: #121e30;
            border: 1px solid #293a51;
            border-radius: 18px;
        }
        QPushButton#sideNavButton {
            text-align: right;
            padding: 12px 14px;
            border: 1px solid transparent;
            border-radius: 12px;
            color: #a6b7d0;
            background-color: transparent;
            font-weight: 600;
        }
        QPushButton#sideNavButton:hover { background-color: #1b2b44; color: #f1f6ff; }
        QPushButton#sideNavButton:checked {
            background-color: #243657;
            border: 1px solid #536ca5;
            color: #f9fbff;
        }
        QFrame#statusBox {
            background-color: #10293a;
            border: 1px solid #2a5961;
            border-radius: 12px;
        }
        QLabel#cloudStatus { color: #9ce4d7; font-weight: 700; }
        QLabel#valueBadge {
            background-color: #253451;
            color: #dce5ff;
            border: 1px solid #42577b;
            border-radius: 10px;
            padding: 7px 10px;
            min-width: 54px;
            font-weight: 700;
        }
        QLineEdit, QComboBox, QSpinBox {
            background-color: #0d1728;
            color: #f0f5ff;
            selection-background-color: #556cbd;
            border: 1px solid #344762;
            border-radius: 11px;
            padding: 10px 13px;
            min-height: 22px;
        }
        QLineEdit#searchField { font-size: 13px; padding: 10px 15px; }
        QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
            border: 1px solid #91a6ff;
            background-color: #131f33;
        }
        QLineEdit:read-only { color: #b3c2da; }
        QComboBox::drop-down { border: 0; width: 25px; }
        QComboBox QAbstractItemView {
            background-color: #18273d;
            color: #f5f7ff;
            border: 1px solid #3d5271;
            selection-background-color: #324a79;
            padding: 5px;
        }
        QPushButton {
            background-color: #223149;
            color: #e6eeff;
            border: 1px solid #3a4c65;
            border-radius: 11px;
            padding: 10px 15px;
            min-height: 19px;
            font-weight: 600;
        }
        QPushButton:hover { background-color: #2b4060; border: 1px solid #58719b; }
        QPushButton:pressed { background-color: #19263c; }
        QPushButton:focus { border: 1px solid #a2b5ff; }
        QPushButton:disabled { color: #657690; border-color: #263449; background-color: #192638; }
        QPushButton#primaryButton {
            color: #ffffff;
            background-color: #576fe4;
            border: 1px solid #7087ff;
            font-weight: 700;
        }
        QPushButton#primaryButton:hover { background-color: #6b82fa; border-color: #a2b2ff; }
        QPushButton#primaryButton:pressed { background-color: #4357c4; }
        QPushButton#softDangerButton {
            color: #f0b9c3;
            background-color: #302735;
            border-color: #634250;
        }
        QPushButton#softDangerButton:hover { background-color: #4a3040; border-color: #9d536b; }
        QPushButton#dangerButton {
            color: #ffe1e5;
            background-color: #6a3449;
            border-color: #a3586a;
        }
        QPushButton#dangerButton:hover { background-color: #854055; }
        QPushButton:checked {
            background-color: #304a76;
            border: 1px solid #7795d4;
            color: #ffffff;
        }
        QSlider::groove:horizontal { height: 6px; background-color: #253750; border-radius: 3px; }
        QSlider::sub-page:horizontal { background-color: #637ff4; border-radius: 3px; }
        QSlider::handle:horizontal {
            width: 17px;
            margin: -6px 0;
            border-radius: 8px;
            background-color: #d7e1ff;
            border: 2px solid #8197ff;
        }
        QListView { background-color: transparent; border: 0; outline: 0; }
        QListView::item { background-color: transparent; border: 0; }
        QScrollArea { background-color: transparent; border: 0; }
        QScrollArea > QWidget > QWidget { background-color: transparent; }
        QScrollBar:vertical { background-color: transparent; width: 10px; margin: 2px; }
        QScrollBar::handle:vertical { background-color: #425570; min-height: 34px; border-radius: 5px; }
        QScrollBar::handle:vertical:hover { background-color: #617a9b; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        QScrollBar:horizontal { background-color: transparent; height: 10px; }
        QScrollBar::handle:horizontal { background-color: #425570; border-radius: 5px; }
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
        QProgressBar { background-color: #20304b; border: 0; border-radius: 3px; }
        QProgressBar::chunk { background-color: #859bff; border-radius: 3px; }
        QPlainTextEdit {
            color: #c6d6ee;
            background-color: #0b1525;
            border: 1px solid #32435e;
            border-radius: 12px;
            padding: 12px;
            font-family: "Cascadia Code", "Consolas", monospace;
            font-size: 11px;
        }
        QMenu { background-color: #172439; color: #eff3ff; border: 1px solid #41536e; padding: 7px; }
        QMenu::item { padding: 9px 25px; border-radius: 7px; }
        QMenu::item:selected { background-color: #314873; }
        QFrame#emptyState { border: 1px dashed #375071; border-radius: 18px; background-color: #101b2c; }
        QLabel#timelineThumb { background-color: #0d1728; border: 1px solid #344762; border-radius: 13px; }
        QLabel#emptySymbol { color: #7e95ec; font-size: 67px; font-weight: 400; }
        QLabel#emptyTitle { color: #f7faff; font-size: 23px; font-weight: 750; }
        QToolTip { background-color: #243653; color: #f4f8ff; border: 1px solid #536a92; padding: 6px; }
        """)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    app.setLayoutDirection(Qt.RightToLeft)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
