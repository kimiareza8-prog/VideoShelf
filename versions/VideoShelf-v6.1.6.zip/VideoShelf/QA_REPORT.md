# VideoShelf v6.1.2 — Preview Timing Update

- Live Hover and all-visible-card previews now use five anchors: 10%, 30%, 50%, 70%, and 90% of video duration.
- Three source seconds per anchor; at the default 2× speed, playback is approximately 1.5 seconds per anchor (excluding process start/seek overhead).
- A video with not-yet-loaded duration is probed in the decode worker before seeking; missing duration does not trigger a seek to 00:00.
- Short videos may have shorter samples near the 90% mark. No anchor is moved backward to the start.
- All 27 automated tests passed in the packaging environment. Two real FFmpeg samples (10%, 90%) each decoded 90 frames representing three seconds at 30fps in approximately 1.41 seconds wall time.
- Full Windows/PySide6 GUI execution remains unverified in this environment.

---

# VideoShelf v6.1.1 — Visible Live Preview QA

- Visible-card preview now instantiates live FFmpeg stream widgets using the same `SmoothHoverPreview` clock, buffering and 2× speed as Hover. No JPEG slideshow task is scheduled from the visible branch.
- Visible-card decode resolution is 384×216 (Hover remains 512×288); output FPS/speed settings are shared, so actual achieved FPS depends on CPU/GPU throughput.
- Default maximum is 8 concurrently active visible cards, user-configurable from 1 to 24. If more files are in the viewport, one active slot rotates every 2.5 seconds. Non-active cards show a poster rather than pretending to be live.
- Moving the pointer to a card in visible mode prioritizes its decoder slot; it does not start a separate Hover decoder.
- Source has no `QProcess` in the live streaming path; FFmpeg process cancellation is managed through the existing subprocess worker pool. Visible inputs use at most 2 FFmpeg decoder threads each.
- Tests: `python -m unittest discover -s tests -p 'test_*.py' -v`.
- Automated tests validate selection fairness, bounded concurrency, hover priority, live-stream wiring and prior project behavior.
- Limitations: Actual PySide6 Windows GUI performance and the behavior of multiple simultaneous 4K/HEVC files have not been validated on the target computer. Choosing a high concurrency limit may overload the machine; reduce it if animations lag.

---

# VideoShelf v6.1.0 — Quality & Verification Report

## Implemented in the v6.1 revision

- Opt-in **FFmpeg motion-compensated interpolation** (`minterpolate`, not merely FPS duplication), plus normal frame sampling when disabled.
- Bounded, reusable Python **decode-worker thread pool** with cancellation and cleanup of subprocesses; FFmpeg itself still restarts when a new source or seek is required.
- More stable FFmpeg stderr handling via OS temporary file and longer hover segments.
- SQLite WAL metadata index with explicit connection closing and current-library-only batched lookups.
- Low-overhead folder enumeration using `scandir`, avoiding traversing symbolic directory links; visible-card processing is bounded to visible items.
- HTTP API with true server-side paginated/filterable/sortable results; desktop and mobile web frontend fetches 80 items per request.
- Asynchronous batch move with source metadata preservation, conflict naming, cross-volume staged copy and rollback where possible.

## Test execution

Run in the extracted `VideoShelf` folder:

```bash
python -m unittest discover -s tests -v
```

Automated suite covers portable ratings, favorites and collections; metadata after moving folders; exact duplicate detection; SQLite reuse and invalidation; batch moves and filename conflicts; cross-drive fallback; corrupt sidecar behavior; FFmpeg interpolation output; preview command configuration, bounded pool and cleanup; HTTP password and token expiry; server-side pagination, search, sort and filters.

**Result during packaging: 15 automated tests passed.** JavaScript syntax and Python compilation passed. An additional isolated SQLite benchmark indexed **50,000 synthetic metadata rows**, but this did not instantiate 50,000 actual video cards or perform filesystem/4K video benchmarks.

## Limits — not certified

- Full Windows graphical UI integration and Windows installer/binary not tested in this environment. PySide6 was not available and installing it was blocked by the build environment network.
- Hardware GPU acceleration depends on actual Windows drivers and codecs. It is optional and includes CPU fallback when initialization fails, but not a guarantee of 60 FPS for all formats.
- Frame interpolation is CPU-intensive and may introduce artifacts; it is disabled by default. It is FFmpeg optical-flow/block motion compensation, **not AI video-frame synthesis on the GPU**.
- The pool reuses Python decoder workers, **not the exact same FFmpeg process across different movies**. Reusing an FFmpeg process with arbitrary input changes requires a different media pipeline and has not been implemented.
- Large-library index benchmark measures SQLite only, **not complete end-to-end performance** for 50,000 video files.
- Physical drive-to-drive interruption tests and Windows filesystem permission/error paths should be validated on the target machine before critical mass moves.

## Migration guidance

Unzip in a **new folder**. Back up your old app `config.json` if you want to preserve prior selected paths/settings. Keep `.videoshelf.json` files beside videos; they are the portable source for ratings/favorites/collections. No files are moved or deleted automatically on upgrade.
