"""v6.1.4 regression: 20 crisp stars and safe real file name rating sync."""
from __future__ import annotations
import ast
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rating_names import MAX_RATING, rated_filename, rename_video_for_rating
from file_actions import _read_sidecar


class RatingNameTests(unittest.TestCase):
    def test_actual_name_format_and_extension(self):
        self.assertEqual(MAX_RATING, 20)
        self.assertEqual(rated_filename('فیلم یک.mkv', 15), 'فیلم یک [★15].mkv')
        self.assertEqual(rated_filename('فیلم یک [★15].mkv', 6), 'فیلم یک [★6].mkv')
        self.assertEqual(rated_filename('فیلم یک [★6].mkv', 0), 'فیلم یک.mkv')
        self.assertEqual(rated_filename('film.final.mp4', 20), 'film.final [★20].mp4')
        with self.assertRaises(ValueError):
            rated_filename('film.mp4', 21)
        with self.assertRaises(ValueError):
            rated_filename('film.mp4', -1)

    def test_renaming_multiple_times_keeps_metadata_and_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            src = folder / 'فیلم اول.mkv'
            src.write_bytes(b'video-content-sample')
            (folder / '.videoshelf.json').write_text(json.dumps({
                'version': 1, 'ratings': {'فیلم اول.mkv': 7},
                'favorites': {'فیلم اول.mkv': True},
                'collections': {'فیلم اول.mkv': ['Sci-Fi']},
                'future_field': {'فیلم اول.mkv': {'progress': 32.0}},
            }, ensure_ascii=False), encoding='utf-8')
            for rating, expected in [(15, 'فیلم اول [★15].mkv'),
                                     (6, 'فیلم اول [★6].mkv'),
                                     (20, 'فیلم اول [★20].mkv')]:
                dst = Path(rename_video_for_rating(str(src), rating))
                self.assertEqual(dst.name, expected)
                self.assertFalse(src.exists())
                self.assertEqual(dst.read_bytes(), b'video-content-sample')
                side = _read_sidecar(folder)
                self.assertEqual(side['ratings'], {expected: rating})
                self.assertEqual(side['favorites'], {expected: True})
                self.assertEqual(side['collections'], {expected: ['Sci-Fi']})
                self.assertEqual(side['future_field'], {expected: {'progress': 32.0}})
                src = dst
            dst = Path(rename_video_for_rating(str(src), 0))
            self.assertEqual(dst.name, 'فیلم اول.mkv')
            side = _read_sidecar(folder)
            self.assertFalse(side.get('ratings'))
            self.assertEqual(side['favorites'], {'فیلم اول.mkv': True})
            self.assertEqual(side['collections'], {'فیلم اول.mkv': ['Sci-Fi']})
            self.assertEqual(side['future_field'], {'فیلم اول.mkv': {'progress': 32.0}})

    def test_collision_does_not_overwrite_video_or_sidecar(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            src = folder / 'film [★6].mp4'
            other = folder / 'film [★15].mp4'
            src.write_bytes(b'first'); other.write_bytes(b'keep me')
            side = {'ratings': {src.name: 6, other.name: 15}}
            meta = folder / '.videoshelf.json'
            meta.write_text(json.dumps(side))
            before = meta.read_bytes()
            with self.assertRaises(FileExistsError):
                rename_video_for_rating(str(src), 15)
            self.assertEqual(src.read_bytes(), b'first')
            self.assertEqual(other.read_bytes(), b'keep me')
            self.assertEqual(meta.read_bytes(), before)

    def test_sidecar_failure_rolls_file_name_back(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            src = folder / 'video.mp4'
            src.write_bytes(b'original')
            with patch('rating_names._write_sidecar', side_effect=PermissionError('read only')):
                with self.assertRaises(PermissionError):
                    rename_video_for_rating(str(src), 12)
            self.assertTrue(src.exists())
            self.assertFalse((folder / 'video [★12].mp4').exists())
            self.assertEqual(src.read_bytes(), b'original')

    def test_untouched_files_and_repeat_rating(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            a = folder / 'a.mp4'; b = folder / 'b.mkv'
            a.write_bytes(b'a'); b.write_bytes(b'b')
            out = Path(rename_video_for_rating(str(a), 20))
            self.assertEqual(Path(rename_video_for_rating(str(out), 20)), out)
            self.assertEqual(b.read_bytes(), b'b')
            self.assertEqual(_read_sidecar(folder)['ratings'], {out.name: 20})


class StaticUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.tree = ast.parse(cls.source)

    def test_ratings_are_20_in_app_and_web(self):
        self.assertIn('MAX_RATING = 20', self.source)
        self.assertIn('MAX_RATING = 20', (ROOT/'cloud_share.py').read_text(encoding='utf-8'))
        self.assertIn('★ ۲۰', self.source)
        self.assertIn('★ ۲۰', (ROOT/'cloud_share.py').read_text(encoding='utf-8'))

    def test_draws_vector_stars_without_old_font_glyphs(self):
        cl = next(x for x in self.tree.body if isinstance(x, ast.ClassDef) and x.name == 'VideoCardDelegate')
        paint = next(x for x in cl.body if isinstance(x, ast.FunctionDef) and x.name == 'paint')
        text = ast.unparse(paint)
        self.assertIn('drawPath(self._star_path)', text)
        self.assertNotIn("'☆'", text)
        self.assertIn('MAX_RATING', ast.unparse(next(x for x in cl.body if isinstance(x, ast.FunctionDef) and x.name == 'star_rects')))

    def test_rating_does_not_trigger_an_immediate_sort_or_model_reset(self):
        library = next(x for x in self.tree.body if isinstance(x, ast.ClassDef) and x.name == 'LibraryTab')
        rating = next(x for x in library.body if isinstance(x, ast.FunctionDef) and x.name == 'on_rating_requested')
        text = ast.unparse(rating)
        self.assertIn('_pending_rating_renames', text)
        self.assertNotIn('set_items(', text)
        self.assertNotIn('invalidateFilter(', text)
        self.assertNotIn('sort(', text)
        rename = next(x for x in library.body if isinstance(x, ast.FunctionDef) and x.name == '_flush_rating_renames')
        self.assertIn('rename_video_for_rating', ast.unparse(rename))
        self.assertIn('rename_item_path', ast.unparse(rename))


if __name__ == '__main__':
    unittest.main()
